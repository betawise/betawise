"""Reviewed baseline/mark revisions; reconstruct from native pixels, never a clipped export."""
import unicodedata
from PIL import Image,ImageDraw
import build as b
import extended_fit as ef
import cedilla_fit as cf
# Baseline/descender experiment withdrawn; retain only Schoolbook umlauts.
SHIFTS={}

def glyph(width,points):
 low=min((y for x,y in points),default=0);high=max((y+1 for x,y in points),default=1)
 im=Image.new('1',(width,high-low))
 for x,y in points:im.putpixel((x,y-low),1)
 return ((width,0),(0,low,width,high),(0,0,width,high-low),im)

def revise(stem,styles,lines,pitch,faces,meta):
 shift=SHIFTS.get((stem,lines),0)
 if not shift and (stem,lines)!=('ncen',4):return faces,meta,[]
 baseline=meta['baseline']+shift;records=[];out={}
 for st,srcst in zip(['R','B','I','BI'],styles):
  path,source=b.source(stem,srcst,meta['points'],meta['dpi']);face={}
  for code in b.CODES:
   width,pts=ef.pixels(source[code]);original=set(pts);lower={(x,y)for x,y in pts if y>=0}
   lower,steps=cf.shorten(lower,pitch-baseline)
   pts={(x,y)for x,y in pts if y<0}|lower
   dia=False
   if (stem,lines)==('ncen',4) and code in [0xc4,0xcb,0xcf,0xd6,0xdc,0xe4,0xeb,0xef,0xf6,0xfc,0x9f,0xff]:
    base=ord(unicodedata.normalize('NFD',bytes([code]).decode('cp1252'))[0])
    _,bp=ef.pixels(source[base]);split=min(y for x,y in bp)
    accent={(x,y)for x,y in pts if y<split}
    if accent:
     # Keep native dot columns, but one high with an empty row above the body.
     pts={p for p in pts if p not in accent}|{(x,split-2)for x,y in accent};dia=True
   cell,change=ef.fit(glyph(width,pts),source,code,-baseline,pitch,pitch)
   face[code]=cell
   if steps or change or dia:records.append(dict(style=st,code=f'{code:02X}',lower_shortening=steps,upper_fit=change,one_row_diaeresis=dia))
   if code<128:
    actual={(x,y-baseline)for x,y in cf.points(cell)}
    assert {p for p in actual if p[1]<0}=={p for p in original if p[1]<0}
  out[st]=face
 return out,{**meta,'baseline':baseline,'baseline_shift_down':shift,'accent_revision':'Native source rebuilt; upper accents fitted separately; only lower descender/cedilla rows shortened to make baseline room.'},records

def card(out,before,after,entries):
 rows=[('Times','tim',4,16),('Times','tim',5,13),('Helvetica','helv',5,13),('Helvetica','helv',6,11),('Schoolbook','ncen',4,16),('Schoolbook','ncen',5,13)]
 im=Image.new('RGB',(1700,80+len(rows)*580),'white');d=ImageDraw.Draw(im)
 d.text((16,8),'Accent revisions — previous / revised',font=b.TITLE,fill='black')
 d.text((16,40),'Source glyphs at 3×; letters, accents, cedillas and descenders shown together. No whole-font rescaling.',font=b.SMALL,fill='#444444')
 for i,(name,stem,lines,pitch) in enumerate(rows):
  y=80+i*580;d.text((12,y),f'{name} · {lines} lines',font=b.TITLE,fill='black')
  for j,st in enumerate(['R','B','I','BI']):
   yy=y+36+j*132;d.text((12,yy),st,font=b.LABEL,fill='black')
   for k,collection in enumerate([before,after]):
    x=70+k*815;d.text((x,yy),'Previous'if not k else'Revised',font=b.SMALL,fill='#555555')
    for n,text in enumerate(['ÀÁÂÃÄÅ ÉÊË ÑÖÜ ŠŽŸ','CÇ cç ¸  g j p q y']):
     mask=b.render_run(collection[stem,lines][st],text.encode('cp1252'));b.draw_ink(im,mask,(x,yy+19+n*(pitch*3+3)),3)
  d.line((0,y+575,1700,y+575),fill='#bbbbbb')
 im.save(out/'accent-revisions.png')
