#!/usr/bin/env python3
"""Lossless integer-row Courier experiments; no production font changes."""
from pathlib import Path
from collections import defaultdict
import math,json,gzip
from PIL import Image,ImageDraw,PcfFontFile
import build as b
import evaluate_substitutes as e
OUT=b.HERE/'courier-gentle'
STYLES=['R','B','O','BO']
SAMPLE='AaBbCcDdEeFfGg'
EXTRA='MW mw ij 0123'
# Explicit reviewed draft corrections, in source pen/baseline coordinates.
# Moves preserve pixel count; deletions are disclosed, never called lossless.
PATCHES={
 4:[('BO',0x80,(10,-8),(8,-8))],
 5:[('O',0x57,(0,-8),None)],
 6:[('B',0x99,(5,-8),(3,-8)),('BO',0x89,(-1,-3),None),
    ('BO',0x99,(6,-7),(5,-7)),('BO',0x9c,(-1,-3),(0,-3)),
    ('BO',0xbe,(6,-6),(5,-6))]}
def patched(faces,lines):
 result={st:{c:set(p)for c,p in face.items()}for st,face in faces.items()}
 for st,c,old,new in PATCHES[lines]:
  assert old in result[st][c] and (new is None or new not in result[st][c])
  result[st][c].remove(old)
  if new is not None:result[st][c].add(new)
 return result


def fit(points,width,oblique,adaptive):
 rows=defaultdict(list)
 for x,y in points:rows[y].append(x)
 if not rows:return dict(points=set(),shifts={},adapted=False)
 targets={y:math.floor(y*math.tan(math.radians(12))*.5+.5)if oblique else 0 for y in rows}
 half={(x+targets[y],y)for x,y in points}
 a=min(x for x,y in half);z=max(x for x,y in half)+1
 if z-a<=width:
  off=max(-a,min(0,width-z));shifts={y:targets[y]+off for y in rows}
  return dict(points={(x+shifts[y],y)for x,y in points},shifts=shifts,adapted=False)
 if not adaptive or any(max(xs)-min(xs)+1>width for xs in rows.values()):return None
 best=None
 for anchor in range(-3,4):
  prev={};yprev=None
  for y in sorted(rows):
   lo=-min(rows[y]);hi=width-1-max(rows[y]);target=targets[y]+anchor
   curr={}
   for shift in range(lo,hi+1):
    local=(shift-target)**2
    if not prev:curr[shift]=(local,{y:shift})
    else:
     cost,path=min(((cost+local+6*((shift-sp)-(targets[y]-targets[yprev]))**2,{**path,y:shift})for sp,(cost,path)in prev.items()),key=lambda v:v[0])
     curr[shift]=(cost,path)
   prev=curr;yprev=y
  cost,path=min(prev.values(),key=lambda x:x[0]);score=cost+anchor*anchor
  if best is None or score<best[0]:best=(score,path)
 shifts=best[1];result={(x+shifts[y],y)for x,y in points}
 assert len(result)==len(points)
 for y,xs in rows.items():assert sorted(x for x,yy in result if yy==y)==sorted(x+shifts[y]for x in xs)
 assert all(0<=x<width for x,y in result)
 return dict(points=result,shifts=shifts,adapted=True)

def source(lines):
 pt,dpi,base=(12,100,None)if lines==4 else(12,75,None)if lines==5 else(8,75,8)
 report=json.loads((b.OUT/'report.json').read_text())
 if base is None:base=next(x['baseline']for x in report['fonts']if x['family']=='Courier'and x['lines']==lines)
 faces={};paths=[]
 for st in STYLES:
  rawpath,raw=b.source('cour',st,pt,dpi);paths.append(str(rawpath))
  path=b.OUT/(f'aligned6-cour-{st}.bdf'if lines==6 else f'cour-{lines}-lines-{st}.bdf')
  _,gs,_=e.parse(path)
  faces[st]={c:{(x-max(0,-raw[c][1][0]),y)for x,y in gs[c]['points']}for c in b.CODES}
 width=raw[65][0][0]
 return faces,width,base,paths

def cells(faces,width,pitch,baseline,mode):
 result={};fail={};adapted={};shifts={}
 for st,face in faces.items():
  result[st]={};fail[st]=[];adapted[st]=[];shifts[st]={}
  for c,points in face.items():
   if mode=='original':
    left=min([x for x,y in points]+[0]);right=max([x+1 for x,y in points]+[width]);pts={(x-left,y)for x,y in points};cw=right-left;out=None
   else:
    out=fit(points,width,st in ['O','BO'],mode=='adaptive')
    if out is None:
     fail[st].append(f'{c:02X}');target={y:math.floor(y*math.tan(math.radians(12))*.5+.5)if st in ['O','BO']else 0 for x,y in points}
     pts={(x+target[y],y)for x,y in points};left=min([x for x,y in pts]+[0]);right=max([x+1 for x,y in pts]+[width]);pts={(x-left,y)for x,y in pts};cw=right-left
    else:
     pts=out['points'];cw=width;shifts[st][f'{c:02X}']=out['shifts']
     if out['adapted']:adapted[st].append(f'{c:02X}')
   im=Image.new('1',(cw,pitch))
   for x,y in pts:
    assert 0<=x<cw and 0<=y+baseline<pitch,(st,c,x,y,baseline,pitch)
    im.putpixel((x,y+baseline),1)
   assert sum(bool(im.getpixel((x,y)))for y in range(pitch)for x in range(cw))==len(points)
   result[st][c]=im
 return result,dict(failed=fail,adaptive_glyphs=adapted,row_shifts=shifts)

def export(path,face,baseline):
 h=next(iter(face.values())).height;w=next(iter(face.values())).width
 out=['STARTFONT 2.1',f'FONT -betawise-couriergentle-medium-r-normal--{h}-0-75-75-m-0-fontspecific-0','SIZE 10 75 75',f'FONTBOUNDINGBOX {w} {h} 0 {baseline-h}','STARTPROPERTIES 3',f'FONT_ASCENT {baseline}',f'FONT_DESCENT {h-baseline}','COPYRIGHT "Adobe/DEC derivative research; see ../build/FONT-LICENSE.txt"','ENDPROPERTIES',f'CHARS {len(face)}']
 for c,im in sorted(face.items()):
  assert im.size==(w,h)
  out +=[f'STARTCHAR slot{c:02X}',f'ENCODING {c}','SWIDTH 500 0',f'DWIDTH {w} 0',f'BBX {w} {h} 0 {baseline-h}','BITMAP']
  n=(w+7)//8
  for y in range(h):out.append(f'{sum(bool(im.getpixel((x,y)))<<(8*n-1-x)for x in range(w)):0{n*2}X}')
  out.append('ENDCHAR')
 out.append('ENDFONT');path.write_text('\n'.join(out)+'\n')
 _,gs,_=e.parse(path)
 for c,im in face.items():
  expected={(x,y-baseline)for y in range(h)for x in range(w)if im.getpixel((x,y))}
  assert gs[c]['points']==expected and gs[c]['advance']==w

def main():
 OUT.mkdir(exist_ok=True);reports=[];panels=[];font=b.LABEL;small=b.SMALL
 for lines,pitch in [(4,16),(5,13),(6,11)]:
  faces,w,base,paths=source(lines)
  # Absolute lossless minimum for whole-row moves, across all four faces.
  minwidth=max(max(xs)-min(xs)+1 for face in faces.values()for pts in face.values()for y in {y for x,y in pts}for xs in [[x for x,yy in pts if yy==y]])
  widths=[w,w+1,minwidth];modes=[('Original normalized','original',w),('Gentler, original width','adaptive',w),('Gentler, +1px + small edits','patched',w+1),('Gentler, minimum lossless','adaptive',minwidth)]
  card=Image.new('RGB',(2320,160+4*(62+pitch*6+22)),'white');d=ImageDraw.Draw(card)
  d.text((12,8),f'Courier {lines} lines — common widths across R/B/O/BO; lossless and minimally edited options',font=b.TITLE,fill='black')
  d.text((12,40),'All samples 3×. Half-slant target + constrained row shifts. +1px uses disclosed tiny edits; final column preserves every source pixel.',font=small,fill='#444444')
  entry=dict(lines=lines,pitch=pitch,baseline=base,source_width=w,minimum_lossless_width=minwidth,source_paths=paths,manual_patches=[dict(style=st,code=f'{c:02X}',old=old,new=new,operation='delete'if new is None else'move')for st,c,old,new in PATCHES[lines]],variants=[])
  for j,(title,mode,width)in enumerate(modes):
   working=patched(faces,lines)if mode=='patched'else faces
   cs,meta=cells(working,width,pitch,base,'adaptive'if mode=='patched'else mode);x=12+j*580
   d.text((x,76),title,font=font,fill='black')
   d.text((x,100),f'{width}px target → {264//width} columns + {264%width}px remainder',font=small,fill='#555555')
   total=sum(len(v)for v in meta['failed'].values())
   status='Variable advances (existing conversion)'if mode=='original'else f'{len(PATCHES[lines])} hand-edited glyphs; all four faces fit'if mode=='patched'else f'{total} glyph/style exceptions; '+('not fixed yet'if total else'all four faces fit')
   d.text((x,121),status,font=small,fill='#a02020'if total else'#335533')
   for i,st in enumerate(STYLES):
    y=160+i*(62+pitch*6+22)
    d.text((x,y),st+(' — exceptions expanded, NOT clipped'if meta['failed'][st]else''),font=font,fill='#a02020'if meta['failed'][st]else'black')
    for k,txt in enumerate([SAMPLE,EXTRA]):
     mask=b.render_run(cs[st],txt.encode());assert mask.width*3<560
     b.draw_ink(card,mask,(x,y+27+k*(pitch*3+5)),3)
   details={k:v for k,v in meta.items()if k!='row_shifts'}
   entry['variants'].append(dict(mode=mode,width=width,columns=264//width,remainder=264%width,**details))
   if mode in ['adaptive','patched']and total==0:
    for st in STYLES:export(OUT/f'courier-{lines}-lines-{width}px-{st}.bdf',cs[st],base)
    (OUT/f'courier-{lines}-lines-{width}px-shifts.json').write_text(json.dumps(meta,indent=2)+'\n')
  # Whole repertoire audit at +1px: glyphs with rows too wide cannot be fixed
  # by ANY row translation. Retain source shapes next to expanded shifted draft.
  bad=cells(faces,w+1,pitch,base,'adaptive')[1]['failed']
  specs=[(st,int(c,16))for st,codes in bad.items()for c in codes]
  if specs:
   panel=Image.new('RGB',(1160,90+len(specs)*(pitch*5+25)),'white');pd=ImageDraw.Draw(panel)
   pd.text((12,8),f'{lines} lines, {w+1}px cell: exceptions requiring pixel edits or a wider cell',font=b.TITLE,fill='black')
   pd.text((12,40),'Red rectangle = requested cell. Source ink shown in full. No clipping or pixel deletion applied.',font=small,fill='#555555')
   for i,(st,c)in enumerate(specs):
    yy=85+i*(pitch*5+25);pd.text((12,yy),f'{st} {c:02X} '+bytes([c]).decode('cp1252'),font=font,fill='black')
    pts=faces[st][c];left=min(x for x,y in pts);right=max(x for x,y in pts)+1
    g=Image.new('1',(max(w+1,right-left),pitch))
    for xx,yyy in pts:g.putpixel((xx-left,yyy+base),1)
    b.draw_ink(panel,g,(160,yy),5);pd.rectangle((159,yy-1,160+(w+1)*5,yy+pitch*5),outline='#b03030',width=2)
   panel.save(OUT/f'{lines}-lines-exceptions.png')
  card.save(OUT/f'{lines}-lines.png');panels.append(card);reports.append(entry)
 # Explicit source/patch/transformed glyph audit, no unrecorded corrections.
 audit=Image.new('RGB',(1500,100+7*165),'white');ad=ImageDraw.Draw(audit)
 ad.text((12,8),'Small +1px-cell corrections — exact source / hand edit / gentler fitted result',font=b.TITLE,fill='black')
 ad.text((12,40),'4/5/6-line drafts. Five pixel moves, two deletions total. These glyph corrections are not labelled lossless.',font=small,fill='#a02020')
 ii=0
 for lines,pitch in [(4,16),(5,13),(6,11)]:
  faces,w,base,_=source(lines);pf=patched(faces,lines);cs,_=cells(pf,w+1,pitch,base,'adaptive')
  for st,c,old,new in PATCHES[lines]:
   y=95+ii*165;ii+=1
   ad.text((12,y),f'{lines} lines {st} {c:02X} '+bytes([c]).decode('cp1252'),font=font,fill='black')
   ad.text((12,y+28),('delete '+str(old))if new is None else(str(old)+' → '+str(new)),font=small,fill='#555555')
   for j,pts in enumerate([faces[st][c],pf[st][c]]):
    left=min(x for x,y in pts);right=max(x for x,y in pts)+1;g=Image.new('1',(right-left,pitch))
    for x,yy in pts:g.putpixel((x-left,yy+base),1)
    b.draw_ink(audit,g,(350+j*300,y),7)
   b.draw_ink(audit,cs[st][c],(950,y),7)
 audit.save(OUT/'manual-patch-audit.png')
 # Lucida Typewriter source inventory: only native R/B in installed X11 set.
 lucida=[];lp=Image.new('RGB',(1160,640),'white');ld=ImageDraw.Draw(lp)
 ld.text((12,8),'Lucida Typewriter — available native upright references',font=b.TITLE,fill='black')
 ld.text((12,40),'No native oblique or bold-oblique entries found in the installed 75/100dpi X11 family.',font=small,fill='#a02020')
 for row,(pt,dpi)in enumerate([(12,100),(12,75),(8,75)]):
  profiles=[]
  for st in ['R','B']:
   path=Path('/usr/share/fonts/X11')/f'{dpi}dpi'/f'lut{st}S{pt:02}.pcf.gz'
   with gzip.open(path,'rb')as f:face=PcfFontFile.PcfFontFile(f,charset_encoding='cp1252').glyph
   assert all(face[c]is not None for c in b.CODES)
   profiles.append(face)
  top,bottom=b.envelope(profiles);y=85+row*180
  ld.text((12,y),f'{pt}pt / {dpi}dpi; full Western R+B height {bottom-top}px',font=font,fill='black')
  for k,face in enumerate(profiles):
   gs={}
   for c in b.CODES:
    ink,t,_=b.raw(face[c]);g=Image.new('1',(ink.width,bottom-top));g.paste(ink,(0,t-top));gs[c]=g
   mask=b.render_run(gs,SAMPLE.encode());b.draw_ink(lp,mask,(12,y+30+k*65),3)
  lucida.append(dict(points=pt,dpi=dpi,styles=['R','B'],full_western=True,shared_height=bottom-top))
 lp.save(OUT/'lucida-typewriter.png')
 (OUT/'report.json').write_text(json.dumps(dict(method='Half of nominal 12-degree shear removed by integer row shifts. Lossless minimum-width variants retain every input pixel; +1px variants use explicit small edits recorded per glyph. No whole-font resizing. Prior vertical accent repairs retained.',coverage='218 printable Western characters × four styles; raw Neo device/control glyphs not exported.',courier=reports,lucida_typewriter=lucida,validation='All 872 glyphs per variant preserve their input ink count; +1px input includes the explicitly recorded manual patches. Each successful row is an exact translation of that input row. Completed BDF exports round-trip exact bitmap positions and fixed advances.'),indent=2)+'\n')
 report_path=OUT/'report.json';record=json.loads(report_path.read_text());entries=[]
 for dpi in [75,100]:
  for line in Path(f'/usr/share/fonts/X11/{dpi}dpi/fonts.dir').read_text().splitlines()[1:]:
   filename,xlfd=line.split(' ',1)
   if '-lucidatypewriter-'in xlfd:
    parts=xlfd.split('-');entries.append(dict(dpi=dpi,file=filename,weight=parts[3],slant=parts[4],xlfd=xlfd))
 record['lucida_inventory']=dict(entries=entries,weights=sorted({x['weight']for x in entries}),slants=sorted({x['slant']for x in entries}))
 record['exported_bdf_faces']=len(list(OUT.glob('*.bdf')))
 report_path.write_text(json.dumps(record,indent=2)+'\n')
 totalh=75+sum(p.height+20 for p in panels);overview=Image.new('RGB',(2320,totalh),'white');od=ImageDraw.Draw(overview);od.text((12,10),'Courier gentler oblique — original / original width / +1px / minimum fully lossless width',font=b.TITLE,fill='black');y=75
 for p in panels:overview.paste(p,(0,y));y+=p.height+20
 overview.save(OUT/'overview.png')
 sections=[]
 for row in reports:
  lines=row['lines'];sections.append(f'<h2>{lines} lines</h2><a href="{lines}-lines.png"><img src="{lines}-lines.png"></a><p><a href="{lines}-lines-exceptions.png">+1px exceptions requiring edits or extra width</a></p>')
 (OUT/'index.html').write_text('<!doctype html><meta charset="utf-8"><title>Courier gentle oblique</title><style>body{font:17px sans-serif;margin:24px}img{max-width:100%;image-rendering:pixelated}</style><h1>Courier gentler oblique</h1><p>Minimum-lossless widths preserve every source pixel. +1px widths use explicit small edits (four lines: Euro BO pixel move; five lines: W oblique serif-tip deletion; six lines: five symbol glyphs, four moves and one deletion). Red exceptions in the original-width column are displayed expanded, not clipped. Completed +1px and minimum-lossless variants include BDF exports for all four styles.</p><p>All widths apply to all four faces. Division remainders use the complete 264-pixel width. A zero margin is a preference, not a reason to distort letters or discard pixels. Full Western = 218 printable CP1252 characters, not every Neo device/control glyph.</p>'+''.join(sections)+'<h2>Explicit small corrections</h2><img src="manual-patch-audit.png"><h2>Lucida Typewriter</h2><img src="lucida-typewriter.png"><p>Only regular/bold native bitmap faces found. These are references, not a complete four-style substitute.</p><p><a href="report.json">Metrics, source paths and exception lists</a></p>')
 for row in reports:print(row['lines'],'lines',[(v['width'],v['columns'],v['remainder'],sum(len(x)for x in v['failed'].values()))for v in row['variants']])
 print(OUT/'index.html')
if __name__=='__main__':main()
