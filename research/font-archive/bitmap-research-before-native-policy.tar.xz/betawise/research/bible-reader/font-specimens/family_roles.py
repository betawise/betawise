#!/usr/bin/env python3
"""Source-font comparison only; no Neo screen capture or visual test oracle."""
import json,struct
from pathlib import Path
from PIL import Image,ImageDraw
import build as b
ROOT=b.HERE.parents[3]

def packed_font(header,raw,widths,offsets):
    h=header[0];out={}
    for c in range(32,127):
        im=Image.new('1',(widths[c],h))
        for y in range(h):
            for x in range(widths[c]):im.putpixel((x,y),(raw[offsets[c]+(y//8)*widths[c]+x]>>(y%8))&1)
        out[c]=im
    return out

def vendor(name):
    p=ROOT/f'.research-work/bible-compression/reader-vendor-{name}-acceptance'
    descriptor=(p/'font-01.bin').read_bytes();h,w,stride,pad,wp,op,bp=struct.unpack('>4BIII',descriptor)
    raw=(p/'font-pixels-01.bin').read_bytes()
    original=(ROOT/f'Ghidra/Alphasmart Neo/SmartApplets/neofont{name}.os3kapp').read_bytes()
    assert raw in original
    widths=list((p/'font-widths-01.bin').read_bytes())if wp else[w]*256
    offsets=list(struct.unpack('>256H',(p/'font-offsets-01.bin').read_bytes()))if op else[c*stride for c in range(256)]
    if wp:assert bytes(widths)in original
    if op:assert(p/'font-offsets-01.bin').read_bytes()in original
    return packed_font((h,w,stride,pad),raw,widths,offsets)

def romfont():
    data=(ROOT/'Ghidra/Alphasmart Neo/SmartApplets/os3kneorom.os3kos').read_bytes();base=0x410000
    h,w,stride,pad,wp,op,bp=struct.unpack_from('>4BIII',data,0x44af8e-base)
    widths=list(data[wp-base:wp-base+256])if wp else[w]*256
    offsets=list(struct.unpack_from('>256H',data,op-base))if op else[c*stride for c in range(256)]
    return packed_font((h,w,stride,pad),data[bp-base:],widths,offsets)

def native(family):
    f=b.source(family,'R',12,75)[1];top,bottom=b.envelope([f]);out={}
    for c in b.CODES:
        ink,t,_=b.raw(f[c]);cell=Image.new('1',(ink.width,bottom-top));cell.paste(ink,(0,t-top));out[c]=cell
    return out

def main():
    rows=[('ROM system — fixed 6×16',romfont()),
          ('Vendor Small — proportional, 11px cell',vendor('small')),
          ('Vendor Medium — proportional, 13px cell',vendor('medium')),
          ('Vendor Large — proportional, 16px cell',vendor('large'))]
    terminal=b.read_font(ROOT/'betawise/fonts/BetaWiseTerminal/glyphs.bdf','iso8859-1')
    rows.append(('BetaWise Terminal — fixed 6×8',{c:g for c,g in enumerate(terminal)}))
    for title,fam in [('Times','tim'),('Century Schoolbook','ncen'),('Helvetica','helv'),('Courier','cour')]:
        rows.append((f'{title} — native 12px / 75dpi regular',native(fam)))
    im=Image.new('RGB',(1120,70+len(rows)*125),'white');d=ImageDraw.Draw(im)
    d.text((12,8),'Font roles — ROM, vendor, Terminal and X11 source artwork',font=b.TITLE,fill='black')
    d.text((12,40),'All samples enlarged 3×. Native bitmap shapes; current Neo cell normalization for X11 spacing. No glyph repairs.',font=b.SMALL,fill='#444444')
    for n,(label,font)in enumerate(rows):
        y=75+n*125;d.text((12,y),label,font=b.LABEL,fill='black')
        for i,text in enumerate(['The quick brown fox jumps over the lazy dog.', 'ijmw  Il1 O0  Reading the book: 0123456789']):
            mask=b.render_run(font,text.encode('cp1252'));assert mask.width*3<1090
            b.draw_ink(im,mask,(12,y+25+i*47),3)
    im.save(b.OUT/'family-roles-comparison.png')
    print(b.OUT/'family-roles-comparison.png')
if __name__=='__main__':main()
