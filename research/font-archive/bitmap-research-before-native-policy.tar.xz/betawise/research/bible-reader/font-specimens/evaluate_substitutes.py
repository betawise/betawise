#!/usr/bin/env python3
"""Paired Neo-cell font specimens, filtered for Western coverage and real styles.
No fonts installed or applets changed. Uses pinned local u8g2/ttyp0 sources.
"""
from pathlib import Path
from functools import lru_cache
import json,re,sys
from PIL import Image,ImageDraw
import build as b
ROOT=b.HERE.parents[3]
SOURCES=ROOT/'.research-work/u8g2-review'
BDF=SOURCES/'upstream/tools/font/bdf'
TTYP=SOURCES/'ttyp0-original/uw-ttyp0-2.1'
OUT=b.OUT/'substitutes'
UNICODE={ord(bytes([c]).decode('cp1252'))for c in b.CODES}
ASCII=set(range(32,127))
CP={ord(bytes([c]).decode('cp1252')):c for c in b.CODES}
STYLE_ORDER=['R','B','I','BI']

@lru_cache(None)
def parse(path):
    lines=Path(path).read_text(encoding='utf-8',errors='replace').splitlines();props={};glyphs={};names={};i=0
    while i<len(lines):
        parts=lines[i].split();i+=1
        if not parts:continue
        if parts[0]!='STARTCHAR':props[parts[0]]=' '.join(parts[1:]).strip('"');continue
        name=parts[1];g={}
        while True:
            parts=lines[i].split();i+=1
            if parts[0]=='BITMAP':break
            g[parts[0]]=parts[1:]
        code=int(g['ENCODING'][0]);w,h,left,bottom=map(int,g['BBX']);rows=lines[i:i+h];i+=h
        assert lines[i]=='ENDCHAR';i+=1
        points=frozenset((left+x,-bottom-h+y)for y,row in enumerate(rows)for x in range(w)
                         if int(row,16)>>(8*((w+7)//8)-1-x)&1)
        glyph=dict(points=points,advance=int(g['DWIDTH'][0]),left=left,right=left+w)
        glyphs[code]=glyph;names[name]=glyph
    return props,glyphs,names

@lru_cache(None)
def ttyp(size,style):
    suffix={'R':'','B':'b','I':'i'}[style]
    path=TTYP/f'bdf/t0-{size}{suffix}.bdf';props,_,names=parse(path);names=dict(names)
    mapping=(TTYP/'mgl/unicode.mgl').read_text()
    # Apply only the documented default aliases needed by the Western map.
    for line in mapping.splitlines():
        match=re.fullmatch(r'IFUNDEF Flag_ReorderOnly IFUNDEF (\S+) COPYTO (\S+) (\S+)',line)
        if match and match[1]not in names and match[2]in names:names[match[3]]=names[match[2]]
    for line in (TTYP/'VARIANTS.dat').read_text().splitlines():
        match=re.fullmatch(r'COPYTO (\S+) (\S+)',line.strip())
        if match and match[1]in names:names[match[2]]=names[match[1]]
    unicode={int(code,16):names[name]for name,code in re.findall(r'^PUT (\S+) (0x[0-9A-Fa-f]+)',mapping,re.M)if name in names}
    return path,unicode

def span(faces,codes=UNICODE):
    points=[(x,y)for face in faces.values()for code in codes if code in face for x,y in face[code]['points']]
    return min(y for x,y in points),max(y for x,y in points)+1

def family(name,files,license):
    faces={};paths={}
    for style,file in files.items():
        if file.startswith('ttyp:'):
            path,glyphs=ttyp(int(file.split(':')[1]),style)
        else:
            path=BDF/file;props,glyphs,_=parse(path)
            assert props.get('CHARSET_REGISTRY')=='ISO10646',path
        faces[style]=glyphs;paths[style]=str(path)
    missing={style:sorted(UNICODE-face.keys())for style,face in faces.items()}
    top,bottom=span(faces)
    return dict(name=name,faces=faces,paths=paths,missing=missing,full_western=all(not m for m in missing.values()),
                styles=list(faces),top=top,bottom=bottom,height=bottom-top,license=license)

def normalize(face,top,pitch,required=UNICODE):
    out={};changed_advances=0
    for code in required:
        glyph=face[code];shift=max(0,-glyph['left']);width=max(glyph['advance']+shift,glyph['right']+shift,1)
        if width!=glyph['advance']:changed_advances+=1
        cell=Image.new('1',(width,pitch))
        expected={(x+shift,y-top)for x,y in glyph['points']}
        for x,y in expected:
            assert 0<=x<width and 0<=y<pitch,(code,top,pitch,y)
            cell.putpixel((x,y),1)
        actual={(x,y)for y in range(pitch)for x in range(width)if cell.getpixel((x,y))}
        assert actual==expected
        out[code]=cell
    return out,changed_advances

def existing(name,paths,baseline):
    faces={}
    for style,path in paths.items():
        props,gs,_=parse(path)
        face={u:gs[c]for u,c in CP.items()}
        faces[style]=face
    top,bottom=span(faces)
    return dict(name=name,faces=faces,paths={k:str(v)for k,v in paths.items()},styles=list(faces),top=-baseline,
                bottom=bottom,height=bottom+baseline,full_western=True,license='Current project resource',missing={})

def page(face,lines,pitch):
    mask=Image.new('1',(264,65));x=0;row=0;done=[]
    for word in (b.TEXT*10).split():
        run=b.render_run(face,map(ord,word+' '))
        if x+run.width>264:x=0;row+=1
        if row>=lines:break
        bb=run.getbbox();assert row*pitch+bb[3]<=65
        mask.paste(run,(x,row*pitch));x+=run.width;done.append(word)
    assert row==lines
    return mask,' '.join(done)

def paired_card(title,left,right,lp,rp,ll,rl,note):
    # All cells displayed with identical integer scale. Both panels apply the
    # same Neo-cell bearing normalization; this is not source-advance rendering.
    lc={};rc={};width_changes={}
    for profile,cache,pitch in [(left,lc,lp),(right,rc,rp)]:
        for st,face in profile['faces'].items():
            required=UNICODE if profile['full_western'] else ASCII
            cache[st],n=normalize(face,profile['top'],pitch,required)
            width_changes[profile['name']+' '+st]=n
    sample1='Reading the book: The quick brown fox.'
    sample2='ijmw Il1 O0 0123456789' if len(left['faces'])==1 else 'ÀÉÑÖÜ Åå ß Œœ Ÿÿ Šš Žž'
    while max(b.render_run(face,map(ord,sample1)).width for group in [lc,rc]for face in group.values())*3>780:
        sample1=sample1.rsplit(' ',1)[0]
    while max(b.render_run(face,map(ord,sample2)).width for group in [lc,rc]for face in group.values())*3>780:
        sample2=sample2.rsplit(' ',1)[0]
    styles=[st for st in STYLE_ORDER if st in lc or st in rc]
    block=35+max(lp,rp)*6+12
    im=Image.new('RGB',(1700,390+len(styles)*block),'white');d=ImageDraw.Draw(im)
    d.text((12,8),title,font=b.TITLE,fill='black')
    d.text((12,40),note,font=b.SMALL,fill='#555555')
    d.text((12,62),'Same 3× display scale; each glyph is normalized to a Neo cell, so overhang padding can change source pen advances.',font=b.SMALL,fill='#555555')
    page_text=[]
    for n,(profile,cache,pitch,lines)in enumerate([(left,lc,lp,ll),(right,rc,rp,rl)]):
        x=12+n*850
        d.text((x,94),('ORIGINAL: 'if n==0 else'SUBSTITUTE: ')+profile['name'],font=b.LABEL,fill='black')
        d.text((x,119),f'{lines} lines; {pitch}px cells; native coverage/style metrics checked',font=b.SMALL,fill='#555555')
        mask,text=page(cache['R'],lines,pitch);page_text.append(text)
        b.draw_ink(im,mask,(x,148),3);d.rectangle((x-1,147,x+792,343),outline='#888888')
    for row,style in enumerate(styles):
        y=375+row*block
        for n,cache in enumerate([lc,rc]):
            x=12+n*850
            d.text((x,y),{'R':'Regular','B':'Bold','I':'Italic / oblique','BI':'Bold italic / oblique'}[style],font=b.LABEL,fill='black')
            if style not in cache:
                d.text((x,y+35),'No native face supplied; no synthetic substitute drawn.',font=b.SMALL,fill='#a02020');continue
            for i,text in enumerate([sample1,sample2]):
                mask=b.render_run(cache[style],map(ord,text))
                b.draw_ink(im,mask,(x,y+27+i*(max(lp,rp)*3+5)),3)
    return im,dict(left_page=page_text[0],right_page=page_text[1],normalized_advance_changes=width_changes,
                    displayed_styles=styles,samples=[sample1,sample2])

def main():
    OUT.mkdir(exist_ok=True)
    profiles=[]
    for pt in [8,10,12]:
        profiles +=[family(f'Lucida Sans {pt}pt',dict(zip(STYLE_ORDER,[f'{prefix}{pt:02}.bdf'for prefix in ['luRS','luBS','luIS','luBIS']])),
                          'Lucida/Sun/B&H terms: modification/trademark review before redistribution'),
                    family(f'Lucida Bright {pt}pt',dict(zip(STYLE_ORDER,[f'{prefix}{pt:02}.bdf'for prefix in ['lubR','lubB','lubI','lubBI']])),
                          'Lucida/Sun/B&H terms: modification/trademark review before redistribution')]
    for size in [16,18]:profiles.append(family(f'ttyp0 {size}px', {st:f'ttyp:{size}'for st in ['R','B','I']},'ttyp0 licence; rename modified fonts; no native bold-italic'))
    fixed={name:family('X11 Fixed '+name.removesuffix('.bdf'),{'R':name},'Public domain per BDF')for name in ['4x6.bdf','5x7.bdf','5x8.bdf','6x9.bdf','6x10.bdf']}
    for p in profiles+list(fixed.values()):
        assert p['full_western'],(p['name'],p['missing'])
    current=json.loads((b.OUT/'report.json').read_text())
    big=json.loads((b.OUT/'report.json').read_text())['three_line_comparison']
    # Existing three-line samples did not export body BDFs; recreate those exact
    # native-ASCII/local-extended candidates with the maintained generator.
    originals={}
    for entry in current['fonts']:
        if not entry['available']:continue
        family_tuple=next(f for f in b.FAMILIES if f[0]==entry['family']);_,stem,styles=family_tuple
        paths={st:b.OUT/f'{stem}-{entry["lines"]}-lines-{style}.bdf'for st,style in zip(STYLE_ORDER,styles)}
        originals[(stem,entry['lines'])]=existing(f'{entry["family"]} {entry["pixel_size"]}px / {entry["dpi"]}dpi',paths,entry['baseline'])
    # For three-line display only, keep normalized cached images instead of
    # exporting new provider resources. Unicode dictionaries share the same form.
    for title,stem,styles in b.FAMILIES:
        bodies,meta=b.body_fonts(stem,styles,21,21);faces={}
        for st,body in zip(STYLE_ORDER,bodies):
            faces[st]={u:dict(points=frozenset((x,y-meta['baseline'])for y in range(im.height)for x in range(im.width)if im.getpixel((x,y))),
                                     advance=im.width,left=0,right=im.width)for u,c in CP.items()for im in [body[c]]}
        originals[(stem,3)]=dict(name=f'{title} {meta["pixel_size"]}px / {meta["dpi"]}dpi',faces=faces,styles=list(faces),
                                paths={},top=-meta['baseline'],height=21,full_western=True,license='Current project source',missing={})
    comparisons=[];evaluations=[]
    pitch={3:21,4:16,5:13,6:11,7:9};limit={3:21,4:16,5:13,6:10,7:9}
    for stem,keyword in [('ncen','Lucida Bright'),('tim','Lucida Bright'),('helv','Lucida Sans'),('cour','ttyp0')]:
        for lines in [3,4,5,6,7]:
            if (stem,lines)not in originals:continue
            eligible=[p for p in profiles if p['name'].startswith(keyword)and all(st in p['faces']for st in ['R','B','I'])and p['height']<=limit[lines]]
            evaluations.append(dict(original=originals[(stem,lines)]['name'],lines=lines,alternatives=[p['name']for p in eligible]))
            if not eligible:continue
            right=max(eligible,key=lambda p:p['height']);left=originals[(stem,lines)]
            id=f'{stem}-{lines}-lines'
            note=f'Full 218-glyph Western coverage. Substitute ink height {right["height"]}px; '+('R/B/I only; no native bold-italic.'if'BI'not in right['faces']else'all four native faces.')
            card,metrics=paired_card(f'{lines}-line {left["name"].split(" ")[0]} alternative',left,right,pitch[lines],pitch[lines],lines,lines,note)
            card.save(OUT/f'{id}.png')
            comparisons.append(dict(id=id,left=left['name'],right=right['name'],lines=lines,pitch=pitch[lines],right_height=right['height'],
                                    right_styles=right['styles'],license=right['license'],source_paths=right['paths'],note=note,**metrics))
    for width in [6,7,8]:
        right=family(f'X11 Fixed {width}x13',{'R':f'{width}x13.bdf','B':f'{width}x13B.bdf','I':f'{width}x13O.bdf'},'Public domain per BDF; no native bold-oblique')
        assert right['full_western'] and right['height']<=13
        profiles.append(right)
        left=originals[('cour',5)];id=f'cour-5-lines-fixed-{width}x13'
        note='Full 218-glyph Western coverage; native regular, bold and oblique; no combined bold-oblique.'
        card,metrics=paired_card('Five-line Courier alternative',left,right,13,13,5,5,note)
        card.save(OUT/f'{id}.png')
        comparisons.append(dict(id=id,left=left['name'],right=right['name'],lines=5,pitch=13,right_height=right['height'],right_styles=right['styles'],license=right['license'],source_paths=right['paths'],note=note,**metrics))
    # Current Terminal's byte BDFs use a native charset, so compare ASCII only on
    # the left. Candidate eligibility still requires full Western Unicode coverage.
    for label,file,sub,pitch_value in [('Tiny 4x6','glyphs-4x6.bdf','4x6.bdf',6),('Small 5x7','glyphs-5x7.bdf','5x7.bdf',7),('Standard 6x8','glyphs.bdf','5x8.bdf',8)]:
        path=ROOT/'betawise/fonts'/file;props,gs,_=parse(path)
        left=dict(name='BetaWise Terminal '+label,faces={'R':gs},styles=['R'],top=-int(props['FONT_ASCENT']),full_western=False,paths={'R':str(path)})
        right=fixed[sub]
        assert right['height']<=pitch_value
        ll=65//pitch_value;id='terminal-'+file.removesuffix('.bdf')
        card,metrics=paired_card('Terminal-size comparison',left,right,pitch_value,pitch_value,ll,ll,
                                'Terminal exception: regular-only allowed. Proposed substitute contains all 218 checked Western characters.')
        card.save(OUT/f'{id}.png')
        lc,_=normalize(left['faces']['R'],left['top'],pitch_value,ASCII);rc,_=normalize(right['faces']['R'],right['top'],pitch_value)
        exact=sum(lc[c].size==rc[c].size and lc[c].tobytes()==rc[c].tobytes()for c in ASCII)
        def shape(im):
            box=im.getbbox()
            if box is None:return None
            g=im.crop(box);return g.size,g.tobytes()
        same_shapes=sum(shape(lc[c])==shape(rc[c])for c in ASCII)
        comparisons.append(dict(id=id,left=left['name'],right=right['name'],lines=ll,pitch=pitch_value,
                                exact_ascii_cells=exact,same_ascii_ink_shapes=same_shapes,right_styles=['R'],license=right['license'],**metrics))
    # Larger regular-only Terminal alternatives are explicitly size changes.
    for sub,pitch_value in [('6x9.bdf',9),('6x10.bdf',11)]:
        path=ROOT/'betawise/fonts/BetaWiseTerminal/glyphs.bdf';props,gs,_=parse(path)
        left=dict(name='BetaWise Terminal Standard 6x8',faces={'R':gs},styles=['R'],top=-8,full_western=False,paths={'R':str(path)})
        right=fixed[sub];id='terminal-larger-'+sub.removesuffix('.bdf')
        card,metrics=paired_card('Larger Terminal variant — height changes',left,right,8,pitch_value,8,65//pitch_value,
                                'Not an 8px drop-in: a larger regular-only Terminal size with full Western coverage.')
        card.save(OUT/f'{id}.png');comparisons.append(dict(id=id,left=left['name'],right=right['name'],lines=65//pitch_value,pitch=pitch_value,right_styles=['R'],license=right['license'],note='Changes Terminal cell height',**metrics))
    profile_metrics=[{k:v for k,v in p.items()if k!='faces'}for p in profiles+list(fixed.values())]
    report=dict(scope='Full Western = 218 printable CP1252 Unicode characters, not all Neo control/device glyphs',
                filters='Western coverage required; R/B/I required for Adobe substitutions; regular-only allowed for Terminal',
                comparisons=comparisons,profiles=profile_metrics,evaluations=evaluations,
                excluded=[dict(font='ProFont',reason='No native italic in supplied family; extended encoding unverified'),
                          dict(font='Spleen',reason='Inspected sources lack some required Western glyphs'),
                          dict(font='Small ttyp0 / Fixed',reason='No italic: only eligible as Terminal alternatives')],
                validation=dict(passed=True,paired_specimens=len(comparisons),full_western_per_candidate=True,no_glyph_resizing=True,
                                qualifier='Exact bitmaps/coverage/geometry checked; no automated readability claims or production installation'))
    (OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    # Regular-only contact sheet. Full cards show every source style and screens.
    thumbs=[]
    for entry in comparisons:
        source=Image.open(OUT/f'{entry["id"]}.png')
        # Keep the already rendered original-left/substitute-right headers/screens.
        thumbs.append(source.crop((0,85,1700,350)))
    contact=Image.new('RGB',(1700,70+len(thumbs)*285),'white');d=ImageDraw.Draw(contact)
    d.text((12,10),'Qualified substitutes — current choice LEFT, proposed alternative RIGHT',font=b.TITLE,fill='black')
    for i,thumb in enumerate(thumbs):contact.paste(thumb,(0,70+i*285))
    contact.save(OUT/'overview.png')
    sections=[]
    for e in comparisons:
        flag='; no bold-italic face'if e['right_styles']==['R','B','I']else''
        sections.append(f'<section><h2>{e["left"]} → {e["right"]}</h2><p>{e["lines"]} lines, {e["pitch"]}px target cells{flag}. {e["license"]}.</p><a href="{e["id"]}.png"><img loading="lazy" src="{e["id"]}.png"></a></section>')
    (OUT/'index.html').write_text('''<!doctype html><meta charset="utf-8"><title>Filtered font substitutes</title>
<style>body{font:16px sans-serif;max-width:1720px;margin:24px auto;padding:0 16px}img{max-width:100%;height:auto;image-rendering:pixelated;border:1px solid #ddd}section{margin:36px 0}a{color:#154f92}</style>
<h1>Original left / proposed substitute right</h1><p>All proposed substitutes pass the 218-glyph Western coverage check. Adobe-family alternatives have native regular, bold and italic; ttyp0 lacks a combined bold-italic face and is explicitly labelled. Only Terminal alternatives may be regular-only. Lucida comparisons are visual candidates with a licence review outstanding.</p>
<p>Both columns use the same glyph-to-Neo-cell bearing normalization. No glyph is resized or trimmed; source overhangs may expand advances. Same text starts and 264×65 page bounds; shorter text samples are identical within each pair.</p>
<p>Left Adobe choices are the current ASCII-first selected candidates, including their existing local extended repairs. Three-line choices are recreated with the same generator. Current Terminal Tiny/Small/Standard are the actual project BDFs. Original Terminal samples are ASCII only because their extended mapping is a separate audit.</p>
<p>No qualifying native styled six-/seven-line substitute was found in this shortlist. Fixed 6×9/6×10 are shown only as larger Terminal variants.</p>'''+''.join(sections)+'<p><a href="report.json">Coverage, selections, exact Terminal comparisons and source paths</a></p>')
    print(json.dumps(report['validation'],indent=2))
    for e in comparisons:print(e['id'],e['left'],'=>',e['right'],e.get('exact_ascii_cells',''),e.get('same_ascii_ink_shapes',''))
    print(OUT/'index.html')
if __name__=='__main__':main()
