#!/usr/bin/env python3
"""Eight original-PCF Courier O/BO glyph cards, with exact visible overhang."""
from pathlib import Path
import json,shutil,hashlib
from PIL import Image,ImageDraw,ImageFont
import build as b
from courier_sweep import candidate
OUT=b.HERE/'courier-stock'
SCALE=4

def main():
 OUT.mkdir(exist_ok=True);shutil.copyfile(b.OUT/'FONT-LICENSE.txt',OUT/'FONT-LICENSE.txt')
 # Use the same nominal source strikes, widths and baseline placements as picker.
 sweep=json.loads((b.HERE/'courier-sweep/data.json').read_text());entries=[]
 small=ImageFont.truetype(b.FONT,12)
 for lines in [3,4,5,6]:
  size=sweep['sizes'][str(lines)];width=size['width'];pitch=size['height'];baseline=size['baseline'];limit=10 if lines==6 else pitch
  for st,title in [('O','Oblique'),('BO','Bold oblique')]:
   path=Path(next(p for p in size['source_paths']if Path(p).name.startswith('cour'+st)and Path(p).name[len('cour'+st)].isdigit()))
   # Raw original source, not the vertically/horizontally repaired BDF exports.
   import gzip
   from PIL import PcfFontFile
   with gzip.open(path,'rb')as stream:font=PcfFontFile.PcfFontFile(stream,charset_encoding='cp1252')
   glyphs={};records=[];ys=[]
   for code in b.CODES:
    advance,box,src,bitmap=font.glyph[code];left,top,right,bottom=box;ink=bitmap.crop(src)
    points={(x+left,y+top)for y in range(ink.height)for x in range(ink.width)if ink.getpixel((x,y))}
    info=candidate(points,width,baseline,None)
    assert len(info['points'])==len(points)
    # One constant horizontal placement only. Original y and row pixels retained.
    assert set(map(tuple,info['points']))=={(x+info['offset'],y)for x,y in points}
    glyphs[code]=info;ys.extend(y+baseline for x,y in info['points'])
    outside=[(x,y)for x,y in info['points']if not 0<=x<width or not 0<=y+baseline<limit]
    records.append(dict(slot=f'{code:02X}',character=bytes([code]).decode('cp1252'),source_advance=advance[0],offset=info['offset'],pixels=len(points),red_pixels=outside))
   top_pad=max(2,-min(ys)+1);bottom_pad=max(2,max(ys)-pitch+2)
   xpad=4;cw=(width+2*xpad)*SCALE+6;ch=(pitch+top_pad+bottom_pad)*SCALE+40
   image=Image.new('RGB',(40+32*cw,140+8*ch),'white');d=ImageDraw.Draw(image)
   d.text((12,8),f'Stock Courier {title} — {lines} lines / {width}px cells / {264//width} columns',font=b.TITLE,fill='black')
   d.text((12,40),'Original Adobe X11 bitmap ink, 4× nearest-neighbour. No shear, pixel deletion, accent repair or resampling.',font=b.SMALL,fill='#444444')
   d.text((12,62),'Black: inside usable cell. Red: outside width or vertical ink budget. A single horizontal glyph placement matches the sweep policy.',font=b.SMALL,fill='#444444')
   d.text((12,84),f'Gray: outside the 218 printable Western slots. '+('Six-line final cell row is reserved blank.'if lines==6 else''),font=b.SMALL,fill='#555555')
   for col in range(32):d.text((40+col*cw+6,115),f'{col:02X}',font=small,fill='#555555')
   for row in range(8):d.text((4,150+row*ch),f'{row*32:02X}',font=small,fill='#555555')
   for code in range(256):
    x=40+code%32*cw;y=140+code//32*ch
    d.rectangle((x,y,x+cw-1,y+ch-1),fill='white'if code in glyphs else'#e8ebee',outline='#cccccc')
    d.text((x+3,y+3),f'{code:02X}',font=small,fill='#555555')
    if code not in glyphs:continue
    ox=x+xpad*SCALE;oy=y+23+top_pad*SCALE
    if lines==6:d.rectangle((ox,oy+limit*SCALE,ox+width*SCALE-1,oy+pitch*SCALE-1),fill='#eeeeee')
    d.rectangle((ox-1,oy-1,ox+width*SCALE,oy+pitch*SCALE),outline='#aaaaaa')
    info=glyphs[code];shown=0
    for xx,yy in info['points']:
     px=ox+xx*SCALE;py=oy+(yy+baseline)*SCALE
     assert x<px and px+SCALE<x+cw and y<py and py+SCALE<y+ch,(lines,st,code,px,py)
     color='#c02b23'if not 0<=xx<width or not 0<=yy+baseline<limit else'black'
     d.rectangle((px,py,px+SCALE-1,py+SCALE-1),fill=color);shown+=1
    assert shown==len(info['points'])
    red=next(r['red_pixels']for r in records if r['slot']==f'{code:02X}')
    if red:d.text((x+3,y+ch-15),f'{len(red)} red',font=small,fill='#b02020')
   file=f'courier-{lines}-lines-{st}.png';image.save(OUT/file)
   entries.append(dict(lines=lines,style=st,title=title,width=width,height=pitch,ink_budget=limit,baseline=baseline,source=str(path),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),file=file,glyphs=records))
 report=dict(scope='Eight stock Courier O/BO cards at 3/4/5/6 lines; all 218 printable Western glyphs per card, no invented Neo device/control glyphs.',difference_from_sweep='These cards read raw PCF ink, including original vertical accent overflow. Sweep references inherited prior vertical extended repairs. All pixels outside the usable width/height budget are red here.',validation=dict(cards=8,glyphs_verified=8*len(b.CODES),source_row_pixels_preserved=True,all_red_pixels_visible=True),cards=entries)
 (OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
 sections=''.join(f'<h2>{e["lines"]} lines — {e["title"]}</h2><a href="{e["file"]}"><img loading="lazy" src="{e["file"]}"></a>'for e in entries)
 (OUT/'index.html').write_text('<!doctype html><meta charset="utf-8"><title>Stock Courier oblique cards</title><style>body{font:17px sans-serif;margin:24px}img{max-width:100%;image-rendering:pixelated}h2{margin-top:40px}</style><h1>Stock Courier — eight complete glyph cards</h1><p>3/4/5/6 lines, oblique and bold-oblique. Click an image for full resolution. Each is a 32×8 byte-position card with all 218 Western glyphs. Gray slots are outside that repertoire.</p><p>Original PCF artwork, including unmodified accents. Red marks ink outside the same +1px-wide cell or usable vertical budget. A constant horizontal placement is allowed as in the sweep; no row shifts, clipping or glyph repair. Six-line row 10 is reserved blank. Previous sweep references inherited vertical accent repairs; these cards show those original overflows as well.</p>'+sections+'<p><a href="report.json">Source hashes and every red pixel</a></p>')
 print(json.dumps(report['validation']));print(OUT/'index.html')
if __name__=='__main__':main()
