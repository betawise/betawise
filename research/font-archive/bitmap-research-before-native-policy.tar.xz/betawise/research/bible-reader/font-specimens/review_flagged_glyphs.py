#!/usr/bin/env python3
"""Compare flagged BDF source artwork against original strikes; no LCD capture."""
import gzip
import json
import sys
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont
from verify_charset_review import UnicodePCF

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).with_name('glyph-fixes-review')
sys.path.insert(0, str(ROOT / 'fonts'))
sys.path.insert(0, str(ROOT / 'os3k'))
import fontgen
from charsets import load

STYLES = ['Regular', 'Bold', 'Italic', 'BoldItalic']
STEMS = {'Book':'ncen', 'Mono':'cour', 'Serif':'tim', 'Sans':'helv'}
LABEL = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 15)
TITLE = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 21)


def points(glyph):
    if glyph is None:
        return set()
    advance, (left, top, right, bottom), box, bitmap = glyph
    bitmap = bitmap.crop(box)
    shift = max(0, -left)
    return {(x+left+shift,y+top) for y in range(bitmap.height) for x in range(bitmap.width)
            if bitmap.getpixel((x,y))}


def draw_points(image, pts, x, y, top=-12, scale=5, color='black'):
    draw = ImageDraw.Draw(image)
    for xx, yy in pts:
        draw.rectangle((x+xx*scale,y+(yy-top)*scale,x+(xx+1)*scale-1,y+(yy-top+1)*scale-1),fill=color)


def reference(path, codes):
    UnicodePCF.candidates = codes
    with gzip.open(path, 'rb') as stream:
        font = UnicodePCF(stream)
    assert font.info[b'CHARSET_REGISTRY'] == b'ISO10646'
    return {code:font.glyph[i] for i,code in enumerate(codes)}


def main():
    review = json.loads((OUT/'submitted-review.json').read_text())
    mapping = load(ROOT/'os3k/charsets/neo-us.txt')
    codes = sorted(set(mapping.values()) | {0x0144})
    records = []
    reader_items = [g for g in review['glyphs'] if g['family'] != 'BetaWise Terminal']
    card = Image.new('RGB', (1400,110+len(reader_items)*145),'white')
    d=ImageDraw.Draw(card)
    d.text((14,8),'Flagged reader glyphs: native source → current, all four styles',font=TITLE,fill='black')
    d.text((14,40),'Exact pixels at 5×; each pair shares its current baseline. Red = removed source pixels; blue = added pixels.',font=LABEL,fill='#444444')
    for col, style in enumerate(STYLES):d.text((165+col*300,75),style,font=LABEL,fill='black')
    for row,item in enumerate(reader_items):
        y=110+row*145;slot=item['slot'];family=item['family'].split()[-1]
        d.text((12,y+18),f'{family} {slot:02X} {chr(mapping[slot])}',font=LABEL,fill='black')
        for col,style in enumerate(STYLES):
            path=ROOT/'fonts'/item['font'].replace('-Regular.bdf',f'-{style}.bdf')
            raw,asc,desc=fontgen.load_bdf(path)
            text=path.read_text();import re
            pt=int(re.search(r'^POINT_SIZE (\d+)$',text,re.M)[1])//10
            dpi=int(re.search(r'^RESOLUTION_Y (\d+)$',text,re.M)[1])
            st={'Regular':'R','Bold':'B','Italic':'I','BoldItalic':'BI'}[style]
            if family in ['Mono','Sans']:st=st.replace('I','O')
            source=Path('/usr/share/fonts/X11')/f'{dpi}dpi'/f'{STEMS[family]}{st}{pt:02}.pcf.gz'
            native=reference(source,codes)[mapping[slot]]
            a=points(native) if native else set();b=points(raw[slot])
            # Assess whether a pure translation explains differences before alleging clipping.
            alignments=[(len({(xx+dx,yy+dy)for xx,yy in a}&b),dx,dy)for dx in range(-3,4)for dy in range(-3,4)]
            _,dx,dy=max(alignments,key=lambda p:(p[0],-abs(p[1])-abs(p[2])))
            shifted={(xx+dx,yy+dy)for xx,yy in a}
            rec=dict(font=str(path.relative_to(ROOT)),slot=f'{slot:02X}',source=str(source),
                source_pixels=len(a),current_pixels=len(b),source_available=native is not None,implemented=raw[slot] is not None,exact=a==b,
                best_translation=[dx,dy],removed=sorted(shifted-b),added=sorted(b-shifted),
                source_outside_current_height=sorted((xx,yy)for xx,yy in a if yy < -asc or yy>=desc))
            records.append(rec)
            x=170+col*300
            draw_points(card,a,x,y,top=-asc)
            draw_points(card,b,x+110,y,top=-asc)
            draw_points(card,shifted-b,x+110,y,top=-asc,color='#d02020')
            draw_points(card,b-shifted,x+110,y,top=-asc,color='#126dcc')
            label='missing' if raw[slot] is None else 'native exact' if a==b else f'Δ({dx},{dy}) −{len(shifted-b)} +{len(b-shifted)}'
            d.text((x,y+100),label,font=LABEL,fill='#555555')
        d.line((0,y+138,1400,y+138),fill='#cccccc')
    card.save(OUT/'reader-source-comparison.png')
    terminal_items=[g for g in review['glyphs'] if g['family']=='BetaWise Terminal']
    original={size:reference(Path('/usr/share/fonts/X11/misc')/f'{size}.pcf.gz',codes)for size in ['5x7','5x8']}
    raw,asc,desc=fontgen.load_bdf(ROOT/'fonts/BetaWiseTerminal/glyphs-5x7.bdf')
    card=Image.new('RGB',(1380,95+((len(terminal_items)+5)//6)*245),'white');d=ImageDraw.Draw(card)
    d.text((12,8),'Terminal Small — current / original 5×7 / alternative 5×8',font=TITLE,fill='black')
    d.text((12,40),'Exact source pixels at 4×. Equal artwork after a vertical shift means no clipping in our conversion.',font=LABEL,fill='#444444')
    for index,item in enumerate(terminal_items):
        slot=item['slot'];x=10+index%6*230;y=95+index//6*245
        d.text((x,y),f'{slot:02X} {chr(mapping[slot])}',font=TITLE,fill='black')
        current=points(raw[slot]);native=points(original['5x7'][mapping[slot]])
        matches=[(dx,dy)for dx in range(-2,3)for dy in range(-3,4)if {(xx+dx,yy+dy)for xx,yy in native}==current]
        records.append(dict(font='fonts/BetaWiseTerminal/glyphs-5x7.bdf',slot=f'{slot:02X}',
                            equal_native_under_translation=matches,source_pixels=len(native),current_pixels=len(current)))
        for row,(label,g) in enumerate([('current',raw[slot]),('5×7',original['5x7'][mapping[slot]]),('5×8',original['5x8'][mapping[slot]])]):
            d.text((x,y+40+row*60),label,font=LABEL,fill='#555555')
            draw_points(card,points(g),x+100,y+33+row*60,top=-8,scale=4)
    card.save(OUT/'terminal-small-source-comparison.png')
    (OUT/'source-audit.json').write_text(json.dumps(records,indent=2)+'\n')
    for r in records:
        if 'exact'in r:print(Path(r['font']).name,r['slot'],'exact',r['exact'],'shift',r['best_translation'],'removed',len(r['removed']),'added',len(r['added']))
        else:print('Terminal',r['slot'],'native equality',r['equal_native_under_translation'])


if __name__=='__main__':main()
