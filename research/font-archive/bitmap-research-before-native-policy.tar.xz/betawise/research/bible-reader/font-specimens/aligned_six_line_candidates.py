#!/usr/bin/env python3
"""Native 8px six-line candidates: shared baseline and local mark moves only."""
import json
from PIL import Image,ImageDraw
import build as b
CASES=[('Courier','cour',('R','B','O','BO')),
       ('Century Schoolbook','ncen',('R','B','I','BI')),
       ('Helvetica','helv',('R','B','O','BO'))]
TOP=-8
PITCH=11
LIMIT=10

def fit(face,family,style,code):
    width,original=b.extended_fit.pixels(face[code])
    if not original:return Image.new('1',(width,PITCH)),None
    if min(y for x,y in original)>=TOP and max(y for x,y in original)<TOP+LIMIT:
        return b.extended_fit.image(width,PITCH,original,TOP),None
    assert min(y for x,y in original)==-9 and max(y for x,y in original)<2
    standalone=code in(0x60,0x88,0x98)
    if standalone:
        upper=original;base=set();cut=None
        method='standalone accent moved down 1px'
    else:
        rows={y for x,y in original}
        gaps=[y for y in range(min(rows)+1,max(rows))if y not in rows]
        if gaps:
            cut=gaps[0]+1
            method='accent moved down 1px into existing gap'
        else:
            # These marks have no separator row. Their bottom tip can share a
            # native letter pixel, keeping the entire letter body unchanged.
            assert (family=='helv'and code==0xc5)or(family=='ncen'and style=='BI'and code in(0x8a,0x8e)),(family,style,code)
            cut=-6
            method='accent moved down 1px; tip shares native letter pixel'
        upper={(x,y)for x,y in original if y<cut};base=original-upper
    moved={(x,y+1)for x,y in upper}
    result=base|moved
    assert min(y for x,y in result)>=TOP and max(y for x,y in result)<TOP+LIMIT
    if cut is not None:assert {(x,y)for x,y in result if y>=cut}==base
    # No clipping or resampling: any ink count reduction is only shared pixels.
    assert len(result)==len(original)-len(moved&base)
    assert width==b.extended_fit.pixels(face[code])[0]
    record=dict(code=f'{code:02X}',character=bytes([code]).decode('cp1252'),style=style,method=method,
                shared_tip_pixels=len(moved&base),base_letter_pixels_unchanged=not standalone,
                source_pixels=len(original),candidate_pixels=len(result),advance_unchanged=True)
    return b.extended_fit.image(width,PITCH,result,TOP),record

def padded(face,codes,source=False):
    result={};height=18;pad=4
    for c in codes:
        if source:
            width,points=b.extended_fit.pixels(face[c]);canvas=b.extended_fit.image(width,height,points,TOP-pad)if points else Image.new('1',(width,height))
        else:
            canvas=Image.new('1',(face[c].width,height));canvas.paste(face[c],(0,pad))
        result[c]=canvas
    return result

def context(title,family,styles,faces,bodies,changes):
    samples=['Agjpqy ÀÁÄÅ ÉÊÏ Ññ ÖØ Ü Ý ŠŽ šž ˆ˜`',
             'Señor, mañana, déjà vu. Reading the book.']
    codes=set(''.join(samples).encode('cp1252'))
    line=57;block=38+line*4
    im=Image.new('RGB',(1120,85+4*block),'white');d=ImageDraw.Draw(im)
    d.text((12,8),f'{title} 8px — shared baseline, no face shifts',font=b.TITLE,fill='black')
    d.text((12,39),'Original / candidate at 3×. Gray: allowed ten ink rows. Blue: original shared baseline. Only overflowing marks are moved.',font=b.SMALL,fill='#444444')
    for index,style in enumerate(styles):
        y=75+index*block
        edited=[c['character']for c in changes if c['style']==style]
        d.text((12,y),style+' — '+('local edits: '+' '.join(edited)if edited else 'unchanged'),font=b.LABEL,fill='black')
        original=padded(faces[index],codes,True);after=padded(bodies[index],codes)
        for version,face in enumerate([original,after]):
            for row,text in enumerate(samples):
                yy=y+27+(version*2+row)*line
                mask=b.render_run(face,text.encode('cp1252'));assert mask.width*3<=1000
                d.text((12,yy+12),'Original'if version==0 else'Candidate',font=b.SMALL,fill='#444444')
                d.rectangle((100,yy+12,100+mask.width*3,yy+42-1),fill='#eeeeee')
                d.line((100,yy+36,100+mask.width*3,yy+36),fill='#bed4eb')
                b.draw_ink(im,mask,(100,yy),3)
    return im

def glyph_grid(title,styles,faces,bodies,changes):
    codes=sorted({int(c['code'],16)for c in changes});columns=min(10,len(codes));rows=(len(codes)+columns-1)//columns
    width=max(760,120+columns*100);block=35+rows*105
    im=Image.new('RGB',(width,85+4*block),'white');d=ImageDraw.Draw(im)
    d.text((12,8),title+' 8px — local mark edits only',font=b.TITLE,fill='black')
    d.text((12,39),'Source left / candidate right, 3×. Letter bodies and original baselines stay fixed.',font=b.SMALL,fill='#444444')
    lookup={(c['style'],int(c['code'],16)):c for c in changes}
    for index,style in enumerate(styles):
        sy=75+index*block;d.text((12,sy+22),style,font=b.LABEL,fill='black')
        source=padded(faces[index],codes,True);after=padded(bodies[index],codes)
        for n,c in enumerate(codes):
            x=85+(n%columns)*100;y=sy+(n//columns)*105
            d.rectangle((x,y,x+97,y+101),outline='#dddddd')
            d.text((x+3,y+2),f'{bytes([c]).decode("cp1252")} · {c:02X}',font=b.SMALL,fill='#444444')
            for xx,mask in [(x+4,source[c]),(x+53,after[c])]:
                d.rectangle((xx,y+22+12,xx+39,y+22+42-1),fill='#eeeeee')
                b.draw_ink(im,mask,(xx,y+22),3)
            entry=lookup.get((style,c))
            label='unchanged'if entry is None else 'shared tip'if entry['shared_tip_pixels']else 'mark ↓1'
            d.text((x+3,y+83),label,font=b.SMALL,fill='#666666')
    return im

def main():
    b.OUT.mkdir(exist_ok=True)
    report=dict(scope='218 printable Windows-1252 glyphs; Neo device/control symbols are outside the mapped repertoire',
                pitch=PITCH,ink_budget=LIMIT,shared_baseline_row=8,faces=[],validation={})
    overview=Image.new('RGB',(1692,445),'white');d=ImageDraw.Draw(overview)
    d.text((12,8),'Six-line native 8px alternatives — aligned baselines, local accent fixes',font=b.TITLE,fill='black')
    d.text((12,39),'All four faces retain their native positions. Only overflowing marks change. Each 11px cell ends with a guaranteed blank row.',font=b.SMALL,fill='#444444')
    html=[];counts={};verified=0;ascii_edited=[]
    for col,(title,family,styles)in enumerate(CASES):
        bodies=[];faces=[];changes=[]
        for style in styles:
            path,face=b.source(family,style,8,75);faces.append(face);body={}
            for c in b.CODES:
                cell,change=fit(face,family,style,c);body[c]=cell;verified+=1
                width,points=b.extended_fit.pixels(face[c]);actual={(x,y+TOP)for y in range(PITCH)for x in range(width)if cell.getpixel((x,y))}
                assert cell.width==width
                assert not any(cell.getpixel((x,10))for x in range(width))
                if change:
                    changes.append(change)
                    if c<128:ascii_edited.append(dict(family=title,**change))
                else:assert actual==points
            # All ordinary letters and their descenders must stay at source coordinates.
            for c in list(range(65,91))+list(range(97,123)):
                width,points=b.extended_fit.pixels(face[c]);actual={(x,y+TOP)for y in range(PITCH)for x in range(width)if body[c].getpixel((x,y))}
                assert actual==points
            glyphs=[Image.new('1',(1,PITCH))for _ in range(256)]
            for c,cell in body.items():glyphs[c]=cell
            b.export_bdf(b.OUT/f'aligned6-{family}-{style}.bdf',glyphs,8)
            bodies.append(body)
            report['faces'].append(dict(family=title,style=style,source=str(path),face_shift=0,
                                        edited_glyphs=[c for c in changes if c['style']==style]))
        counts[title]=dict(unique_characters=len({c['code']for c in changes}),glyph_edits=len(changes))
        context(title,family,styles,faces,bodies,changes).save(b.OUT/f'aligned6-{family}-before-after.png')
        glyph_grid(title,styles,faces,bodies,changes).save(b.OUT/f'aligned6-{family}-glyph-edits.png')
        x=12+564*col
        d.text((x,76),f'{title} — 8px / 75dpi; six lines',font=b.LABEL,fill='black')
        page,text=b.page(bodies[0],6,11);b.draw_ink(overview,page,(x,111),2)
        d.rectangle((x-1,110,x+528,241),outline='#999999')
        d.text((x,253),f"{counts[title]['unique_characters']} character codes adjusted; no baseline stagger",font=b.SMALL,fill='#444444')
        text='Regular Bold Italic BoldItalic Regular';parts=[(0,'Regular '),(1,'Bold '),(2,'Italic '),(3,'BoldItalic '),(0,'Regular')]
        mask=Image.new('1',(sum(sum(bodies[i][c].width for c in s.encode('cp1252'))for i,s in parts),11));px=0
        for i,s in parts:
            run=b.render_run(bodies[i],s.encode('cp1252'));mask.paste(run,(px,0));px+=run.width
        assert mask.width*2<=528
        d.text((x,291),'Mixed faces (2×):',font=b.SMALL,fill='#444444');d.line((x,331,x+mask.width*2,331),fill='#bed4eb');b.draw_ink(overview,mask,(x,315),2)
        html.append(f'<h2>{title}</h2><a href="aligned6-{family}-before-after.png"><img src="aligned6-{family}-before-after.png"></a><p><a href="aligned6-{family}-glyph-edits.png">Every local mark edit, source / candidate</a></p>')
    assert len(ascii_edited)==2 and all(c['family']=='Courier'and c['code']=='60'and c['style']in('B','BO')for c in ascii_edited)
    report['counts']=counts
    report['validation']=dict(passed=True,glyphs_verified=verified,bdf_roundtrips=12,
                               whole_font_rescalings=0,individual_glyph_rescalings=0,face_shifts=0,
                               letter_bodies_unchanged=True,descenders_unchanged=True,last_cell_row_always_blank=True,
                               ascii_edits=ascii_edited)
    overview.save(b.OUT/'aligned6-three-family-overview.png')
    (b.OUT/'aligned6-report.json').write_text(json.dumps(report,indent=2)+'\n')
    (b.OUT/'aligned6-index.html').write_text('''<!doctype html><meta charset="utf-8"><title>Six-line aligned baseline candidates</title>
<style>body{font:16px sans-serif;max-width:1140px;margin:24px auto}img{max-width:100%;height:auto;image-rendering:pixelated}</style>
<h1>Six-line 8px candidates, aligned baselines</h1><p>No face shifts, no glyph resampling, no changes to letter bodies or descenders. Only over-height accents/spacing marks move down one pixel. Some ring/caron tips share a native letter pixel; these remain review candidates.</p>
<p>The only ASCII edits are Courier bold and bold-oblique grave accents (60). Their standalone drawings move down one row; letters retain exact native pixels and positions. Every cell ends with a guaranteed blank row, so all six lines fit within 65 screen rows.</p>
<img src="aligned6-three-family-overview.png">'''+''.join(html)+'<p><a href="aligned6-report.json">Exact code/style edit inventory and checks</a></p>')
    print(json.dumps({'counts':counts,'validation':report['validation']},indent=2))
if __name__=='__main__':main()
