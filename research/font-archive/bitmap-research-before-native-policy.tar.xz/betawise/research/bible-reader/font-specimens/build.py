#!/usr/bin/env python3
"""Offline X11 candidate fonts and exact-pixel review specimens, no applet install."""
import gzip
import html
import json
from pathlib import Path
import sys
from functools import lru_cache
from PIL import Image, ImageDraw, ImageFont, PcfFontFile

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parents[2] / 'fonts'))
from fontgen import load as read_font
import audit_strikes
import extended_fit
OUT = HERE / 'build'
FAMILIES = [('Century Schoolbook','ncen',('R','B','I','BI')),
            ('Helvetica','helv',('R','B','O','BO')),
            ('Times','tim',('R','B','I','BI')),
            ('Courier','cour',('R','B','O','BO'))]
SIZES = [(4,16,16),(5,13,13),(6,11,10),(7,9,9)]
@lru_cache(None)
def strike_options(family):
    xname={'ncen':'new century schoolbook','helv':'helvetica','tim':'times','cour':'courier'}[family]
    options=set()
    for index in Path('/usr/share/fonts/X11').glob('*/fonts.dir'):
        for line in index.read_text().splitlines()[1:]:
            filename,xlfd=line.split(' ',1);f=xlfd.split('-')
            if len(f)>=15 and f[1]=='adobe' and f[2]==xname and f[3]=='medium' and f[4]=='r' and f[13:]==['iso10646','1']:
                options.add((int(f[8])//10,int(f[9]),int(f[7])))
    assert options
    return sorted(options,key=lambda x:(x[2],x[1]))
CODES = list(range(32,127)) + [c for c in range(128,256) if c not in (0x81,0x8d,0x8f,0x90,0x9d)]
ENC = json.loads((HERE/'encoding.json').read_text())
TRIPLES = {int(r,16): {s:int(v,16) for s,v in row.items()} for r,row in ENC['style_triples'].items()}
REGULAR = sorted(TRIPLES)
RED = {int(c,16) for c in ENC['red_slots']}
DIGITS = set(range(0x30,0x3a))
FONT = '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
LABEL = ImageFont.truetype(FONT,16)
SMALL = ImageFont.truetype(FONT,13)
TITLE = ImageFont.truetype(FONT,22)
TEXT = ('In the beginning God created the heaven and the earth. '
        'And the earth was without form, and void; and darkness was upon the face of the deep. '
        'And the Spirit of God moved upon the face of the waters. '
        'And God said, Let there be light: and there was light. ')
ACCENT_TEXT = 'Señor: À É Î Ö Ü Ç Æ Œ Š Ž Ÿ; 0123456789.'

@lru_cache(None)
def source(family, style, points, dpi=75):
    path=(Path('/usr/share/fonts/X11')/f'{dpi}dpi')/f'{family}{style}{points:02}.pcf.gz'
    with gzip.open(path,'rb') as stream:
        font=PcfFontFile.PcfFontFile(stream,charset_encoding='cp1252')
    assert font.info[b'CHARSET_REGISTRY']==b'ISO10646'
    assert all(font.glyph[c] is not None for c in CODES),path
    return path,font.glyph

def raw(glyph):
    advance,box,src,bitmap=glyph
    left,top,right,bottom=box
    shift=max(0,-left)
    width=max(advance[0]+shift,right+shift,1)
    ink=Image.new('1',(width,max(1,bottom-top)))
    ink.paste(bitmap.crop(src),(left+shift,0))
    return ink,top,bottom

def envelope(faces,codes=CODES):
    spans=[]
    for face in faces:
        for c in codes:
            ink,top,_=raw(face[c]);box=ink.getbbox()
            if box:spans.append((top+box[1],top+box[3]))
    return min(t for t,b in spans),max(b for t,b in spans)

def reduce_mask(im,size):
    return im.convert('L').resize(size,Image.Resampling.BOX).point(lambda p:255 if p>=64 else 0,'1')

def bbox(im):
    assert im.getbbox()
    return im.getbbox()

def body_fonts(family,styles,limit,pitch):
    candidates=[]
    for pt,dpi,pixels in strike_options(family):
        faces=[source(family,s,pt,dpi)[1] for s in styles]
        top,bottom=envelope(faces,range(32,127))
        candidates.append((pt,faces,top,bottom,dpi,pixels))
    fitting=[c for c in candidates if c[3]-c[2]<=limit]
    if not fitting:
        return None,dict(pitch=pitch,body_ink_budget=limit,available=False,
                         minimum_native_ascii_height=min(c[3]-c[2]for c in candidates),
                         method='No native ASCII strike fits; no ASCII changes or whole-font rescaling')
    pt,faces,ascii_top,bottom,dpi,pixels=max(fitting,key=lambda x:(x[5],x[3]-x[2],x[4]))
    # Spend any unused rows above ASCII, where accents need them; preserve the
    # shared baseline and every source pixel. This avoids gratuitous repairs.
    top=bottom-limit
    bodies=[];changes=[];ascii_verified=0;untouched_extended=0
    for style,face in zip(styles,faces):
        result={}
        for code in CODES:
            cell,change=extended_fit.fit(face[code],face,code,top,limit,pitch)
            result[code]=cell
            width,points=extended_fit.pixels(face[code])
            assert cell.width==width
            actual={(x,y+top)for y in range(cell.height)for x in range(cell.width)if cell.getpixel((x,y))}
            if code<128:
                assert change is None and actual==points
                ascii_verified+=1
            elif change is None:
                assert actual==points
                untouched_extended+=1
            else:changes.append(dict(style=style,**change))
            assert not cell.getbbox()or bbox(cell)[3]<=limit
        bodies.append(result)
    assert ascii_verified==95*4
    return bodies,dict(points=pt,dpi=dpi,pixel_size=pixels,source_ink_height=bottom-ascii_top,
                        body_ink_budget=limit,pitch=pitch,body_scale=1,baseline=-top,available=True,
                        coverage='Windows-1252 glyph repertoire; only overflowing extended glyphs adjusted',
                        method='native ASCII; local extended-glyph repairs',ascii_glyphs_verified=ascii_verified,
                        unmodified_extended_glyphs=untouched_extended,extended_adjustments=changes,
                        adjusted_extended_characters=len({c['code']for c in changes}))

def duplicate_groups(caps):
    groups={}
    for c,g in caps.items():
        groups.setdefault((g.size,g.tobytes()),[]).append(c)
    return [[f'{c:02X}' for c in group] for group in groups.values() if len(group)>1]

def smallcaps(family,styles,bodies,points,pitch,limit):
    all_caps=[];notes=[]
    for style,body in zip(styles[:3],bodies[:3]):
        target=bbox(body[ord('x')]);target_top,target_bottom=target[1],target[3]
        xheight=target_bottom-target_top
        strikes=[]
        for pt,dpi,pixels in strike_options(family):
            g=source(family,style,pt,dpi)[1]
            ink,t,_=raw(g[ord('H')]);box=bbox(ink)
            ht=t+box[1];hb=t+box[3]
            strikes.append((abs((hb-ht)-xheight),pt,g,ht,hb,dpi,pixels))
        _,pt,g,ht,hb,dpi,pixels=min(strikes,key=lambda v:(v[0],v[4]-v[3]<xheight,v[6],v[5]))
        scale=xheight/(hb-ht)
        caps={};constrained=[]
        for c in REGULAR:
            if c==0xd7:
                ink,t,b=raw(g[ord('S')]);ss=Image.new('1',(ink.width*2,ink.height))
                ss.paste(ink,(0,0));ss.paste(ink,(ink.width,0));ink=ss
            else:ink,t,b=raw(g[c])
            top=min(t,ht);bottom=max(b,hb)
            canvas=Image.new('1',(ink.width,bottom-top));canvas.paste(ink,(0,t-top))
            width=max(1,round(ink.width*scale))
            above=ht-top;below=bottom-hb
            upper=0 if not above else max(1,round(above*scale))
            lower=0 if not below else max(1,round(below*scale))
            if upper>target_top or lower>limit-target_bottom:
                constrained.append(f'{c:02X}')
                upper=min(upper,target_top);lower=min(lower,limit-target_bottom)
                assert not above or upper>0,(family,style,c,'no accent room')
                assert not below or lower>0,(family,style,c,'no tail room')
            reduced=Image.new('1',(width,upper+xheight+lower))
            regions=[(0,above,upper,0),(above,above+hb-ht,xheight,upper),
                     (above+hb-ht,bottom-top,lower,upper+xheight)]
            for y0,y1,height,dest in regions:
                if height:
                    part=reduce_mask(canvas.crop((0,y0,canvas.width,y1)),(width,height))
                    reduced.paste(part,(0,dest))
            cell=Image.new('1',(width,pitch));offset=target_top-upper
            # Do not accept a cropped accent or tail, even when outside body span.
            rb=bbox(reduced)
            assert offset+rb[1]>=0 and offset+rb[3]<=limit,(family,style,pt,c,offset,rb,limit)
            cell.paste(reduced,(0,offset));assert cell.getbbox(),(family,style,c)
            caps[c]=cell
        assert bbox(caps[ord('H')])[3]-bbox(caps[ord('H')])[1]==xheight,(family,style,pt,xheight,ht,hb,bbox(caps[ord('H')]))
        all_caps.append(caps)
        notes.append(dict(style=style,x_height=xheight,smallcap_source_points=pt,smallcap_source_dpi=dpi,smallcap_source_pixels=pixels,
                          source_cap_height=hb-ht,scale=scale,
                          method=('native hinted capitals' if scale==1 else 'area rescaling (25% threshold); review required') + ('; accents/tails fitted' if constrained else ''),
                          covered_letters=len(caps),clipped_glyphs=0,accent_or_tail_rescaled_to_cell=constrained,duplicate_groups=duplicate_groups(caps)))
    return all_caps,notes

def render_run(glyphs,codes):
    codes=list(codes)
    h=next(iter(glyphs.values())).height
    im=Image.new('1',(sum(glyphs[c].width for c in codes),h));x=0
    for c in codes:im.paste(glyphs[c],(x,0));x+=glyphs[c].width
    return im

def draw_ink(dest,mask,xy,scale=3):
    mask=mask.resize((mask.width*scale,mask.height*scale),Image.Resampling.NEAREST)
    dest.paste('black',xy,mask)

def page(body,lines,pitch):
    im=Image.new('1',(264,65));x=y=0;row=0;words=(TEXT*8).split();done=[]
    for word in words:
        run=render_run(body,map(ord,word+' '))
        if x+run.width>264:x=0;row+=1;y=row*pitch
        if row>=lines:break
        box=run.getbbox()
        assert box and y+box[3]<=65
        im.paste(run,(x,y));x+=run.width;done.append(word)
    assert row==lines
    return im,' '.join(done)

def export_bdf(path,glyphs,baseline):
    h=glyphs[0].height
    out=['STARTFONT 2.1',f'FONT -betawise-specimen-medium-r-normal--{h}-0-75-75-p-0-fontspecific-0',
         'SIZE 10 75 75',f'FONTBOUNDINGBOX {max(g.width for g in glyphs)} {h} 0 {baseline-h}',
         'STARTPROPERTIES 3',f'FONT_ASCENT {baseline}',f'FONT_DESCENT {h-baseline}',
         'COPYRIGHT "Adobe/DEC X11 bitmap font derivative; see FONT-LICENSE.txt"','ENDPROPERTIES','CHARS 256']
    for c,g in enumerate(glyphs):
        out += [f'STARTCHAR slot{c:02X}',f'ENCODING {c}','SWIDTH 500 0',f'DWIDTH {g.width} 0',
                f'BBX {g.width} {h} 0 {baseline-h}','BITMAP']
        n=(g.width+7)//8
        for y in range(h):
            v=sum((1 if g.getpixel((x,y)) else 0)<<(n*8-1-x) for x in range(g.width))
            out.append(f'{v:0{n*2}X}')
        out.append('ENDCHAR')
    out.append('ENDFONT');path.write_text('\n'.join(out)+'\n')
    reread=read_font(path,'iso8859-1')
    assert all(a.size==b.size and a.tobytes()==b.tobytes() for a,b in zip(glyphs,reread))

def specimen(title,lines,pitch,body,caps,meta,notes,packed):
    im=Image.new('RGB',(1120,610),'white');d=ImageDraw.Draw(im)
    d.text((12,8),f'{title} — {lines} lines / {pitch}px pitch',font=TITLE,fill='black')
    d.text((12,39),f"Body: {meta['pixel_size']}px ({meta['points']}pt/{meta['dpi']}dpi). ASCII unchanged; {meta['adjusted_extended_characters']} extended characters adjusted.",font=SMALL,fill='#444444')
    d.text((12,64),'Body regular:',font=LABEL,fill='black')
    bodyrun=render_run(body[0],map(ord,'The quick brown fox jumps over the lazy dog.'))
    draw_ink(im,bodyrun,(150,60))
    for idx,(cap,note,name) in enumerate(zip(caps,notes,['Regular','Bold','Italic / oblique'])):
        y=123+idx*131
        d.text((12,y),f"{name}: x-height {note['x_height']}px; {note['smallcap_source_pixels']}px/{note['smallcap_source_dpi']}dpi source; {note['method']}",font=SMALL,fill='black')
        for row,codes in enumerate([range(0x41,0x5b),[c for c in REGULAR if c>0x7f]]):
            yy=y+24+row*45
            run=render_run(cap,codes)
            assert run.width*3<=1090,(title,lines,name,run.width)
            # Guide lines are part of the specimen, not modifications to glyph pixels.
            xb=bbox(body[idx][ord('x')])
            d.line((12,yy+xb[1]*3,1100,yy+xb[1]*3),fill='#ebca83')
            d.line((12,yy+xb[3]*3,1100,yy+xb[3]*3),fill='#c8dceb')
            draw_ink(im,run,(12,yy))
    d.text((12,527),'Packed-face superscripts 0–9:',font=LABEL,fill='black')
    draw_ink(im,render_run({c:packed[c] for c in DIGITS},sorted(DIGITS)),(270,521))
    accent_text=''.join(ch for ch in ACCENT_TEXT if ch.encode('cp1252')[0] in body[0])
    accent=render_run(body[0],accent_text.encode('cp1252'))
    d.text((12,565),'Body subset:',font=SMALL,fill='black');draw_ink(im,accent,(125,558),2)
    d.text((12,590),'Candidate artwork for human review. Gold: x-height top; blue: bottom. Accents/tails may extend beyond these lines.',font=SMALL,fill='#555555')
    return im

def glyph_grid(title,lines,pitch,caps,notes):
    im=Image.new('RGB',(1120,1160),'white');d=ImageDraw.Draw(im)
    d.text((12,8),f'{title} — {lines} lines: every small-cap candidate',font=TITLE,fill='black')
    d.text((12,39),'Labels show source letter and packed destination byte. Glyphs enlarged 3×. SS represents source ß.',font=SMALL,fill='#444444')
    for idx,(face,note,style) in enumerate(zip(caps,notes,['regular','bold','italic'])):
        sy=75+idx*357
        d.text((12,sy),f"{style.title()} — x-height {note['x_height']}px; {note['method']}",font=SMALL,fill='black')
        for n,c in enumerate(REGULAR):
            x=12+(n%16)*68;y=sy+25+(n//16)*79
            d.rectangle((x,y,x+66,y+77),outline='#dddddd')
            label='SS' if c==0xd7 else bytes([c]).decode('cp1252')
            d.text((x+3,y+2),f"{label} · {TRIPLES[c][style]:02X}",font=SMALL,fill='#555555')
            glyph=face[c]
            draw_ink(im,glyph,(x+(66-glyph.width*3)//2,y+24))
    return im

def native_strike_sheet():
    count=max(len(strike_options(family)) for title,family,styles in FAMILIES)
    im=Image.new('RGB',(2256,70+count*150),'white');d=ImageDraw.Draw(im)
    d.text((12,8),'All native Adobe strikes — both resolutions; regular artwork at integer 2×',font=TITLE,fill='black')
    d.text((12,38),'Each row is a distinct source strike. Ink heights include all four styles at a shared baseline; no artwork is rescaled.',font=SMALL,fill='#444444')
    for col,(title,family,styles) in enumerate(FAMILIES):
        for row,(pt,dpi,pixels) in enumerate(strike_options(family)):
            faces=[source(family,style,pt,dpi)[1]for style in styles]
            top,bottom=envelope(faces);at,ab=envelope(faces,range(32,127))
            x=12+col*564;y=70+row*150
            d.text((x,y),f'{title}: {pixels}px / {pt}pt / {dpi}dpi',font=LABEL,fill='black')
            d.text((x,y+24),f'Ink height: ASCII {ab-at}px; full Western {bottom-top}px',font=SMALL,fill='#444444')
            codes='Abg ÑÖŸ 123'.encode('cp1252');face={}
            for c in codes:
                ink,t,_=raw(faces[0][c]);cell=Image.new('1',(ink.width,bottom-top));cell.paste(ink,(0,t-top));face[c]=cell
            mask=render_run(face,codes);assert mask.width*2<=540
            draw_ink(im,mask,(x,y+48),2)
    im.save(OUT/'all-native-strikes.png')

def extended_repair_grid(title,family,styles,meta,body):
    changed=meta['extended_adjustments']
    codes=sorted({int(entry['code'],16)for entry in changed})
    if not codes:return None
    columns=10;rows=(len(codes)+columns-1)//columns
    block=38+rows*112
    im=Image.new('RGB',(1120,80+block*4),'white');d=ImageDraw.Draw(im)
    d.text((12,8),f"{title}: extended repairs — {meta['pixel_size']}px / {meta['dpi']}dpi",font=TITLE,fill='black')
    d.text((12,39),'Each cell: source left, adjusted right, both 2×. Gray = allowed ink rows. ASCII and already-fitting extended glyphs are unchanged.',font=SMALL,fill='#444444')
    lookup={(entry['style'],int(entry['code'],16)):entry for entry in changed}
    for index,style in enumerate(styles):
        sy=75+index*block
        d.text((12,sy),style,font=LABEL,fill='black')
        face=source(family,style,meta['points'],meta['dpi'])[1]
        for n,c in enumerate(codes):
            x=12+(n%columns)*110;y=sy+28+(n//columns)*112
            d.rectangle((x,y,x+106,y+108),outline='#dddddd')
            d.text((x+3,y+2),f"{bytes([c]).decode('cp1252')} · {c:02X}",font=SMALL,fill='#444444')
            ink,top,_=raw(face[c]);entry=lookup.get((style,c))
            above=max(1,-top-meta['baseline']+1)
            mask=Image.new('1',(ink.width,meta['pitch']+above+3))
            mask.paste(ink,(0,top+meta['baseline']+above))
            after=Image.new('1',(ink.width,mask.height));after.paste(body[index][c],(0,above))
            for gx,g in [(x+4,mask),(x+57,after)]:
                d.rectangle((gx,y+24+above*2,gx+46,y+24+(above+meta['body_ink_budget'])*2-1),fill='#eeeeee')
                draw_ink(im,g,(gx,y+24),2)
            label='unchanged' if entry is None else 'band shift' if 'translated' in entry['method'] else 'accent fit' if entry['base_pixels_preserved'] else 'glyph fit'
            d.text((x+3,y+90),label,font=SMALL,fill='#666666' if entry is None else '#8a3f10')
    return im

def repaired_context(title,family,styles,meta,body):
    samples=['Señor: ÀÁÂÃÄÅ ÈÉÊË ÌÍÎÏ Ñ ÒÓÔÕÖ Ø ÙÚÛÜ Ý',
             'mañana, niño, déjà vu, ångström, Straße, ð, ÿ, Šš Žž.']
    scale=3;pad=4;cellheight=meta['pitch']+pad+3;lineheight=cellheight*scale+3
    block=40+4*lineheight
    im=Image.new('RGB',(1120,85+4*block),'white');d=ImageDraw.Draw(im)
    d.text((12,8),f'{title}, six lines — extended letters in context',font=TITLE,fill='black')
    d.text((12,39),'Before: untouched X11 artwork. After: local extended repairs. ASCII stays identical. Both 3×; gray marks allowed ink rows.',font=SMALL,fill='#444444')
    for index,style in enumerate(styles):
        y=75+index*block
        d.text((12,y),{'R':'Regular','B':'Bold','O':'Oblique','BO':'Bold oblique'}.get(style,style),font=LABEL,fill='black')
        original={}
        for code in set(''.join(samples).encode('cp1252')):
            ink,t,_=raw(source(family,style,meta['points'],meta['dpi'])[1][code])
            canvas=Image.new('1',(ink.width,cellheight));canvas.paste(ink,(0,t+meta['baseline']+pad))
            assert sum(bool(v)for v in canvas.getdata())==sum(bool(v)for v in ink.getdata())
            original[code]=canvas
        adjusted={}
        for code in original:
            canvas=Image.new('1',(body[index][code].width,cellheight));canvas.paste(body[index][code],(0,pad));adjusted[code]=canvas
        for mode,glyphs in enumerate([original,adjusted]):
            for row,text in enumerate(samples):
                yy=y+29+(mode*2+row)*lineheight
                mask=render_run(glyphs,text.encode('cp1252'));assert mask.width*scale<1000
                d.text((12,yy+pad*scale),'Before' if mode==0 else 'After',font=SMALL,fill='#444444')
                d.rectangle((95,yy+pad*scale,95+mask.width*scale,yy+(pad+meta['body_ink_budget'])*scale-1),fill='#eeeeee')
                draw_ink(im,mask,(95,yy),scale)
    return im

def main():
    OUT.mkdir(exist_ok=True)
    inventory=audit_strikes.main(verbose=False)
    native_strike_sheet()
    import shutil
    shutil.copyfile(HERE.parent/'smallcaps-hinted/build/FONT-LICENSE.txt',OUT/'FONT-LICENSE.txt')
    report={'scope':'Research candidate specimens, not installed or accepted production fonts',
            'sizes':SIZES,'encoding':ENC,'audited_bitmap_files':inventory['bitmap_files'],'audited_four_style_strikes':inventory['four_style_strikes'],'fonts':[],'three_line_comparison':[],'validation':{}}
    overview=Image.new('RGB',(2256,1389),'white');od=ImageDraw.Draw(overview)
    od.text((12,8),'Regular body fonts — 3 / 4 / 5 / 6 / 7 lines on a 264 × 65 screen (2×)',font=TITLE,fill='black')
    families_html=[]
    bdf_count=0
    for col,(title,family,styles) in enumerate(FAMILIES):
        family_body=Image.new('RGB',(840,1130),'white');fd=ImageDraw.Draw(family_body)
        fd.text((12,8),f'{title}: four reading sizes (3×)',font=TITLE,fill='black')
        # Three-line / 21px row is a comparison, not an adopted package size.
        preview,preview_meta=body_fonts(family,styles,21,21)
        assert preview is not None
        screen,preview_text=page(preview[0],3,21)
        white=Image.new('RGB',screen.size,'white');white.paste('black',(0,0),screen)
        white.save(OUT/f'{family}-3-lines-comparison.png')
        x,y=col*564+12,50
        od.text((x,y),f'{title} — 3 lines / 21px (comparison)',font=LABEL,fill='black')
        od.text((x,y+24),f"{preview_meta['pixel_size']}px / {preview_meta['dpi']}dpi; native ASCII",font=SMALL,fill='#444444')
        overview.paste(white.resize((528,130),Image.Resampling.NEAREST),(x,y+48))
        od.rectangle((x-1,y+47,x+528,y+178),outline='#999999')
        report['three_line_comparison'].append(dict(family=title,**preview_meta,page_text=preview_text))
        cards=[];family_links=[]
        for row,(lines,pitch,limit) in enumerate(SIZES):
            stem=f'{family}-{lines}-lines'
            body,meta=body_fonts(family,styles,limit,pitch)
            if body is None:
                unavailable=Image.new('RGB',(1120,610),'white');ud=ImageDraw.Draw(unavailable)
                ud.text((12,10),f'{title} — {lines} lines / {pitch}px pitch',font=TITLE,fill='black')
                reason=f"No complete native ASCII strike across all four styles fits the {limit}px ink budget."
                ud.text((12,55),reason,font=LABEL,fill='#a02020')
                ud.text((12,85),'No body rescaling, clipping, font export or inferred small-cap set.',font=LABEL,fill='black')
                unavailable.save(OUT/f'{stem}-smallcaps.png');cards.append(unavailable)
                for old in OUT.glob(f'{stem}-*.bdf'):old.unlink()
                for suffix in ['glyph-grid.png','body-native.png']:
                    old=OUT/f'{stem}-{suffix}'
                    if old.exists():old.unlink()
                x,y=col*564+12,(row+1)*265+50
                od.text((x,y),f'{title} — {lines} lines / {pitch}px',font=LABEL,fill='black')
                od.text((x,y+26),'No native four-style ASCII strike fits',font=SMALL,fill='#a02020')
                fd.text((12,row*265+52),f'{lines} lines: unavailable without changing native artwork',font=LABEL,fill='#a02020')
                report['fonts'].append(dict(family=title,lines=lines,**meta))
                family_links.append(f'<p>{lines} lines: {reason} No rescaled substitute.</p>')
                continue
            if family=='helv' and lines==6:
                repaired_context(title,family,styles,meta,body).save(OUT/'helv-6-lines-before-after-context.png')
            caps,notes=smallcaps(family,styles,body,meta['points'],pitch,limit)
            repair_grid=extended_repair_grid(title,family,styles,meta,body)
            if repair_grid is not None:repair_grid.save(OUT/f'{stem}-extended-repairs.png')
            else:
                stale=OUT/f'{stem}-extended-repairs.png'
                if stale.exists():stale.unlink()
            blank=lambda:[Image.new('1',(1,pitch)) for _ in range(256)]
            packed=blank()
            for idx,style in enumerate(['regular','bold','italic']):
                for r,trip in TRIPLES.items():packed[trip[style]]=caps[idx][r]
            # Superscript numerals use the same common cap baseline, scaled upward.
            top=bbox(body[0][ord('x')])[1]
            numeral_height=max(3,round(notes[0]['x_height']*.8))
            for c in sorted(DIGITS):
                original=body[0][c];box=bbox(original)
                scale=numeral_height/(box[3]-box[1]);width=max(1,round(original.width*scale))
                small=reduce_mask(original.crop((0,box[1],original.width,box[3])),(width,numeral_height))
                cell=Image.new('1',(width,pitch));cell.paste(small,(0,max(0,top-1)));packed[c]=cell
            assert len(REGULAR)==61 and len({c for v in TRIPLES.values() for c in v.values()})==183
            assert all(not packed[c].getbbox() for c in RED)
            assert all(packed[c].getbbox() for c in DIGITS)
            assert sum(bool(g.getbbox()) for g in packed)==193
            for idx,style in enumerate(['regular','bold','italic']):
                assert all(packed[trip[style]].tobytes()==caps[idx][r].tobytes() for r,trip in TRIPLES.items())
            for idx,style in enumerate(styles):
                glyphs=blank()
                for c,g in body[idx].items():glyphs[c]=g
                export_bdf(OUT/f'{stem}-{style}.bdf',glyphs,meta['baseline']);bdf_count+=1
            export_bdf(OUT/f'{stem}-packed.bdf',packed,meta['baseline']);bdf_count+=1
            card=specimen(title,lines,pitch,body,caps,meta,notes,packed)
            card.save(OUT/f'{stem}-smallcaps.png');cards.append(card)
            glyph_grid(title,lines,pitch,caps,notes).save(OUT/f'{stem}-glyph-grid.png')
            screen,text=page(body[0],lines,pitch)
            white=Image.new('RGB',screen.size,'white');white.paste('black',(0,0),screen)
            white.save(OUT/f'{stem}-body-native.png')
            x,y=col*564+12,(row+1)*265+50
            od.text((x,y),f'{title} — {lines} lines / {pitch}px',font=LABEL,fill='black')
            od.text((x,y+24),f"{meta['pixel_size']}px / {meta['dpi']}dpi; "+f"ASCII native; {meta['adjusted_extended_characters']} ext. edits",font=SMALL,fill='#444444' if meta['body_scale']==1 else '#a02020')
            overview.paste(white.resize((528,130),Image.Resampling.NEAREST),(x,y+48))
            od.rectangle((x-1,y+47,x+528,y+178),outline='#999999')
            fd.text((12,row*265+52),f"{lines} lines / {pitch}px — {meta['pixel_size']}px/{meta['dpi']}dpi; ASCII unchanged, local extended edits",font=SMALL,fill='black')
            family_body.paste(white.resize((792,195),Image.Resampling.NEAREST),(12,row*265+79))
            entry=dict(family=title,lines=lines,**meta,smallcaps=notes,letters_each_style=61,
                       red_slots_clear=True,superscript_slots='30–39',page_text=text,
                       extended_repair_grid=f'{stem}-extended-repairs.png' if repair_grid is not None else None,
                       specimen=f'{stem}-smallcaps.png',glyph_grid=f'{stem}-glyph-grid.png',native_body=f'{stem}-body-native.png',
                       source_paths=[str(source(family,s,meta['points'],meta['dpi'])[0]) for s in styles])
            report['fonts'].append(entry)
            family_links.append((f'<p><a href="{stem}-extended-repairs.png">{lines}-line extended repairs: before / after</a></p>' if repair_grid is not None else f'<p>{lines} lines: no extended repairs needed.</p>')+f'<p><a href="{stem}-glyph-grid.png">{lines}-line labelled grid: all 183 small-cap glyphs</a></p><a href="{stem}-smallcaps.png"><img loading="lazy" src="{stem}-smallcaps.png" alt="{html.escape(title)} {lines} lines small caps"></a>')
        family_body.save(OUT/f'{family}-body-sizes.png')
        combined=Image.new('RGB',(1120,610*4),'white')
        for i,card in enumerate(cards):combined.paste(card,(0,i*610))
        combined.save(OUT/f'{family}-smallcaps-sizes.png')
        families_html.append(f'<section><h2>{html.escape(title)}</h2><a href="{family}-body-sizes.png"><img src="{family}-body-sizes.png" alt="Regular body sizes"></a>'+''.join(family_links)+'</section>')
    overview.save(OUT/'regular-body-overview.png')
    report['validation']=dict(passed=True,family_size_combinations=16,native_body_sets=bdf_count//5,unavailable_body_sets=16-bdf_count//5,body_rescalings=0,ascii_glyphs_verified=sum(f.get('ascii_glyphs_verified',0)for f in report['fonts']),
        extended_glyphs_adjusted=sum(len(f.get('extended_adjustments',[]))for f in report['fonts']),
        smallcap_style_sets=(bdf_count//5)*3,
        smallcap_glyphs=(bdf_count//5)*61*3,superscript_glyphs=(bdf_count//5)*10,bdf_pixel_roundtrips=bdf_count,
        red_slot_collisions=0,clipped_smallcaps=0,page_width=264,page_height=65,
        note='Coverage/geometry assertions are not legibility approval. Reduced glyphs need review.')
    assert sum(len(list(OUT.glob(f'{family}-*-lines-*.bdf'))) for _,family,_ in FAMILIES)==bdf_count
    (OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    (OUT/'index.html').write_text('''<!doctype html><meta charset="utf-8"><title>X11 font specimens</title>
<style>body{font:16px sans-serif;max-width:1160px;margin:24px auto;padding:0 12px}img{max-width:100%;height:auto;image-rendering:pixelated;border:1px solid #ddd;margin:12px 0}a{color:#154f92}section{margin-top:40px}</style>
<h1>X11 candidate font specimens</h1><p><a href="helv-6-lines-before-after-context.png">Six-line Helvetica: before/after extended letters in context</a> · <a href="helv-6-lines-extended-repairs.png">Every affected Helvetica glyph in all four styles</a></p><p>Four families × four candidate sizes: 4, 5, 6 and 7 lines; no eight-line size. The body overview additionally shows a three-line / 21px-pitch comparison row at the top, without adopting it as a package size. Click images for full resolution. These are candidates for human review, not completed production fonts.</p>
<p>The six-line pitch is 11px with ink restricted to ten rows: its 66th logical row is blank, and all displayed ink fits within 65 physical rows. Seven-line pitch is 9px. Choose the largest native ASCII strike at each line count. ASCII bitmap shapes are native; normalized Neo cell widths are verified. Source X11 pen advances can differ where glyphs overhang. All Windows-1252 glyphs are retained; only overflowing extended glyphs receive labelled local repairs. No whole-font rescaling. A combination with no native ASCII fit remains unavailable.</p>
<p>Where a native body fits, small caps cover all 61 letters in regular, bold and italic/oblique, including SS, Ÿ, Š, Œ and Ž. Gold and blue guide lines show x-height boundaries; accents and tails extend outside them. Tiny glyphs are algorithmic candidates and require visual review.</p>
<p><a href="all-native-strikes.png">Compare every native strike from both resolutions</a> · <a href="strike-inventory.json">Complete 384-file inventory</a></p><a href="regular-body-overview.png"><img src="regular-body-overview.png" alt="Body font overview"></a>'''+''.join(families_html)+'<p><a href="report.json">Metrics, provenance and validation report</a> · <a href="FONT-LICENSE.txt">Source font licence</a></p>')
    print(json.dumps(report['validation'],indent=2))
    print(OUT/'index.html')
if __name__=='__main__':main()
