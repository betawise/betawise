#!/usr/bin/env python3
"""Requested three-stem m, tiny italic a alternatives and native bitmap models."""
from pathlib import Path
import json,hashlib,subprocess
from PIL import Image,ImageDraw
import build as b
import evaluate_substitutes as e
import courier_stock_fit as stock
import reader_candidates as writer
OUT=b.HERE/'courier-six-touches'
REF=b.HERE.parents[3]/'.research-work/courier-a-references/dylex'

def to_image(points,w=6,h=11,baseline=8):
 im=Image.new('1',(w,h))
 for x,y in points:
  assert 0<=x<w and 0<=y+baseline<10
  im.putpixel((x,y+baseline),1)
 return im

def main():
 OUT.mkdir(exist_ok=True)
 fonts={};original_m={}
 for st in stock.STYLES:
  _,gs,_=e.parse(b.HERE/f'courier-stock-fit/cour-6-lines-{st}.bdf');fonts[st]={c:to_image(set(gs[c]['points']))for c in b.CODES}
 # Independent exact checks of requested m semantics against native stock B.
 _,regular=b.source('cour','R',8,75);_,bold=b.source('cour','B',8,75)
 before,_=stock.horizontal(stock.raw(regular[109]),6);native_b,_=stock.horizontal(stock.raw(bold[109]),6)
 after={(x,y-8)for y in range(11)for x in range(6)if fonts['R'][109].getpixel((x,y))}
 assert after==native_b
 for y in [-3,-2,-1]:assert{x for x,yy in after if yy==y}=={0,2,4}
 original_m=to_image(before)
 # A4: original four-row x-height, single-storey oblique a with a closed bowl
 # and right foot. This is new hand-drawn artwork, not an imported font glyph.
 patterns=['..##..','.#.#..','#..#..','.####.']
 four={(x,-4+y)for y,row in enumerate(patterns)for x,v in enumerate(row)if v=='#'}
 assert stock.topology(four)==(1,1)
 # A5: use the larger native Courier O a, removing one repeated lower stem
 # row and moving upper rows down one. No raster resampling or width change.
 larger_path,larger=b.source('cour','O',12,75);large=stock.raw(larger[97]);assert{(x,y+1)for x,y in large if y==-3}=={(x,y)for x,y in large if y==-2}
 five={(x,y+1 if y<=-4 else y)for x,y in large if y!=-3}
 assert min(y for x,y in five)==-5 and max(y for x,y in five)==-1
 options={'stock':fonts['O'][97],'A4':to_image(four),'A5':to_image(five)}
 variants={}
 for name,a in options.items():
  face={c:g.copy()for c,g in fonts['O'].items()};face[97]=a
  writer.export(OUT/f'cour-6-lines-O-{name}.bdf',face,8);variants[name]=face
 # Dylex variants are delta sets; author's README explicitly prescribes base fallback.
 props,base,_=e.parse(REF/'6x10.bdf');refs={};metrics={}
 for st,suffix in [('R',''),('B','B'),('O','O'),('BO','BO')]:
  path=REF/f'6x10{suffix}.bdf';_,delta,_=e.parse(path);full={**base,**delta}
  assert not e.UNICODE-full.keys()
  for code in e.UNICODE:
   assert full[code]['advance']==6 and all(0<=x<6 and -8<=y<2 for x,y in full[code]['points'])
  refs[st]={c:to_image(set(full[ord(bytes([c]).decode('cp1252'))]['points']))for c in b.CODES}
  metrics[st]=dict(source=str(path),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),coverage=218,delta_glyphs=len(delta),base_fallback=True)
 # Detailed source a/m comparisons, identical source-pixel enlargement.
 im=Image.new('RGB',(1320,920),'white');d=ImageDraw.Draw(im)
 d.text((12,8),'Six-line Courier — requested m and italic a choices',font=b.TITLE,fill='black')
 d.text((12,40),'All glyphs retain 6px cells, baseline row 8; enlargement 10×. A5 is one ink row taller than stock/A4.',font=b.SMALL,fill='#444444')
 for j,(title,g)in enumerate([('Regular m: before',original_m),('New m = native bold m',fonts['R'][109]),('Native bold m',fonts['B'][109])]):
  x=20+j*420;d.text((x,85),title,font=b.LABEL,fill='black');b.draw_ink(im,g,(x+30,116),10)
  mask=b.render_run({**fonts['R'],109:g},b'minimum mammal');b.draw_ink(im,mask,(x,245),3)
 for j,(name,g)in enumerate(options.items()):
  x=20+j*420;title={'stock':'Stock oblique a (4 rows)','A4':'A4: closed bowl, 4 rows','A5':'A5: larger Courier model, 5 rows'}[name]
  d.text((x,345),title,font=b.LABEL,fill='black');b.draw_ink(im,g,(x+30,376),10)
  for k,text in enumerate(['a aaaa aea','a minimum mammal','an amazing aroma']):
   mask=b.render_run(variants[name],text.encode());b.draw_ink(im,mask,(x,510+k*53),3)
 d.text((12,710),'Native references, no rescaling: Dylex 6×10 O / BO; X11 Fixed 6×13 O',font=b.LABEL,fill='black')
 for j,st in enumerate(['O','BO']):
  x=20+j*420;d.text((x,750),'Dylex '+st+' — 5-row a',font=b.LABEL,fill='black');b.draw_ink(im,refs[st][97],(x+30,780),10)
 fixed=e.parse(e.BDF/'6x13O.bdf')[1][97];pts=fixed['points'];top=min(y for x,y in pts);bottom=max(y for x,y in pts)+1;fg=Image.new('1',(6,bottom-top))
 for x,y in pts:fg.putpixel((x,y-top),1)
 d.text((860,750),f'Fixed O — {bottom-top}-row a',font=b.LABEL,fill='black');b.draw_ink(im,fg,(890,800),10)
 im.save(OUT/'m-a-options.png')
 # Whole native Dylex six-line screen comparison, not a font substitution.
 refcard=Image.new('RGB',(1160,680),'white');rd=ImageDraw.Draw(refcard)
 rd.text((12,8),'Dylex 6×10 — native four-style reference, 44×6',font=b.TITLE,fill='black')
 rd.text((12,40),'Actual source bitmaps, no conversion edits; screens 2×, samples 3×. Author marks fonts CC0 public domain.',font=b.SMALL,fill='#444444')
 for i,st in enumerate(stock.STYLES):
  x=12+i%2*580;y=85+i//2*290;rd.text((x,y),st,font=b.LABEL,fill='black');page,_=b.page(refs[st],6,11);b.draw_ink(refcard,page,(x,y+28),2)
  for k,text in enumerate(['AaBbCcDdEeFfGg','a m minimum mammal']):b.draw_ink(refcard,b.render_run(refs[st],text.encode()),(x,y+175+k*42),3)
 refcard.save(OUT/'dylex-reference.png')
 commit=subprocess.check_output(['git','-C',str(REF),'rev-parse','HEAD'],text=True).strip()
 report=dict(m=dict(applied_to='courier-stock-fit regular six-line 6D',copied_from='native bold m',lower_three_rows=[0,2,4],before=sorted(before),after=sorted(after)),
  a=dict(applied=False,stock='Retained pending selection',A4=dict(points=sorted(four),height=4,design='New single-storey bowl/tail, no pixel resampling'),A5=dict(points=sorted(five),height=5,source=str(larger_path),method='Delete duplicate lower stem row; shift upper rows down one; baseline fixed')),
  models=dict(dylex=dict(url='https://github.com/dylex/fonts',commit=commit,license='CC0 fonts per author README',styles=metrics,all_four_faces_width=6,full_western=True,ink_envelope=[-8,2]),fixed=dict(source=str(e.BDF/'6x13O.bdf'),a_ink_height=bottom-top)),
  search='No specific discussion of the Adobe 75dpi 8px oblique lowercase a was found in targeted web searches. This is a search result, not proof that no commentary exists.',
  validation=dict(m_exact_bold_match=True,m_three_stems=True,candidate_a_bdf_roundtrips=3*218,Dylex_glyph_bounds_checked=4*218,A4_closed_counter=True))
 (OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
 (OUT/'index.html').write_text('<!doctype html><meta charset="utf-8"><title>Courier six-line m and a</title><style>body{font:17px sans-serif;margin:24px}img{max-width:100%;image-rendering:pixelated}</style><h1>Six-line Courier: m correction and a options</h1><p>The regular m is now an exact copy of the native bold glyph, with three separate stems and no right foot serif. The stock oblique a is retained; A4 and A5 are alternate designs for review. A4 stays four rows tall; A5 is one row taller, derived from a larger native Courier bitmap.</p><a href="m-a-options.png"><img src="m-a-options.png"></a><h2>Native 6px monospace reference</h2><p>Dylex 6×10 has all four styles. Its variant files are deltas, merged with the base according to the author’s documented fallback. All 218 Western glyphs fit six columns and ten ink rows; fonts are CC0 per the author. It is shown as a reference, not silently substituted for Courier.</p><a href="dylex-reference.png"><img src="dylex-reference.png"></a><p><a href="https://github.com/dylex/fonts">Dylex source</a> · <a href="report.json">Exact changes, sources and validation</a> · <a href="../courier-stock-fit/index.html">Updated Courier set</a></p>')
 print(json.dumps(report['validation']));print(OUT/'index.html')
if __name__=='__main__':main()
