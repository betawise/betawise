#!/usr/bin/env python3
"""8px Courier six-line candidate: two caron edits and three face shifts."""
import json
from PIL import Image,ImageDraw
import build as b
STYLES=('R','B','O','BO')
TOP=-8
PITCH=11
LIMIT=10

def main():
    b.OUT.mkdir(exist_ok=True)
    bodies=[];sources=[];records=[]
    for style in STYLES:
        path,face=b.source('cour',style,8,75);sources.append(face)
        body={};row_users=[[]for _ in range(PITCH)];original_top=[];original_bottom=[]
        for c in b.CODES:
            width,original=b.extended_fit.pixels(face[c])
            if style=='R' and c in (0x8a,0x8e):
                # Caron occupies -9/-8, with an empty -7 row before the S/Z body.
                upper={(x,y)for x,y in original if y < -7}
                assert {y for x,y in upper}=={-9,-8}
                points={(x,y+1)for x,y in upper}|(original-upper)
                assert len(points)==len(original)
                assert {(x,y)for x,y in points if y>=-6}=={(x,y)for x,y in original if y>=-6}
            elif style!='R':points={(x,y+1)for x,y in original}
            else:points=original
            if points:assert min(y for x,y in points)>=TOP and max(y for x,y in points)<TOP+LIMIT
            cell=b.extended_fit.image(width,PITCH,points,TOP) if points else Image.new('1',(width,PITCH))
            assert cell.width==width
            assert sum(bool(v)for v in cell.getdata())==len(original)
            if style!='R':assert {(x,y-1)for x,y in points}==original
            elif c not in(0x8a,0x8e):assert points==original
            assert not any(cell.getpixel((x,10))for x in range(cell.width))
            for row in range(PITCH):
                if any(cell.getpixel((x,row))for x in range(cell.width)):row_users[row].append(f'{c:02X}')
            if any(y==-9 for x,y in original):original_top.append(f'{c:02X}')
            if any(y==1 for x,y in original):original_bottom.append(f'{c:02X}')
            body[c]=cell
        assert not row_users[10]
        glyphs=[Image.new('1',(1,PITCH))for _ in range(256)]
        for c,cell in body.items():glyphs[c]=cell
        b.export_bdf(b.OUT/f'courier8-6-lines-{style}.bdf',glyphs,8)
        records.append(dict(style=style,source=str(path),face_shift=0 if style=='R'else 1,
                            modified_shapes=['8A','8E']if style=='R'else[],
                            row_occupied=[bool(users)for users in row_users],row_users=row_users,
                            original_top_edge_users=original_top,original_bottom_edge_users=original_bottom,
                            glyphs_verified=len(body)))
        bodies.append(body)
    compare=Image.new('RGB',(1660,400),'white');d=ImageDraw.Draw(compare)
    d.text((12,8),'Six-line Courier: native 8px candidate vs 11px with extended repairs',font=b.TITLE,fill='black')
    d.text((12,40),'264 × 65 screens at integer 3×. Same text start. Both use 11px pitch with a guaranteed blank final cell row.',font=b.SMALL,fill='#444444')
    existing=b.read_font(b.OUT/'cour-6-lines-R.bdf','iso8859-1')
    oldbody={c:existing[c]for c in b.CODES}
    for index,(label,body)in enumerate([('8px / 75dpi: regular Š/Ž carons moved down 1px',bodies[0]),
                                       ('11px / 100dpi: previous local extended repairs',oldbody)]):
        x=12+824*index
        d.text((x,70),label,font=b.LABEL,fill='black')
        mask,text=b.page(body,6,11);b.draw_ink(compare,mask,(x,103),3)
        d.rectangle((x-1,102,x+792,298),outline='#888888')
        d.text((x,316),'Regular ASCII pixels and widths are unchanged.',font=b.SMALL,fill='#444444')
        if index==0:d.text((x,341),'Bold / oblique / bold-oblique shift down 1px; their glyph shapes stay native.',font=b.SMALL,fill='#444444')
    compare.save(b.OUT/'courier8-vs-11-six-lines.png')
    # Before/after face specimens use padding to retain the native top overshoots.
    samples=['Agjpqy  ÀÁÄÅ ÉÊÏ Ññ ÖØ Ü Ý  ŠŽ šž',
             'Reading the book: Señor, mañana, déjà vu.']
    scale=3;pad=3;h=PITCH+pad+2;lineheight=h*scale+3;block=35+lineheight*4
    specimen=Image.new('RGB',(1120,85+4*block),'white');sd=ImageDraw.Draw(specimen)
    sd.text((12,8),'8px Courier — original above candidate, all four faces',font=b.TITLE,fill='black')
    sd.text((12,39),'Gray: ten occupied rows allowed. Blue: common original baseline. Candidate face shifts are visible against that baseline.',font=b.SMALL,fill='#444444')
    for index,style in enumerate(STYLES):
        y=75+index*block
        label=style+(' — edit regular Š/Ž carons only'if style=='R'else' — shift this entire face down one pixel; shapes unchanged')
        sd.text((12,y),label,font=b.LABEL,fill='black')
        original={};candidate={}
        for c in set(''.join(samples).encode('cp1252')):
            width,points=b.extended_fit.pixels(sources[index][c])
            original[c]=b.extended_fit.image(width,h,points,TOP-pad)if points else Image.new('1',(width,h))
            canvas=Image.new('1',(width,h));canvas.paste(bodies[index][c],(0,pad));candidate[c]=canvas
        for version,face in enumerate([original,candidate]):
            for row,text in enumerate(samples):
                yy=y+28+(version*2+row)*lineheight
                sd.text((12,yy+pad*scale),'Original'if version==0 else'Candidate',font=b.SMALL,fill='#555555')
                mask=b.render_run(face,text.encode('cp1252'));assert mask.width*3<=1000
                sd.rectangle((100,yy+pad*3,100+mask.width*3,yy+(pad+LIMIT)*3-1),fill='#eeeeee')
                sd.line((100,yy+(pad+8)*3,100+mask.width*3,yy+(pad+8)*3),fill='#bed4eb')
                b.draw_ink(specimen,mask,(100,yy),3)
    specimen.save(b.OUT/'courier8-6-lines-before-after.png')
    # Mixed-style text makes the intentional one-pixel baseline stagger explicit.
    mixed=Image.new('RGB',(1120,250),'white');md=ImageDraw.Draw(mixed)
    md.text((12,10),'Mixed faces on one line — the baseline trade-off (4×)',font=b.TITLE,fill='black')
    mixedtext=[('R','Regular '),('B','Bold '),('O','Oblique '),('BO','BoldOblique '),('R','Regular')]
    width=sum(sum(bodies[STYLES.index(st)][c].width for c in text.encode('cp1252'))for st,text in mixedtext)
    mask=Image.new('1',(width,PITCH));x=0
    for st,text in mixedtext:
        run=b.render_run(bodies[STYLES.index(st)],text.encode('cp1252'));mask.paste(run,(x,0));x+=run.width
    assert width*4<=1090
    md.line((12,75+8*4,12+width*4,75+8*4),fill='#bed4eb');b.draw_ink(mixed,mask,(12,75),4)
    md.text((12,158),'Bold and slanted letters sit one pixel lower than regular. Widths, shapes and all glyph ink are retained.',font=b.SMALL,fill='#444444')
    mixed.save(b.OUT/'courier8-6-lines-mixed-baseline.png')
    report=dict(scope='218 Windows-1252 printable glyphs; no claim of a complete Neo device/control glyph mapping',
                pitch=11,ink_rows=10,lines=6,logical_rows=66,physical_rows=65,
                guaranteed_blank_cell_rows=[10],guaranteed_blank_last_logical_row_index=65,
                edited_glyphs=[dict(style='R',code='8A',character='Š',operation='caron down one pixel'),
                               dict(style='R',code='8E',character='Ž',operation='caron down one pixel')],
                shifted_faces={'B':1,'O':1,'BO':1},faces=records,
                validation=dict(passed=True,source_pixel_counts_preserved=True,widths_preserved=True,
                    source_glyphs_verified=sum(r['glyphs_verified']for r in records),bdf_roundtrips=4,
                    final_logical_row_has_ink=False,whole_font_rescaling=False))
    (b.OUT/'courier8-6-lines-report.json').write_text(json.dumps(report,indent=2)+'\n')
    (b.OUT/'courier8-6-lines.html').write_text('''<!doctype html><meta charset="utf-8"><title>8px Courier six-line candidate</title>
<style>body{font:16px sans-serif;max-width:1140px;margin:24px auto}img{max-width:100%;height:auto;image-rendering:pixelated}</style>
<h1>8px Courier: six-line candidate</h1><p>Only regular Š/Ž carons are edited. All three other faces shift down one pixel. Every glyph retains its ink count and normalized advance. The last row of every eleven-row cell is guaranteed blank, making six cells safe on a 65-row display.</p>
<p>The cost is a one-pixel baseline stagger between regular and the other faces. This is a font candidate, not an installed/native-editor acceptance test.</p>
<img src="courier8-vs-11-six-lines.png"><img src="courier8-6-lines-mixed-baseline.png"><img src="courier8-6-lines-before-after.png">
<p><a href="courier8-6-lines-report.json">Metrics and exact row occupancy</a></p>''')
    print(json.dumps(report['validation'],indent=2))
    print('Native original top/bottom edge occupied:',any(r['original_top_edge_users']for r in records),any(r['original_bottom_edge_users']for r in records))
    print('Candidate last row always blank:',all(not r['row_occupied'][10]for r in records))
if __name__=='__main__':main()
