#!/usr/bin/env python3
"""Inventory every installed Adobe bitmap for the four requested families."""
import gzip,json
from pathlib import Path
from PIL import PcfFontFile
HERE=Path(__file__).resolve().parent
NAMES={'courier':'Courier','helvetica':'Helvetica','times':'Times','new century schoolbook':'Century Schoolbook'}
def span(glyphs,codes):
 out=[]
 for c in codes:
  g=glyphs[c]
  if g is None:continue
  box=g[3].crop(g[2]).getbbox()
  if box:out.append((g[1][1]+box[1],g[1][1]+box[3]))
 return {'top':min(t for t,b in out),'bottom':max(b for t,b in out),'height':max(b for t,b in out)-min(t for t,b in out)}
def main(verbose=True):
 entries=[]
 for directory in sorted(Path('/usr/share/fonts/X11').glob('*')):
  index=directory/'fonts.dir'
  if not index.exists():continue
  for line in index.read_text().splitlines()[1:]:
   name,xlfd=line.split(' ',1);fields=xlfd.split('-')
   if len(fields)<15 or fields[1]!='adobe' or fields[2] not in NAMES:continue
   if not name.endswith(('.pcf.gz','.pcf','.bdf','.bdf.gz')):continue
   codec='cp1252' if fields[13]=='iso10646' else 'iso8859-1'
   path=directory/name
   with gzip.open(path,'rb') as stream:g=PcfFontFile.PcfFontFile(stream,charset_encoding=codec).glyph
   groups={'ascii':list(range(32,127)),'latin1':list(range(32,127))+list(range(160,256))}
   if fields[13]=='iso10646':groups['western_cp1252']=list(range(32,127))+[c for c in range(128,256)if c not in [0x81,0x8d,0x8f,0x90,0x9d]]
   entries.append(dict(path=str(path),xlfd=xlfd,family=NAMES[fields[2]],weight=fields[3],slant=fields[4],
     pixels=int(fields[7]),points=int(fields[8])/10,dpi=int(fields[9]),encoding='-'.join(fields[13:]),
     metrics={key:span(g,codes)for key,codes in groups.items()}))
 groups={}
 for e in entries:
  if e['encoding']!='iso10646-1':continue
  key=(e['family'],e['dpi'],e['points'],e['pixels'])
  groups.setdefault(key,[]).append(e)
 summary=[]
 for (family,dpi,points,pixels),faces in groups.items():
  assert len(faces)==4,(family,dpi,points,len(faces))
  item=dict(family=family,dpi=dpi,points=points,pixels=pixels)
  for label in ['ascii','latin1','western_cp1252']:
   top=min(f['metrics'][label]['top']for f in faces);bottom=max(f['metrics'][label]['bottom']for f in faces)
   item[label]=dict(top=top,bottom=bottom,height=bottom-top)
  summary.append(item)
 # Compare every Latin-1 variant to its Unicode companion for shared source artwork.
 variant_differences=[]
 for e in entries:
  if e['encoding']!='iso8859-1':continue
  partner=next(f for f in entries if f['encoding']=='iso10646-1' and all(e[k]==f[k] for k in ['family','dpi','points','pixels','weight','slant']))
  with gzip.open(e['path'],'rb')as stream:a=PcfFontFile.PcfFontFile(stream,charset_encoding='iso8859-1').glyph
  with gzip.open(partner['path'],'rb')as stream:b=PcfFontFile.PcfFontFile(stream,charset_encoding='iso8859-1').glyph
  differences=[]
  for c in list(range(32,127))+list(range(160,256)):
   ga,gb=a[c],b[c]
   if ga is None or gb is None or ga[:3]!=gb[:3] or ga[3].crop(ga[2]).tobytes()!=gb[3].crop(gb[2]).tobytes():differences.append(c)
  if differences:variant_differences.append(dict(path=e['path'],differences=differences))
 result=dict(bitmap_files=len(entries),unicode_files=sum(e['encoding']=='iso10646-1'for e in entries),
   four_style_strikes=len(summary),variant_differences=variant_differences,strikes=sorted(summary,key=lambda x:(x['family'],x['pixels'],x['dpi'])),files=entries)
 (HERE/'build').mkdir(exist_ok=True)
 (HERE/'build/strike-inventory.json').write_text(json.dumps(result,indent=2)+'\n')
 if not verbose:return result
 print('FILES',len(entries),'STRIKES',len(summary),'LATIN/UNICODE DIFFERENCES',len(variant_differences))
 for item in result['strikes']:
  if item['pixels']<=17:print(item['family'],item['pixels'],'px',item['points'],'pt',item['dpi'],'dpi; ink ASCII / Latin1 / Western:',*[item[k]['height']for k in ['ascii','latin1','western_cp1252']])
if __name__=='__main__':main()
