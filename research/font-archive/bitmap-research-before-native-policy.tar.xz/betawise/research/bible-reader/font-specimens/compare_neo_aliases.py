#!/usr/bin/env python3
"""Compare literal byte-pair bitmaps in Neo font resources; no screen inference."""
import json
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

import build
from inventory_neo_fonts import decode

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).with_name('charset-review')
SLOTS = [0x60, 0x90, 0x0d, 0x16]


def identical(first, second):
    return first.size == second.size and first.tobytes() == second.tobytes()


def main():
    workspace = ROOT.parent
    terminal = build.read_font(ROOT / 'fonts/BetaWiseTerminal/glyphs.bdf', 'iso8859-1')
    fonts = {'Terminal Medium': terminal}
    rom = (workspace / 'Ghidra/Alphasmart Neo/SmartApplets/os3kneorom.os3kos').read_bytes()
    for name, address in [('Neo system', 0x44af8e), ('Neo dialog', 0x44e336)]:
        fonts[name] = decode(rom, address - 0x410000, 0x410000)[1]
    for path in sorted((workspace / 'Ghidra/Alphasmart Neo/NeoFonts').glob('*.OS3KApp')):
        if any(name in path.stem for name in ['Klingon', 'Mirror', 'Neuropol']):
            continue
        data = path.read_bytes()
        fonts[path.stem.replace('NeoFont', '')] = decode(data, len(data) - 20)[1]
    rows = []
    for name, glyphs in fonts.items():
        rows.append(dict(font=name, height=glyphs[0].height,
                         grave_identical=identical(glyphs[0x60], glyphs[0x90]),
                         return_identical=identical(glyphs[0x0d], glyphs[0x16]),
                         glyphs={f'{slot:02X}': dict(width=glyphs[slot].width,
                             bbox=glyphs[slot].getbbox(), rows=[
                                 ''.join('1' if glyphs[slot].getpixel((x, y)) else '0'
                                         for x in range(glyphs[slot].width))
                                 for y in range(glyphs[slot].height)]) for slot in SLOTS}))
    OUT.mkdir(exist_ok=True)
    (OUT / 'cross-font-aliases.json').write_text(json.dumps(rows, indent=2) + '\n')
    image = Image.new('RGB', (1050, 830), 'white')
    draw = ImageDraw.Draw(image)
    font = '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
    title = ImageFont.truetype(font, 22)
    label = ImageFont.truetype(font, 16)
    small = ImageFont.truetype(font, 13)
    draw.text((16, 10), 'Grave and return aliases across Neo source fonts', font=title, fill='black')
    draw.text((16, 44), '6× exact pixels, full cells. No alignment or resampling of the source glyphs.', font=small, fill='#444444')
    columns = ['Terminal Medium', 'Neo system', 'Nano', 'Bold']
    for index, name in enumerate(columns):
        draw.text((130 + index * 220, 80), name, font=label, fill='black')
    for row, slot in enumerate(SLOTS):
        y = 120 + row * 170
        draw.text((16, y + 15), f'0x{slot:02X}', font=title, fill='black')
        for col, name in enumerate(columns):
            glyph = fonts[name][slot]
            x = 140 + col * 220
            mask = glyph.resize((glyph.width * 6, glyph.height * 6), Image.Resampling.NEAREST)
            image.paste('black', (x, y, x + mask.width, y + mask.height), mask)
            draw.text((x, y + 112), f'{glyph.width}px advance · {sum(bool(v) for v in glyph.getdata())} ink pixels', font=small, fill='#555555')
        draw.line((0, y + 155, image.width, y + 155), fill='#cccccc')
    image.save(OUT / 'grave-return-cross-font.png')
    for row in rows:
        print(row['font'], 'grave identical:', row['grave_identical'],
              'return identical:', row['return_identical'])


if __name__ == '__main__':
    main()
