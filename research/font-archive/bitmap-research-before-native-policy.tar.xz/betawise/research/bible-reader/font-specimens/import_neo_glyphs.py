#!/usr/bin/env python3
"""Add missing Neo-US glyphs from each face's original Unicode X11 strike.

Existing glyph blocks and metrics are preserved. New glyphs must fit the current
baseline/cell without pixel edits; unsupported/overflowing glyphs remain absent.
"""
import argparse
import gzip
import json
import re
import sys
from pathlib import Path

from PIL import Image
from verify_charset_review import UnicodePCF

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'fonts'))
sys.path.insert(0, str(ROOT / 'os3k'))
import fontgen
from charsets import glyph_name, load

STEMS = {'Serif': 'tim', 'Sans': 'helv', 'Book': 'ncen', 'Mono': 'cour'}
BLOCK = re.compile(r'STARTCHAR [^\n]+\nENCODING (\d+)\n.*?ENDCHAR\n', re.S)


def glyph_block(slot, image, descent, mapping):
    width, height = image.size
    rows = []
    for y in range(height):
        value = 0
        for x in range(width):
            value = (value << 1) | bool(image.getpixel((x, y)))
        value <<= (-width) % 8
        rows.append(f'{value:0{2*((width+7)//8)}X}')
    return (f'STARTCHAR {glyph_name(slot, mapping)}\nENCODING {slot}\n'
            f'SWIDTH 500 0\nDWIDTH {width} 0\nBBX {width} {height} 0 {-descent}\n'
            'BITMAP\n' + '\n'.join(rows) + '\nENDCHAR\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--apply', action='store_true')
    args = parser.parse_args()
    mapping = load(ROOT / 'os3k/charsets/neo-us.txt')
    codes = sorted(set(mapping.values()) - {None})
    UnicodePCF.candidates = codes
    code_index = {code: index for index, code in enumerate(codes)}
    records = []
    preserved = imported = 0
    for path in sorted((ROOT / 'fonts').glob('BetaWise*/*.bdf')):
        original = path.read_text()
        blocks = {int(match[1]): match[0] for match in BLOCK.finditer(original)}
        before, ascent, descent = fontgen.load_bdf(path)
        cells_before = fontgen.load(path, 'iso8859-1', 0x3f)
        height = ascent + descent
        additions = {}
        record = dict(path=str(path.relative_to(ROOT)), imported=[], unavailable=[], overflow=[])
        if 'Terminal' not in path.parent.name:
            family, size, style = path.stem.removeprefix('BetaWise').split('-')
            points = int(re.search(r'^POINT_SIZE (\d+)$', original, re.M)[1]) // 10
            dpi = int(re.search(r'^RESOLUTION_Y (\d+)$', original, re.M)[1])
            source_style = {'Regular': 'R', 'Bold': 'B', 'Italic': 'I', 'BoldItalic': 'BI'}[style]
            if family in ('Sans', 'Mono'):
                source_style = source_style.replace('I', 'O')
            source = Path('/usr/share/fonts/X11') / f'{dpi}dpi' / f'{STEMS[family]}{source_style}{points:02}.pcf.gz'
            with gzip.open(source, 'rb') as stream:
                reference = UnicodePCF(stream)
            assert reference.info[b'CHARSET_REGISTRY'] == b'ISO10646'
            record['source'] = str(source)
            for slot in range(256):
                if before[slot] is not None or mapping[slot] is None:
                    continue
                # Reuse an existing identical Unicode identity, including local fixes.
                aliases = [other for other in blocks if mapping[other] == mapping[slot]]
                if aliases:
                    image = cells_before[min(aliases)].copy()
                    origin = f'existing alias {min(aliases):02X}'
                else:
                    glyph = reference.glyph[code_index[mapping[slot]]]
                    if glyph is None:
                        record['unavailable'].append(f'{slot:02X}')
                        continue
                    advance, (left, top, right, bottom), rect, bitmap = glyph
                    ink = bitmap.crop(rect)
                    bounds = ink.getbbox()
                    if bounds and (top + bounds[1] < -ascent or top + bounds[3] > descent):
                        record['overflow'].append(dict(slot=f'{slot:02X}',
                            top=top+bounds[1], bottom=top+bounds[3], ascent=ascent, descent=descent))
                        continue
                    shift = max(0, -left)
                    width = max(advance[0] + shift, right + shift, 1)
                    # Preserve the reviewed six-line Mono's extra cell column.
                    if family == 'Mono' and size == 'Small':
                        width = max(width, cells_before[ord('A')].width)
                    image = Image.new('1', (width, height))
                    image.paste(ink, (left+shift, top+ascent))
                    assert sum(bool(p) for p in image.getdata()) == sum(bool(p) for p in ink.getdata())
                    origin = f'U+{mapping[slot]:04X}'
                additions[slot] = glyph_block(slot, image, descent, mapping)
                record['imported'].append(dict(slot=f'{slot:02X}', source=origin))
        updated = BLOCK.sub(lambda match: re.sub(r'^STARTCHAR [^\n]+',
                            'STARTCHAR '+glyph_name(int(match[1]), mapping), match[0]), original)
        # Keep every original block in place; append only newly implemented slots.
        updated = updated.replace('ENDFONT', ''.join(additions.values()) + 'ENDFONT')
        largest = max([cell.width for cell in cells_before] + [int(re.search(r'DWIDTH (\d+)', block)[1]) for block in additions.values()])
        updated = re.sub(r'^(FONTBOUNDINGBOX )([0-9]+)', lambda match: match[1] + str(max(int(match[2]), largest)), updated, flags=re.M)
        updated = re.sub(r'^CHARS \d+$', f'CHARS {len(blocks)+len(additions)}', updated, flags=re.M)
        if args.apply and updated != original:
            path.write_text(updated)
        if args.apply:
            after, new_ascent, new_descent = fontgen.load_bdf(path)
            cells_after = fontgen.load(path, 'iso8859-1', 0x3f)
            assert (new_ascent, new_descent) == (ascent, descent)
            for slot in blocks:
                a, b = cells_before[slot], cells_after[slot]
                assert a.size == b.size and a.tobytes() == b.tobytes(), (path, slot)
            after_blocks = {int(match[1]): match[0] for match in BLOCK.finditer(path.read_text())}
            for slot, block in blocks.items():
                assert block.split('\n',1)[1] == after_blocks[slot].split('\n',1)[1], (path, slot)
        preserved += len(blocks)
        imported += len(additions)
        records.append(record)
    result = dict(applied=args.apply, existing_glyphs_preserved=preserved,
                  imported_glyphs=imported, fonts=records)
    destination = Path(__file__).with_name('charset-review') / 'glyph-import.json'
    if args.apply:
        destination.write_text(json.dumps(result, indent=2)+'\n')
    print(f'{"Applied" if args.apply else "Preview"}: {len(records)} faces; '
          f'{preserved:,} existing glyphs preserved; {imported:,} additions; '
          f'{sum(len(r["overflow"]) for r in records)} source glyphs exceed current cells; '
          f'{sum(len(r["unavailable"]) for r in records)} unavailable in original strikes.')


if __name__ == '__main__':
    main()
