#!/usr/bin/env python3
"""Place original vendor source glyphs beside labelled Unicode font examples."""
import json
from pathlib import Path

from fontTools.ttLib import TTFont
from PIL import Image, ImageDraw, ImageFont

OUT = Path(__file__).with_name('charset-review')
FONTDIR = Path('/usr/share/fonts/truetype/dejavu')


def main():
    records = {r['font']: r for r in json.loads((OUT / 'vendor-glyph-audit.json').read_text())}
    image = Image.new('RGB', (1420, 730), 'white')
    draw = ImageDraw.Draw(image)
    title = ImageFont.truetype(str(FONTDIR / 'DejaVuSans.ttf'), 25)
    label = ImageFont.truetype(str(FONTDIR / 'DejaVuSans.ttf'), 18)
    small = ImageFont.truetype(str(FONTDIR / 'DejaVuSans.ttf'), 15)
    draw.text((20, 12), 'Neo vendor symbols and Unicode candidates', font=title, fill='black')
    draw.text((20, 51), 'Vendor: full bitmap cells, exact pixels enlarged 4×. Unicode: illustrative DejaVu designs, not authoritative shapes.', font=small, fill='#555555')
    candidates = {
        '17': [(0x25af, 'White vertical rectangle', 'DejaVuSans.ttf'),
               (0x2395, 'APL quad', 'DejaVuSansMono.ttf'),
               (0x25a1, 'White square', 'DejaVuSans.ttf')],
        '18': [(0x221a, 'Square root — Sans', 'DejaVuSans.ttf'),
               (0x221a, 'Square root — Serif', 'DejaVuSerif.ttf'),
               (0x2713, 'Check mark', 'DejaVuSans.ttf')],
    }
    for row, slot in enumerate(['17', '18']):
        top = 95 + row * 310
        draw.text((20, top), f'Native byte 0x{slot}', font=title, fill='black')
        for col, name in enumerate(['Very Large', 'Extra Large']):
            x = 20 + col * 280
            draw.text((x, top + 43), 'Vendor ' + name, font=label, fill='black')
            data = records[name]['glyphs'][slot]
            glyph = Image.new('1', (data['width'], len(data['rows'])))
            for y, pixels in enumerate(data['rows']):
                for xx, value in enumerate(pixels):
                    glyph.putpixel((xx, y), int(value))
            glyph = glyph.resize((glyph.width * 4, glyph.height * 4), Image.Resampling.NEAREST)
            px, py = x + 65, top + 88
            draw.rectangle((px-1, py-1, px+glyph.width, py+glyph.height), outline='#bbbbbb')
            image.paste('black', (px, py, px+glyph.width, py+glyph.height), glyph)
            draw.text((x, top+240), f"{data['width']}×{len(data['rows'])} original cell", font=small, fill='#555555')
        for col, (code, name, filename) in enumerate(candidates[slot], 2):
            x = 20 + col * 280
            path = FONTDIR / filename
            assert code in TTFont(path).getBestCmap(), (path, code)
            draw.text((x, top+43), name, font=label, fill='black')
            face = ImageFont.truetype(str(path), 120)
            draw.text((x+50, top+80), chr(code), font=face, fill='black', embedded_color=False)
            draw.text((x, top+240), f'U+{code:04X} · {filename.removesuffix(".ttf")}', font=small, fill='#555555')
        draw.line((20, top+280, 1400, top+280), fill='#cccccc')
    image.save(OUT / 'vendor-symbol-candidates.png')


if __name__ == '__main__':
    main()
