#!/usr/bin/env python3
"""Compare four-row step and per-glyph continuity-guided inflections.
Source-bitmap design study, never a Neo screenshot validation oracle.
"""
from collections import deque
import json,shutil,unicodedata
from PIL import Image,ImageDraw
import build as b
import reader_candidates as reader
OUT=b.HERE/'courier-inflection'

# Explicit design choices after reviewing the a/W source row grids.
CUT_OVERRIDES={
 (3,'I',0x61):5,(3,'BI',0x61):5,
 (4,'I',0x61):4,(4,'BI',0x61):4,
 (5,'I',0x61):4,(5,'BI',0x61):4,
 (5,'I',0x57):3,(5,'BI',0x57):3,
 (6,'I',0x57):3,(6,'BI',0x57):3}
# Coordinates after the constant glyph placement; all are displayed in audit.
MIDDLE_EDITS={
 (5,'I',0x57):[((1,-3),None),(None,(3,-3))],
 (5,'BI',0x57):[((0,-3),None)],
 (6,'I',0x57):[((0,-3),None),(None,(2,-3))],
 (6,'BI',0x57):[((0,-3),(1,-3)),((2,-3),(3,-3)),((4,-3),(5,-3)),
                 ((0,-2),(1,-2)),(None,(3,-2))]}

def components(points,diagonal=True):
 todo=set(points);n=0
 neigh=[(x,y)for x in [-1,0,1]for y in [-1,0,1]if(x or y)and(diagonal or not(x and y))]
 while todo:
  n+=1;stack=[todo.pop()]
  while stack:
   x,y=stack.pop()
   for dx,dy in neigh:
    p=x+dx,y+dy
    if p in todo:todo.remove(p);stack.append(p)
 return n

def topology(points):
 if not points:return 0,0
 lo=min(x for x,y in points)-1;hi=max(x for x,y in points)+1
 top=min(y for x,y in points)-1;bottom=max(y for x,y in points)+1
 white={(x,y)for x in range(lo,hi+1)for y in range(top,bottom+1)}-points
 return components(points),components(white,False)-1

def shape(points,w,cut):
 moved={(x+int(y<-cut),y)for x,y in points}
 if not moved:return set(),dict(offset=0,removed=[])
 lo=min(x for x,y in moved);hi=max(x for x,y in moved)+1
 if hi-lo<=w:offset=max(-lo,min(0,w-hi))
 else:offset=min(range(-hi,w-lo+1),key=lambda s:(sum(not 0<=x+s<w for x,y in moved),abs(s),s))
 removed=sorted((x,y)for x,y in moved if not 0<=x+offset<w)
 result={(x+offset,y)for x,y in moved if 0<=x+offset<w}
 assert len(result)==len(points)-len(removed)
 return result,dict(offset=offset,removed=removed)

def pick(points,w):
 if not points:return set(),dict(cut=4,offset=0,removed=[],score=0)
 original=topology(points);height=max(1,-min(y for x,y in points))
 best=None
 for cut in range(2,max(3,min(7,height))):
  result,record=shape(points,w,cut);after=topology(result)
  upper={x for x,y in points if y==-cut-1};lower={x for x,y in points if y==-cut}
  # Count boundary pixels that had a cross-row neighbor but lose every one
  # after the one-pixel displacement. This targets broken diagonal strokes.
  orphan=sum(any(abs(x-z)<=1 for z in lower)and not any(abs(x+1-z)<=1 for z in lower)for x in upper)
  orphan+=sum(any(abs(x-z)<=1 for z in upper)and not any(abs(x-(z+1))<=1 for z in upper)for x in lower)
  before_edges=sum(abs(x-z)<=1 for x in upper for z in lower)
  after_edges=sum(abs(x+1-z)<=1 for x in upper for z in lower)
  score=6*len(record['removed'])+20*abs(after[0]-original[0])+12*abs(after[1]-original[1])+10*orphan+.2*max(0,before_edges-after_edges)+.5*abs(cut-4)
  candidate=(score,abs(cut-4),cut,result,dict(cut=cut,score=score,source_topology=original,result_topology=after,orphaned_boundary_pixels=orphan,**record))
  if best is None or candidate[:3]<best[:3]:best=candidate
 return best[3],best[4]

def cell(points,w,pitch,baseline):
 g=Image.new('1',(w,pitch))
 for x,y in points:
  assert 0<=x<w and 0<=y+baseline<pitch
  g.putpixel((x,y+baseline),1)
 return g

def main():
 OUT.mkdir(exist_ok=True);shutil.copyfile(b.OUT/'FONT-LICENSE.txt',OUT/'FONT-LICENSE.txt')
 reports=[];panels=[];focus=[]
 for lines,pitch in reader.ROWS:
  smooth,meta,_,source=reader.smooth_courier(lines,pitch);w=meta['width'];baseline=meta['baseline']
  bases={s:{c:set(p)for c,p in source[s].items()}for s in ['R','B']}
  for s,c,op,np in reader.PATCHES[lines]:
   bases[s][c].remove(op)
   if np is not None:bases[s][c].add(np)
  variants={k:{'R':smooth['R'],'B':smooth['B'],'I':{},'BI':{}}for k in ['bottom3','bottom4','tuned']}
  records={k:{}for k in variants}
  for st,base in [('I','R'),('BI','B')]:
   for mode in variants:
    records[mode][st]={}
   for c,points in bases[base].items():
    for mode,cut in [('bottom3',3),('bottom4',4),('tuned',None)]:
     if cut is None:
      override=CUT_OVERRIDES.get((lines,st,c))
      if override is None:
       basechar=unicodedata.normalize('NFD',bytes([c]).decode('cp1252'))[0]
       if ord(basechar)<128:override=CUT_OVERRIDES.get((lines,st,ord(basechar)))
      if override is None:result,record=pick(points,w)
      else:
       result,record=shape(points,w,override);record.update(cut=override,manual_cut=True)
      edits=MIDDLE_EDITS.get((lines,st,c),[])
      for oldpt,newpt in edits:
       if oldpt is not None:
        assert oldpt in result,(lines,st,c,oldpt);result.remove(oldpt)
       if newpt is not None:
        assert newpt not in result and 0<=newpt[0]<w,(lines,st,c,newpt);result.add(newpt)
      if edits:record['middle_edits']=[dict(old=op,new=np)for op,np in edits]
      record['final_topology']=topology(result)
     else:result,record=shape(points,w,cut);record['cut']=cut
     variants[mode][st][c]=cell(result,w,pitch,baseline);records[mode][st][f'{c:02X}']=record
  for st,face in variants['tuned'].items():reader.export(OUT/f'cour-{lines}-lines-{st}.bdf',face,baseline)
  for st in ['I','BI']:reader.export(OUT/f'cour-{lines}-bottom4-{st}.bdf',variants['bottom4'][st],baseline)
  panel=Image.new('RGB',(2700,145+2*(120+pitch*12)),'white');d=ImageDraw.Draw(panel)
  d.text((12,8),f'Courier {lines} lines — fixed {w}px width, {264//w} columns; all specimens 4× nearest-neighbour',font=b.TITLE,fill='black')
  d.text((12,40),'Glyph-specific draft: a/W have explicit transition choices and W middle-row corrections. Other cuts use a continuity heuristic.',font=b.SMALL,fill='#444444')
  for j,(mode,title)in enumerate([('bottom3','Previous: bottom three aligned'),('bottom4','Trial: bottom four aligned'),('tuned','Glyph-specific inflection')]):
   x=12+j*900;d.text((x,76),title,font=b.LABEL,fill='black')
   trims=sum(len(rec['removed'])for face in records[mode].values()for rec in face.values())
   d.text((x,101),f'{trims} edge trims; middle corrections in glyph-specific draft recorded separately',font=b.SMALL,fill='#a02020'if trims else'#335533')
   for i,st in enumerate(['I','BI']):
    y=140+i*(120+pitch*12);d.text((x,y),st,font=b.LABEL,fill='black')
    for k,text in enumerate(['AaBbCcDdEeFfGg','aWaW HIlmnp MW ij','Reading the book.']):
     mask=b.render_run(variants[mode][st],text.encode());assert mask.width*4<875
     b.draw_ink(panel,mask,(x,y+27+k*(pitch*4+7)),4)
   # Native-page assets, separate from enlarged source specimens.
   for st in ['I','BI']:
    page,_=b.page(variants[mode][st],lines,pitch);native=Image.new('RGB',page.size,'white');native.paste('black',(0,0),page)
    native.save(OUT/f'{lines}-{mode}-{st}-native.png')
  panel.save(OUT/f'{lines}-lines.png');panels.append(panel)
  if lines==5:panel.crop((1800,0,2700,panel.height)).save(OUT/'5-lines-tuned.png')
  for st in ['I','BI']:
   for char in ['a','W']:
    focus.append((lines,pitch,w,baseline,st,char,bases['R'if st=='I'else'B'][ord(char)],{k:variants[k][st][ord(char)]for k in variants},records['tuned'][st][f'{ord(char):02X}']))
  reports.append(dict(lines=lines,width=w,columns=264//w,remainder=264%w,baseline=baseline,base_patches=meta['patches'],variants=records))
 # Pixel grids isolate a/W, showing where each transition crosses actual rows.
 audit=Image.new('RGB',(1500,90+len(focus)*185),'white');ad=ImageDraw.Draw(audit)
 ad.text((12,8),'a / W: exact source and transition choices, 8× pixel grid',font=b.TITLE,fill='black')
 for j,label in enumerate(['Upright source','Bottom three','Bottom four','Glyph-specific']):ad.text((240+j*300,45),label,font=b.LABEL,fill='black')
 for i,(lines,pitch,w,baseline,st,ch,pts,faces,rec)in enumerate(focus):
  y=85+i*185;ad.text((12,y),f'{lines} lines {st} {ch}',font=b.LABEL,fill='black');ad.text((12,y+28),f'Tuned cut: {rec["cut"]} rows',font=b.SMALL,fill='#555555')
  lo=min([x for x,y in pts]+[0]);raw=cell({(x-lo,yy)for x,yy in pts},max(w,max([x-lo+1 for x,y in pts]+[1])),pitch,baseline)
  for j,g in enumerate([raw,faces['bottom3'],faces['bottom4'],faces['tuned']]):
   x=240+j*300;b.draw_ink(audit,g,(x,y),8)
   for xx in range(g.width+1):ad.line((x+xx*8,y,x+xx*8,y+pitch*8),fill='#dddddd')
   for yy in range(pitch+1):ad.line((x,y+yy*8,x+g.width*8,y+yy*8),fill='#dddddd')
   if j:
    cut=3 if j==1 else 4 if j==2 else rec['cut'];line_y=y+(baseline-cut)*8
    ad.line((x,line_y,x+g.width*8,line_y),fill='#b3472b',width=2)
 audit.save(OUT/'a-W-grid.png')
 (OUT/'report.json').write_text(json.dumps(dict(method='Bottom-four trial plus continuity-guided per-glyph inflections, explicit a/W cut overrides, and recorded W middle-row corrections. No model inference or increased width.',status='Design alternatives. Previous combined reader-candidates preserved.',coverage='218 Western printable native-byte slots; full Neo device mapping incomplete.',fonts=reports,validation=dict(bdf_faces=24,roundtrip_glyphs=24*len(b.CODES),checks='Exact source row displacement except recorded edge trims and middle-row edits; exact BDF pixel/advance round trip; no vertical shifts or gray pixels.')),indent=2)+'\n')
 (OUT/'index.html').write_text('<!doctype html><meta charset="utf-8"><title>Courier inflection trials</title><style>body{font:17px sans-serif;margin:24px}img{max-width:100%;image-rendering:pixelated}.native{width:264px;height:65px}</style><h1>Courier bottom-four and glyph-specific inflections</h1><p>All cells keep the same width. A one-pixel right shift is applied above the selected baseline-relative cut. a/W have explicit per-glyph cut choices; W also has recorded middle-row edits to avoid spurs and disconnected diagonals. Other glyphs use a continuity heuristic. This is a design trial, not automatic proof of readability. Edge trims and all additional pixel edits are explicit in the report.</p>'+''.join(f'<h2>{lines} lines</h2><a href="{lines}-lines.png"><img src="{lines}-lines.png"></a><p>Tuned native 264×65 pages, I / BI:</p><img class="native" src="{lines}-tuned-I-native.png"><img class="native" src="{lines}-tuned-BI-native.png">'for lines,pitch in reader.ROWS)+'<h2>a / W pixel grids</h2><a href="a-W-grid.png"><img src="a-W-grid.png"></a><p><a href="report.json">Every per-glyph cut, edge correction and check</a></p>')
 for r in reports:print(r['lines'],{st:{c:r['variants']['tuned'][st][f'{ord(c):02X}']['cut']for c in 'aW'}for st in ['I','BI']})
 print(OUT/'index.html')
if __name__=='__main__':main()
