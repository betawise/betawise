"""Pin cedilla letter bodies to selected C/c, shorten the mark instead."""
import re
from PIL import Image
import build as b

def points(g):
 return {(x,y)for y in range(g.height)for x in range(g.width)if g.getpixel((x,y))}

def native(g):
 advance,box,src,bitmap=g;left,top,_,_=box;im=bitmap.crop(src)
 return {(x+left,y+top)for y in range(im.height)for x in range(im.width)if im.getpixel((x,y))}

def shorten(mark,room):
 result=set(mark);steps=[]
 while result and max(y for x,y in result)>=room:
  height=max(y for x,y in result)+1
  assert height>1,('more than one row shortening needed',height,room)
  candidates=list(range(1,height-1))or[0]
  rows={y:{x for x,yy in result if yy==y}for y in range(height)}
  row=min(candidates,key=lambda y:(0 if not rows[y]else 1 if rows[y]==rows.get(y-1)or rows[y]==rows.get(y+1)else 2,len(rows[y]),abs(y-(height-1)/2)))
  steps.append(dict(removed_row=row,removed_pixels=sorted((x,y)for x,y in result if y==row)))
  result={(x,y-int(y>row))for x,y in result if y!=row}
 return result,steps

def repair(stem,styles,lines,pitch,faces,meta):
 baseline=meta['baseline'];limit=10 if lines==6 else pitch;room=limit-baseline
 assert room>=1
 result={st:dict(face)for st,face in faces.items()};records=[]
 for st,source_style in zip(['R','B','I','BI'],styles):
  if stem=='cour':
   path=meta['sources'][source_style]['path'];pt=int(re.search(r'cour(?:BO|B|O|R)(\d+)\.pcf',path)[1]);dpi=int(path.split('/')[-2].removesuffix('dpi'))
  else:pt=meta.get('points',8);dpi=meta.get('dpi',75)
  source_path,source=b.source(stem,source_style,pt,dpi)
  for code,basecode in [(0xc7,0x43),(0xe7,0x63),(0xb8,None)]:
   raw=native(source[code])
   if basecode is None:
    mark=raw; width=faces[st][code].width;body=set();dx=max(0,-source[code][1][0])
   else:
    glyph=faces[st][basecode];width=glyph.width;body=points(glyph)
    assert all(y<baseline for x,y in body),(stem,lines,st,basecode,baseline)
    # Native letter bearings can differ from the selected normalized cells.
    # Recover only horizontal placement; never change a base letter's y.
    rawbase=native(source[basecode]);target={(x,y-baseline)for x,y in body}
    dx=min(range(-5,6),key=lambda d:(len({(x+d,y)for x,y in rawbase}^target),abs(d)))
    # Attachment pixels at/above baseline may be native shorthand substitutions
    # for C's bottom row. They must not replace any plain C/c body pixel.
    mark={(x,y)for x,y in raw if y>=0}
    if not mark:
     standalone=native(source[0xb8]);start=min(y for x,y in standalone)
     mark={(x,y-start)for x,y in standalone}
   mark={(x+dx,y)for x,y in mark};original_mark=set(mark)
   mark,steps=shorten(mark,room)
   if mark:
    left=min(x for x,y in mark);right=max(x for x,y in mark)+1
    assert right-left<=width,(stem,st,lines,code,width,mark)
    mark_dx=max(-left,min(0,width-right))
    if stem=='helv' and lines==6:mark_dx=min(mark_dx+1,width-right)
    mark={(x+mark_dx,y)for x,y in mark}
   else:mark_dx=0
   allpoints=body|{(x,y+baseline)for x,y in mark}
   image=Image.new('1',(width,pitch))
   for x,y in allpoints:
    assert 0<=x<width and 0<=y<limit
    image.putpixel((x,y),1)
   if basecode is not None:
    assert {(x,y)for x,y in points(image)if y<baseline}==body
    assert image.width==faces[st][basecode].width
   previous=points(faces[st][code]);result[st][code]=image
   records.append(dict(style=st,slot=f'{code:02X}',character=bytes([code]).decode('cp1252'),base_slot=f'{basecode:02X}'if basecode is not None else None,
    source=str(source_path),base_body_exact=basecode is not None,body_y_shift=0,base_x_alignment=dx,mark_x_adjustment=mark_dx,
    native_lower_rows=max([y+1 for x,y in original_mark]+[0]),available_lower_rows=room,shortened_rows=len(steps),shortening=steps,
    removed=sorted(previous-allpoints),added=sorted(allpoints-previous),width_before=faces[st][code].width,width_after=width))
 return result,records
