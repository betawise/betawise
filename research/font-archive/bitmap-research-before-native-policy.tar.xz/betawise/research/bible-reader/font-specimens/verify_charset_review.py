#!/usr/bin/env python3
"""Compare human-reviewed Neo glyph identities with exact X11 PCF patterns.

This is offline font-resource research, not a Neo screen decoder/test oracle.
No source artwork or mapping entries are changed by running this script.
"""
import argparse
import gzip
import itertools
import json
import sys
import unicodedata
from pathlib import Path

from PIL import Image, PcfFontFile

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'fonts'))
import fontgen

OUT = Path(__file__).with_name('charset-review')
SLOTS = [*range(32), 127, 129, 141, 143, 144, 157]
ALTERNATIVES = {0x0143, 0x0144, 0x0132, 0x0133, 0x2310, 0x231c,
                0x21a9, 0x21b2, 0x21b5, 0x21b6, 0x2936, 0x0060,
                0x02cb, 0x0300, 0x25a1, 0x2395, 0x23ce, 0x21b0,
                0x21b3, 0x21ab, 0x004e, 0x006e}
FONT_NAMES = ['4x6', '5x7', '5x8', '6x9', '6x10', '6x12', '6x13',
              '7x13', '7x14', '8x13', '8x16']


class UnicodePCF(PcfFontFile.PcfFontFile):
    """Use Pillow's bitmap reader with an explicit Unicode selection."""
    candidates = []

    def _load_encoding(self):
        stream, _, read16, _ = self._getformat(PcfFontFile.PCF_BDF_ENCODINGS)
        first_col, last_col, first_row, last_row, _ = [read16(stream.read(2)) for _ in range(5)]
        columns = last_col - first_col + 1
        entries = [read16(stream.read(2)) for _ in range(columns * (last_row - first_row + 1))]
        result = [None] * 256
        assert len(self.candidates) <= 256
        for slot, code in enumerate(self.candidates):
            row, col = code >> 8, code & 255
            if first_row <= row <= last_row and first_col <= col <= last_col:
                index = entries[(row - first_row) * columns + col - first_col]
                if index != 0xffff:
                    result[slot] = index
        return result


def signature(image):
    """Remove blank margins and repeated rows, retaining exact column pixels."""
    box = image.getbbox()
    if not box:
        return ()
    image = image.crop(box)
    rows = [tuple(bool(image.getpixel((x, y))) for x in range(image.width))
            for y in range(image.height)]
    return tuple(row for row, _ in itertools.groupby(rows))


def image_rows(image):
    return [[int(bool(image.getpixel((x, y)))) for x in range(image.width)]
            for y in range(image.height)]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('review', type=Path)
    args = parser.parse_args()
    review = json.loads(args.review.read_text())
    assert review['format'] == 'betawise-font-fixes-v1'
    values = sorted({r.get('unicode', r.get('currentUnicode')) for r in review['mapping']
                     if r.get('unicode', r.get('currentUnicode')) is not None} | ALTERNATIVES)
    assert all(isinstance(c, int) and 0 <= c <= 0x10ffff for c in values)
    UnicodePCF.candidates = values
    terminal = fontgen.load(ROOT / 'fonts/BetaWiseTerminal/glyphs.bdf', 'iso8859-1')
    audit_path = ROOT.parent / '.research-work/font-charset-audit/audit.json'
    audit = json.loads(audit_path.read_text())
    system = []
    for rows in audit['fonts']['system']['glyphs']:
        image = Image.new('1', (len(rows[0]), len(rows)))
        for y, row in enumerate(rows):
            for x, value in enumerate(row):
                image.putpixel((x, y), value)
        system.append(image)
    for slot in range(256):
        assert image_rows(terminal[slot]) == audit['slots'][slot]['terminal']
    references = {value: [] for value in values}
    for name in FONT_NAMES:
        path = Path('/usr/share/fonts/X11/misc') / (name + '.pcf.gz')
        if not path.is_file():
            continue
        with gzip.open(path, 'rb') as stream:
            font = UnicodePCF(stream)
        if font.info[b'CHARSET_REGISTRY'] != b'ISO10646':
            continue
        for slot, code in enumerate(values):
            glyph = font.glyph[slot]
            if glyph:
                references[code].append((path.name, signature(glyph[3].crop(glyph[2]))))
    report = []
    for slot in SLOTS:
        row = dict(slot=f'{slot:02X}', system_terminal_equal_signature=(
            signature(terminal[slot]) == signature(system[slot])), matches=[])
        for code, fonts in references.items():
            matched = [name for name, pattern in fonts if pattern and pattern == signature(system[slot])]
            if matched:
                row['matches'].append(dict(unicode=f'{code:04X}', char=chr(code),
                                           name=unicodedata.name(chr(code)), fonts=matched))
        report.append(row)
    OUT.mkdir(exist_ok=True)
    (OUT / 'exact-reference-matches.json').write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n')
    raw = dict(scope='Source glyph bitmaps, not screenshots',
               system_source=str(audit_path), terminal_source='fonts/BetaWiseTerminal/glyphs.bdf',
               glyphs=[dict(slot=f'{slot:02X}', system=image_rows(system[slot]),
                            terminal=image_rows(terminal[slot])) for slot in SLOTS])
    (OUT / 'native-bitmaps.json').write_text(json.dumps(raw, indent=2) + '\n')
    print(f'Recorded {len(report)} native glyphs; {sum(bool(r["matches"]) for r in report)} '
          'have exact normalized reference matches. Matches may be ambiguous.')


if __name__ == '__main__':
    main()
