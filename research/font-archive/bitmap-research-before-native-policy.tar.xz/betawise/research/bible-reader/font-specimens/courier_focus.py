#!/usr/bin/env python3
"""Native Courier comparison and exact outlier audit; proposed accent moves only."""
import json
from pathlib import Path
from PIL import Image,ImageDraw
import build as b
STYLES=('R','B','O','BO')
CASES=[dict(pixels=12,pt=12,dpi=75,lines=5,pitch=13,limit=13),
       dict(pixels=11,pt=8,dpi=100,lines=6,pitch=11,limit=10)]

def audit(case):
    faces=[b.source('cour',s,case['pt'],case['dpi'])[1] for s in STYLES]
    top,bottom=b.envelope(faces,range(32,127));bad=[];all_changes=[];proposed={}
    bodies=[]
    for style,face in zip(STYLES,faces):
        body={}
        for c in range(32,127):
            ink,t,_=b.raw(face[c]);cell=Image.new('1',(ink.width,case['pitch']));cell.paste(ink,(0,t-top));body[c]=cell
            assert sum(bool(v)for v in cell.getdata())==sum(bool(v)for v in ink.getdata())
        bodies.append(body)
        for c in b.CODES:
            ink,t,_=b.raw(face[c]);box=ink.getbbox()
            if not box or top<=t+box[1] and t+box[3]<=top+case['limit']:continue
            char=bytes([c]).decode('cp1252')
            original={(x,y+t) for y in range(ink.height) for x in range(ink.width) if ink.getpixel((x,y))}
            ref=ord('H') if char.isupper() else ord('x');ri,rt,_=b.raw(face[ref]);split=rt+ri.getbbox()[1]
            moved={(x,y+1 if y<split else y)for x,y in original}
            okay=len(moved)==len(original) and min(y for x,y in moved)>=top and max(y for x,y in moved)<top+case['limit']
            entry=dict(code=f'{c:02X}',character=char,style=style,
                       above_rows=max(0,top-t-box[1]),below_rows=max(0,t+box[3]-top-case['limit']),
                       simple_upper_band_move_viable=okay,source_pixels=len(original),proposed_pixels=len(moved))
            bad.append(entry)
            if okay:
                cell=Image.new('1',(ink.width,case['pitch']))
                for x,y in moved:cell.putpixel((x,y-top),1)
                assert all((x,y) in moved for x,y in original if y>=split)
                proposed[(style,c)]=cell
                all_changes.append(entry)
    return dict(**case,baseline=-top,ascii_height=bottom-top,western_height=b.envelope(faces)[1]-b.envelope(faces)[0],
                unique_outliers=sorted({e['code'] for e in bad}),outliers=bad,proposed_changes=all_changes),bodies,faces,proposed

def main():
    b.OUT.mkdir(exist_ok=True)
    image=Image.new('RGB',(1660,380),'white');draw=ImageDraw.Draw(image)
    draw.text((12,8),'Native Courier: 12px at five lines vs 11px at six lines',font=b.TITLE,fill='black')
    draw.text((12,39),'Identical passage starts; native glyph pixels and advances; 264 × 65 screen shown at integer 3×.',font=b.SMALL,fill='#444444')
    reports=[]
    for col,case in enumerate(CASES):
        report,bodies,faces,proposed=audit(case);reports.append(report)
        x=12+col*824
        draw.text((x,68),f"{case['pixels']}px · {case['pt']}pt/{case['dpi']}dpi · {case['lines']} lines · {case['pitch']}px pitch",font=b.LABEL,fill='black')
        mask,text=b.page(bodies[0],case['lines'],case['pitch'])
        b.draw_ink(image,mask,(x,102),3);draw.rectangle((x-1,101,x+792,297),outline='#888888')
        draw.text((x,313),f"{len(report['unique_outliers'])} extended characters need local edits across the four styles.",font=b.SMALL,fill='#444444')
        draw.text((x,338),'No extended characters occur in this English sample; no body glyphs were edited.',font=b.SMALL,fill='#444444')
        report['page_text']=text
        codes=[int(c,16)for c in report['unique_outliers']]
        grid=Image.new('RGB',(max(1200,80*len(codes)+120),820),'white');gd=ImageDraw.Draw(grid)
        gd.text((12,10),f"Courier {case['pixels']}px: outliers and proposed one-row upper-band moves",font=b.TITLE,fill='black')
        gd.text((12,43),'Gray = available ink window. Native source above proposed candidate; red MANUAL = move would merge ink. Not approved edits.',font=b.SMALL,fill='#444444')
        for row,style in enumerate(STYLES):
            sy=82+row*181;gd.text((12,sy+30),style,font=b.LABEL,fill='black')
            for col,c in enumerate(codes):
                x=90+col*80;gd.text((x,sy),f'{bytes([c]).decode("cp1252")} {c:02X}',font=b.SMALL,fill='#333333')
                ink,t,_=b.raw(faces[row][c]);pad=3
                original=Image.new('1',(ink.width,case['pitch']+6));original.paste(ink,(0,t+report['baseline']+pad))
                gy=sy+28;gd.rectangle((x,gy+pad*3,x+68,gy+(pad+case['limit'])*3-1),fill='#eeeeee')
                b.draw_ink(grid,original,(x+8,gy),3)
                gy=sy+103;gd.rectangle((x,gy,x+68,gy+case['limit']*3-1),fill='#eeeeee')
                if (style,c)in proposed:b.draw_ink(grid,proposed[(style,c)],(x+8,gy),3)
                else:gd.text((x,gy+8),'MANUAL',font=b.SMALL,fill='#a02020')
        grid.save(b.OUT/f"courier-{case['pixels']}px-outliers.png")
    image.save(b.OUT/'courier-12px-five-vs-11px-six.png')
    # Smaller strikes are native alternatives, not resized versions of the 11px strike.
    alternate=Image.new('RGB',(1140,630),'white');ad=ImageDraw.Draw(alternate)
    ad.text((12,8),'Courier alternatives — native regular pixels, integer 3× display',font=b.TITLE,fill='black')
    alternatives=[]
    for row,(pt,dpi,pixels)in enumerate([(8,75,8),(10,75,10),(8,100,11),(12,75,12)]):
        faces=[b.source('cour',s,pt,dpi)[1]for s in STYLES];top,bottom=b.envelope(faces);at,ab=b.envelope(faces,range(32,127))
        body={}
        for c in 'The quick brown fox, AaÑg 0123456789.'.encode('cp1252'):
            ink,t,_=b.raw(faces[0][c]);im=Image.new('1',(ink.width,bottom-top));im.paste(ink,(0,t-top));body[c]=im
        y=58+row*140
        ad.text((12,y),f'{pixels}px / {pt}pt / {dpi}dpi — four-style ink: ASCII {ab-at}px, Windows-1252 {bottom-top}px',font=b.LABEL,fill='black')
        b.draw_ink(alternate,b.render_run(body,'The quick brown fox, AaÑg 0123456789.'.encode('cp1252')),(12,y+35),3)
        alternatives.append(dict(pixels=pixels,points=pt,dpi=dpi,ascii_height=ab-at,western_height=bottom-top))
    alternate.save(b.OUT/'courier-native-alternatives.png')
    result=dict(cases=reports,alternatives=alternatives,scope='Native comparison and review proposals, no installed fonts changed')
    (b.OUT/'courier-focus.json').write_text(json.dumps(result,indent=2)+'\n')
    rows=['# Courier native strike comparison','',
          'Windows-1252 (previously labelled “Western”) adds printable glyphs in the 80–9F region to the ISO-8859-1/Latin-1 repertoire. These are glyph repertoires, not a claim that Neo editor control bytes become printable.','']
    for r in reports:
        rows += [f"## {r['pixels']}px at {r['lines']} lines",'',
                 f"Native {r['pt']}pt/{r['dpi']}dpi. ASCII ink envelope {r['ascii_height']} rows; complete Western envelope {r['western_height']} rows. Required budget {r['limit']} rows.",'',
                 'Outliers: '+' '.join(f"`{c}` {bytes([int(c,16)]).decode('cp1252')}"for c in r['unique_outliers'])+'.','',
                 'Each extends one row above the selected shared ASCII baseline window. Upper-band translation proposals preserve all pixels, the base-letter region and advance unless marked MANUAL.','']
        manual=[e for e in r['outliers']if not e['simple_upper_band_move_viable']]
        rows+=['Manual cases: '+', '.join(f"{e['character']} ({e['style']})"for e in manual)+'.','']
    rows+=['## Selection policy','',
           'The previous rule preferred full Western coverage, then Latin-1, then ASCII, and only then chose the largest XLFD pixel size. That made the five-line Courier smaller than the largest native ASCII option. The comparison explicitly shows the 12px five-line candidate instead.','',
           'The nominal 8px Courier has an 11-row shared ASCII envelope across its four styles. Nominal point/pixel sizes are not bounding-box heights. It also has a fixed advance of five pixels versus six for the 10px/11px options, so it remains a meaningful narrow alternative. Its shared baseline envelope does not make it a lossless seven-line font.']
    (b.OUT/'courier-focus.md').write_text('\n'.join(rows)+'\n')
    print(json.dumps({'image':str(b.OUT/'courier-12px-five-vs-11px-six.png'),
                     'unique_outliers':[{str(r['pixels']):len(r['unique_outliers'])}for r in reports]},indent=2))
if __name__=='__main__':main()
