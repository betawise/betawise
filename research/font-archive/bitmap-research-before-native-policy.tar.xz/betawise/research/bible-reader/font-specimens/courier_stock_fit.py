#!/usr/bin/env python3
"""Stock-slant Courier, common +1px cells, local mark/edge repairs only."""
from pathlib import Path
from collections import deque
import gzip,json,hashlib,shutil,unicodedata
from PIL import Image,ImageDraw,PcfFontFile,ImageFont
import build as b
import evaluate_substitutes as e
import reader_candidates as writer
OUT=b.HERE/'courier-stock-fit'
STYLES=['R','B','O','BO']

def components(points,diagonal=True):
 todo=set(points);count=0
 neighbors=[(dx,dy)for dx in [-1,0,1]for dy in [-1,0,1]if(dx or dy)and(diagonal or not(dx and dy))]
 while todo:
  count+=1;stack=[todo.pop()]
  while stack:
   x,y=stack.pop()
   for dx,dy in neighbors:
    q=x+dx,y+dy
    if q in todo:todo.remove(q);stack.append(q)
 return count

def topology(points):
 if not points:return(0,0)
 left=min(x for x,y in points)-1;right=max(x for x,y in points)+1;top=min(y for x,y in points)-1;bottom=max(y for x,y in points)+1
 bg={(x,y)for x in range(left,right+1)for y in range(top,bottom+1)}-points
 return components(points),components(bg,False)-1

def raw(g):
 advance,box,src,bitmap=g;left,top,right,bottom=box;im=bitmap.crop(src)
 return {(x+left,y+top)for y in range(im.height)for x in range(im.width)if im.getpixel((x,y))}

def vertical(points,code,face,top,bottom):
 original=set(points);steps=[]
 if not points:return points,steps
 low=min(y for x,y in points);high=max(y for x,y in points)+1
 if top<=low and high<=bottom:return points,steps
 char=bytes([code]).decode('cp1252');decomp=unicodedata.normalize('NFD',char)
 standalone=code in [0x60,0x5e,0x7e,0x88,0x98,0xaf,0xb4,0xa8,0xb8]
 if standalone:
  delta=top-low if low<top else bottom-high
  moved={(x,y+delta)for x,y in points}
  if min(y for x,y in moved)>=top and max(y for x,y in moved)<bottom:
   return moved,[dict(method='standalone mark translated',dy=delta)]
 # Split accent from the letter at a blank separator if present; otherwise at
 # the native unaccented base's top. Existing letter pixels stay in place.
 if low<top:
  basechar=decomp[0];ref=raw(face[ord(basechar)])if len(decomp)>1 and ord(basechar)<128 else set()
  gaps=[yy for yy in range(low+1,min(y for x,y in ref)+1)if not any(y==yy for x,y in points)]if ref else[]
  cut=gaps[0]+1 if gaps else min(y for x,y in ref)if ref else low+max(1,top-low)
  upper={(x,y)for x,y in points if y<cut};body=points-upper
  delta=top-low;moved={(x,y+delta)for x,y in upper}
  if upper and body and all(y>=top for x,y in moved)and max(y for x,y in moved)<=cut:
   shared=moved&body;points=body|moved
   steps.append(dict(method='accent band moved down; body fixed',dy=delta,cut=cut,shared_pixels=sorted(shared)))
  else:
   # Last-resort discrete mark-band folding only, never whole-glyph scaling.
   upper={(x,y)for x,y in points if y<top};body=points-upper
   points=body|{(x,top)for x,y in upper}
   steps.append(dict(method='overflowing top mark pixels folded onto top row',pixels=sorted(upper),review=True))
 if max(y for x,y in points)>=bottom:
  basechar=decomp[0];ref=raw(face[ord(basechar)])if len(decomp)>1 and ord(basechar)<128 else set()
  split=max(y for x,y in ref)+1 if ref else bottom-1
  lower={(x,y)for x,y in points if y>=split};body=points-lower
  delta=max(y for x,y in points)-bottom+1
  moved={(x,y-delta)for x,y in lower}
  if lower and body and min(y for x,y in moved)>=split-1:
   points=body|moved;steps.append(dict(method='cedilla/lower mark moved up; body fixed',dy=-delta,cut=split,shared_pixels=sorted(body&moved)))
  else:
   offending={(x,y)for x,y in points if y>=bottom};points=(points-offending)|{(x,bottom-1)for x,y in offending}
   steps.append(dict(method='overflowing bottom mark pixels folded onto final ink row',pixels=sorted(offending),review=True))
 assert all(top<=y<bottom for x,y in points),(code,top,bottom,points)
 return points,steps

def horizontal(points,width):
 if not points:return set(),dict(offset=0,removed=[],edge_relocations=[])
 left=min(x for x,y in points);right=max(x for x,y in points)+1;before=topology(points)
 if right-left<=width:
  offset=max(-left,min(0,width-right));return{(x+offset,y)for x,y in points},dict(offset=offset,removed=[],edge_relocations=[])
 trials=[]
 for off in range(width-right,-left+1):
  moved={(x+off,y)for x,y in points};inside={(x,y)for x,y in moved if 0<=x<width};outside=moved-inside
  after=topology(inside)
  score=50*(abs(before[0]-after[0])+abs(before[1]-after[1]))+len(outside)
  trials.append((score,len(outside),abs(off),off,inside,outside))
 _,_,_,offset,inside,outside=min(trials,key=lambda x:x[:4]);relocations=[]
 # Preserve closed counters/stroke connections when trimming their edge would
 # open them: fold only those offending points onto the nearest cell edge.
 if topology(inside)!=before:
  folded={(min(width-1,max(0,x)),y)for x,y in outside};candidate=inside|folded
  old_error=sum(abs(a-z)for a,z in zip(before,topology(inside)))
  new_error=sum(abs(a-z)for a,z in zip(before,topology(candidate)))
  if new_error<old_error:
   for x,y in sorted(outside):
    dest=(min(width-1,max(0,x)),y)
    if dest not in inside:relocations.append(dict(old=(x,y),new=dest));inside.add(dest)
 return inside,dict(offset=offset,removed=sorted(outside),edge_relocations=relocations,source_topology=before,result_topology=topology(inside),review=topology(inside)!=before)

def glyph_image(points,width,pitch,baseline):
 im=Image.new('1',(width,pitch))
 for x,y in points:
  assert 0<=x<width and 0<=y+baseline<pitch
  im.putpixel((x,y+baseline),1)
 return im

def extra_proofs(report):
 imgs=[Image.open(OUT/f'{n}-lines-text.png')for n in [3,4,5,6]]
 out=Image.new('RGB',(1160,65+sum(im.height+20 for im in imgs)),'white');d=ImageDraw.Draw(out)
 d.text((12,10),'Stock-slant Courier — fitted +1px cells, all four styles',font=b.TITLE,fill='black');y=65
 for im in imgs:out.paste(im,(0,y));y+=im.height+20
 out.save(OUT/'text-overview.png')
 a=Image.new('RGB',(1100,840),'white');ad=ImageDraw.Draw(a)
 ad.text((12,8),'0x61 (a) — original source pixels, no repair or cropping',font=b.TITLE,fill='black')
 ad.text((12,40),'Every source pixel 12×. The 8px oblique at six lines is independently identical to the upstream BDF.',font=b.SMALL,fill='#555555')
 for j,st in enumerate(STYLES):ad.text((130+j*240,76),st,font=b.LABEL,fill='black')
 for i,entry in enumerate(report['fonts']):
  yy=110+i*175;ad.text((12,yy),f'{entry["lines"]} lines',font=b.LABEL,fill='black')
  for j,st in enumerate(STYLES):
   with gzip.open(entry['sources'][st]['path'],'rb')as stream:font=PcfFontFile.PcfFontFile(stream,charset_encoding='cp1252').glyph
   pts=raw(font[97]);left=min(x for x,y in pts);top=min(y for x,y in pts);right=max(x for x,y in pts)+1;bottom=max(y for x,y in pts)+1
   for x,y in pts:
    px=130+j*240+(x-left)*12;py=yy+(y-top)*12;ad.rectangle((px,py,px+11,py+11),fill='black')
   ad.text((130+j*240,yy+120),f'{right-left}×{bottom-top} ink',font=b.SMALL,fill='#555555')
 a.save(OUT/'a-source-proof.png')

def main():
 OUT.mkdir(exist_ok=True);shutil.copyfile(b.OUT/'FONT-LICENSE.txt',OUT/'FONT-LICENSE.txt')
 data=json.loads((b.HERE/'courier-sweep/data.json').read_text());reports=[];sections=[];a_evidence=[]
 for lines in [3,4,5,6]:
  size=data['sizes'][str(lines)];w=size['width'];pitch=size['height'];base=size['baseline'];limit=10 if lines==6 else pitch;top=-base;bottom=limit-base
  sources={};faces={};records={};rawpts={}
  for st in STYLES:
   path=Path(next(p for p in size['source_paths']if Path(p).name.startswith('cour'+st)and Path(p).name[len('cour'+st)].isdigit()))
   with gzip.open(path,'rb')as stream:source=PcfFontFile.PcfFontFile(stream,charset_encoding='cp1252').glyph
   sources[st]=dict(path=str(path),sha256=hashlib.sha256(path.read_bytes()).hexdigest());face={};entries={};rawpts[st]={}
   for code in b.CODES:
    original=raw(source[code]);rawpts[st][code]=original
    corrected,mark_moves=vertical(original,code,source,top,bottom)
    final,trim=horizontal(corrected,w)
    if lines==6 and st=='R' and code==0x6d:
     # User-selected hint: use the native bold m's three separate stems,
     # replacing the regular glyph's merged left/middle and right foot serif.
     bold_path,bold_face=b.source('cour','B',8,75)
     final,bold_fit=horizontal(raw(bold_face[code]),w)
     trim['manual_m_copy_from_bold']=dict(source=str(bold_path),method='Exact fitted bold m copied into regular m; no right foot serif')
     trim['result_topology']=topology(final)
    if lines==6 and st=='O' and code in (0x61,0xe0,0xe1,0xe2,0xe3,0xe4,0xe5):
     # User-requested minimal repair: fill the one missing bottom-row pixel.
     assert (2,-1) not in final
     final.add((2,-1))
     trim['manual_a_bottom_pixel']=dict(added=(2,-1),method='Single bottom-row pixel filled; same cell, baseline and stock slant')
     trim['result_topology']=topology(final)
    if lines==6 and st=='BO' and code==0x9c:
     # Move the clipped left o edge inward and thin its opposite wall to
     # reopen a continuous counter. Source counter was diagonally split.
     ops=[((1,-3),(0,-3)),((1,-2),(0,-2))]
     for oldpt,newpt in ops:
      assert oldpt in final and newpt not in final
      final.remove(oldpt);final.add(newpt)
     trim['manual_counter_repair']=[dict(old=op,new=np)for op,np in ops]
     trim['result_topology']=topology(final)
     trim['topology_difference_explained']='Two diagonal source o-counter pockets become one connected counter; e counter retained.'
    assert all(0<=x<w and top<=y<bottom for x,y in final)
    image=glyph_image(final,w,pitch,base)
    if lines==6:assert not any(image.getpixel((x,10))for x in range(w))
    face[code]=image
    shifted_original={(x+trim['offset'],y)for x,y in original}
    removed=shifted_original-final;added=final-shifted_original
    entries[f'{code:02X}']=dict(character=bytes([code]).decode('cp1252'),mark_moves=mark_moves,**trim,source_pixels=len(original),candidate_pixels=len(final),all_removed=sorted(removed),all_added=sorted(added))
   faces[st]=face;records[st]=entries;writer.export(OUT/f'cour-{lines}-lines-{st}.bdf',face,base)
   # Full paired source/after audit for every changed glyph.
   changes=[c for c in b.CODES if entries[f'{c:02X}']['all_removed']or entries[f'{c:02X}']['all_added']]
   cw=155;rh=(pitch+8)*3+55;cols=8;rows=max(1,(len(changes)+cols-1)//cols)
   audit=Image.new('RGB',(cols*cw,100+rows*rh),'white');ad=ImageDraw.Draw(audit)
   ad.text((12,8),f'{lines} lines {st} — source / fitted, every changed glyph',font=b.TITLE,fill='black')
   ad.text((12,40),'Source outside cell red; fitted additions blue. Original slant retained. All images 3×.',font=b.SMALL,fill='#444444')
   for i,c in enumerate(changes):
    x=i%cols*cw;y=95+i//cols*rh;rec=entries[f'{c:02X}'];ad.text((x+3,y),f'{c:02X} '+bytes([c]).decode('cp1252'),font=b.LABEL,fill='black')
    pts={(xx+rec['offset'],yy)for xx,yy in rawpts[st][c]};after={(xx,yy-base)for yy in range(pitch)for xx in range(w)if face[c].getpixel((xx,yy))}
    for j,pp in enumerate([pts,after]):
     ox=x+15+j*75;oy=y+28+4*3;ad.rectangle((ox-1,oy-1,ox+w*3,oy+pitch*3),outline='#aaaaaa')
     for xx,yy in pp:
      px=ox+xx*3;py=oy+(yy+base)*3
      assert x<=px<x+cw-2 and y<py<y+rh-2,(lines,st,c,xx,yy)
      color='#c02b23'if j==0 and(not 0<=xx<w or not top<=yy<bottom)else'#2866ae'if j==1 and(xx,yy)in set(map(tuple,rec['all_added']))else'black'
      ad.rectangle((px,py,px+2,py+2),fill=color)
   audit.save(OUT/f'{lines}-lines-{st}-edits.png')
  # One complete 32x8 card per size, all four styles inside every slot.
  scale=4;cw=34+(w+6)*scale;subh=(pitch+4)*scale+9;rh=22+4*subh
  card=Image.new('RGB',(40+32*cw,140+8*rh),'white');d=ImageDraw.Draw(card);small=ImageFont.truetype(b.FONT,12)
  d.text((12,8),f'Courier {lines} lines — stock slant, {w}px fixed cells / {264//w} columns — R / B / O / BO',font=b.TITLE,fill='black')
  d.text((12,40),'Source stock slant retained. Local overhang trims, mark translations and boundary repairs only; no shear or whole-glyph rescaling.',font=b.SMALL,fill='#444444')
  d.text((12,62),'Every glyph 4×. Blue corner = glyph changed beyond constant horizontal placement. Gray slots are outside the 218 Western printable slots.',font=b.SMALL,fill='#444444')
  d.text((12,84),'O/BO are stock oblique/bold-oblique. Six-line oblique a/à/á/â/ã/ä/å each have the bottom pixel filled; changes are marked blue.',font=b.SMALL,fill='#555555')
  for col in range(32):d.text((40+col*cw+4,115),f'{col:02X}',font=small,fill='#555555')
  for row in range(8):d.text((3,145+row*rh),f'{row*32:02X}',font=small,fill='#555555')
  for c in range(256):
   x=40+c%32*cw;y=140+c//32*rh;d.rectangle((x,y,x+cw-1,y+rh-1),fill='white'if c in b.CODES else'#e8ebee',outline='#cccccc');d.text((x+3,y+3),f'{c:02X}',font=small,fill='#555555')
   if c not in b.CODES:continue
   for i,st in enumerate(STYLES):
    yy=y+22+i*subh;d.text((x+2,yy+6),st,font=small,fill='#666666');g=faces[st][c];ox=x+27;oy=yy+7;d.rectangle((ox-1,oy-1,ox+w*4,oy+pitch*4),outline='#bbbbbb');b.draw_ink(card,g,(ox,oy),4)
    rec=records[st][f'{c:02X}']
    if rec['all_removed']or rec['all_added']:d.rectangle((x+cw-7,yy+5,x+cw-3,yy+9),fill='#2866ae')
  file=f'{lines}-lines-all-styles.png';card.save(OUT/file)
  # Readable text specimens and native pixel pages.
  textcard=Image.new('RGB',(1160,110+2*(250+pitch*3)),'white');td=ImageDraw.Draw(textcard)
  td.text((12,8),f'Courier {lines} lines — stock slant, {w}px / {264//w} columns',font=b.TITLE,fill='black')
  td.text((12,40),'R / B / O / BO. Screens 2×, glyph strings 3×. Pixel corrections are inventoried in report.json.',font=b.SMALL,fill='#444444')
  for i,st in enumerate(STYLES):
   x=12+i%2*580;y=85+i//2*(250+pitch*3);td.text((x,y),st,font=b.LABEL,fill='black')
   page,_=b.page(faces[st],lines,pitch);b.draw_ink(textcard,page,(x,y+30),2)
   native=Image.new('RGB',(264,65),'white');native.paste('black',(0,0),page);native.save(OUT/f'{lines}-{st}-native.png')
   for k,txt in enumerate(['AaBbCcDdEeFfGg','ŠŽšž Çç ÀÉÑÖÜ']):
    mask=b.render_run(faces[st],txt.encode('cp1252'));assert mask.width*3<560;b.draw_ink(textcard,mask,(x,y+180+k*(pitch*3+5)),3)
  textcard.save(OUT/f'{lines}-lines-text.png')
  a_evidence.append(dict(lines=lines,source_rows={st:[''.join('#'if(x,y)in rawpts[st][97]else'.'for x in range(min(xx for xx,yy in rawpts[st][97]),max(xx for xx,yy in rawpts[st][97])+1))for y in range(min(yy for xx,yy in rawpts[st][97]),max(yy for xx,yy in rawpts[st][97])+1)]for st in STYLES}))
  reports.append(dict(lines=lines,width=w,height=pitch,ink_budget=limit,baseline=base,columns=264//w,sources=sources,styles=records))
  sections.append(f'<h2>{lines} lines — all four styles</h2><a href="{lines}-lines-text.png"><img src="{lines}-lines-text.png"></a><p><a href="{file}">Full 32×8 card, all four styles</a></p><a href="{file}"><img loading="lazy" src="{file}"></a><p>Every edited glyph: '+ ' · '.join(f'<a href="{lines}-lines-{st}-edits.png">{st}</a>'for st in STYLES)+'</p>')
 # Independently verify the surprising 8px oblique lowercase a against upstream BDF.
 upstream=b.HERE.parents[3]/'.research-work/u8g2-review/courO08-upstream.bdf'
 _,bd,_=e.parse(upstream);size=data['sizes']['6'];path=Path(next(p for p in size['source_paths']if Path(p).name=='courO08.pcf.gz'))
 with gzip.open(path,'rb')as f:p=PcfFontFile.PcfFontFile(f,charset_encoding='cp1252')
 assert bd[97]['points']==raw(p.glyph[97])
 report=dict(method='Stock original R/B/O/BO at +1px shared widths; regular six-line m copies native bold m by explicit user request. No shear. Local mark translations first; edge trimming chooses placement preserving counters/components where possible; offending pixels may move to the cell boundary if this better retains source topology. Every removal/addition recorded.',scope='218 Western printable native-byte slots; not a complete Neo-US device/control map.',fonts=reports,lowercase_a=dict(evidence=a_evidence,independent_BDF=str(upstream),sha256=hashlib.sha256(upstream.read_bytes()).hexdigest(),verified=True),validation=dict(bdf_faces=16,glyphs_roundtripped=16*len(b.CODES),all_width_height_bounds_passed=True,six_line_final_row_blank=True,whole_glyph_rescaling=False,slant_shearing=False))
 (OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
 extra_proofs(report)
 (OUT/'index.html').write_text('<!doctype html><meta charset="utf-8"><title>Stock-slant Courier fitted</title><style>body{font:17px sans-serif;margin:24px}img{max-width:100%;image-rendering:pixelated}h2{margin-top:40px}</style><h1>Stock-slant Courier fitted to +1px cells</h1><p><a href="text-overview.png">Combined text overview</a> · <a href="a-source-proof.png">Original 0x61 pixel proof</a></p><p>Four sizes, all four styles. Local overhang/mark corrections and the user-selected six-line regular m copied from bold; no slant changes or whole-glyph scaling. Every correction has an original/candidate glyph audit. Full cards mark changed glyphs with a blue corner.</p><p>The six-line native oblique a really has the unusual four-row drawing: independently checked against the original BDF. Oblique a and its six accented forms each have the explicitly requested bottom pixel added at (2,-1).</p>'+''.join(sections)+'<p><a href="report.json">Every pixel edit, source hash and exact verification</a></p>')
 print(json.dumps(report['validation']))
 for r in reports:
  print(r['lines'],{st:sum(bool(v['all_removed']or v['all_added'])for v in r['styles'][st].values())for st in STYLES},'topology_review',sum(v.get('review',False)for face in r['styles'].values()for v in face.values()))
 print(OUT/'index.html')
if __name__=='__main__':main()
