#!/usr/bin/env python3
"""Inventory original Neo font resources offline; no emulator/screenshots."""
from pathlib import Path
import struct,json,hashlib,collections,re
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).resolve().parents[4]
OUT=Path(__file__).with_name('neo-fonts')
FONTDIR=ROOT/'Ghidra/Alphasmart Neo/NeoFonts'
def decode(data,at,base=0):
 h,w,stride,flags,wp,op,bp=struct.unpack_from('>4BIII',data,at)
 widths=list(data[wp-base:wp-base+256])if wp else[w]*256
 offsets=list(struct.unpack_from('>256H',data,op-base))if op else[c*stride for c in range(256)]
 glyphs=[]
 for c in range(256):
  im=Image.new('1',(widths[c],h))
  for y in range(h):
   for x in range(widths[c]):
    pos=bp-base+offsets[c]+y//8*widths[c]+x
    assert 0<=pos<len(data)
    im.putpixel((x,y),(data[pos]>>(y%8))&1)
  glyphs.append(im)
 return (h,w,stride,flags,wp,op,bp),glyphs
font=lambda n:ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',n)
def paste(im,g,xy,scale=3):
 im.paste('black',(*xy,xy[0]+g.width*scale,xy[1]+g.height*scale),g.resize((g.width*scale,g.height*scale),Image.Resampling.NEAREST))
def trimmed(g):
 box=g.getbbox()
 return g.crop((0,box[1],g.width,box[3]))if box else Image.new('1',(g.width,1))
def card(name,gs,rom):
 im=Image.new('RGB',(2048,1130),'white');d=ImageDraw.Draw(im)
 d.text((12,8),name+' — actual 256 byte slots',font=font(23),fill='black')
 d.text((12,42),'Each box: candidate TOP, Neo ROM BOTTOM. Blank vertical margins removed; 3× nearest-neighbour. Bytes, not Unicode labels.',font=font(15),fill='black')
 for c in range(256):
  x=c%32*64;y=80+c//32*130
  d.rectangle((x,y,x+63,y+129),outline='#cccccc')
  d.text((x+3,y+2),f'{c:02X}',font=font(12),fill='#555555')
  for g,yy in [(gs[c],y+23),(rom[c],y+73)]:
   g=trimmed(g);paste(im,g,(x+2,yy))
 im.save(OUT/f'{name}-charset.png')
def main():
 OUT.mkdir(exist_ok=True)
 rd=(ROOT/'Ghidra/Alphasmart Neo/SmartApplets/os3kneorom.os3kos').read_bytes()
 _,rom=decode(rd,0x44af8e-0x410000,0x410000)
 records=[];allglyphs={}
 for p in sorted(FONTDIR.glob('*.OS3KApp')):
  data=p.read_bytes();assert data[-4:]==bytes.fromhex('cafefeed')
  descriptor=len(data)-20
  # Initializer's first PC-relative LEA demonstrably resolves to this descriptor.
  matches=[]
  for i in range(0x130,min(0x180,len(data)-12),2):
   if data[i:i+2]==b'\x20\x7c'and data[i+6:i+12]==bytes.fromhex('41fb88fe1290'):
    matches.append(i+6+struct.unpack_from('>i',data,i+2)[0])
  assert matches==[descriptor],(p,matches,descriptor)
  info,gs=decode(data,descriptor);h,w,stride,flags,wp,op,bp=info
  assert len(data[wp:wp+256])==256 and op+512<=descriptor
  # Existing providers recognize name, regular-font getter and height only.
  handler=data[0x94:0x138]
  assert all(bytes.fromhex('0c40')+struct.pack('>H',n)in handler for n in [1,2,6])
  groups=collections.defaultdict(list)
  for c,g in enumerate(gs):groups[(g.size,g.tobytes())].append(c)
  blank=[c for c,g in enumerate(gs)if not g.getbbox()]
  solid=[]
  for c,g in enumerate(gs):
   box=g.getbbox()
   if box:
    crop=g.crop(box)
    if crop.width>=3 and crop.height>=3 and all(crop.getpixel((x,y))for y in range(crop.height)for x in range(crop.width)):solid.append(f'{c:02X}')
  internal_name=data[24:60].split(b'\0')[0].decode()
  advertised=int(re.search(r'\((\d+) line',internal_name)[1])
  clipped=[f'{c:02X}'for c,g in enumerate(gs)if advertised>1 and (advertised-1)*h+g.height>65 and g.crop((0,max(0,65-(advertised-1)*h),g.width,g.height)).getbbox()]
  widths=[g.width for g in gs];ink=[g.getbbox()for g in gs if g.getbbox()]
  name=p.stem.removeprefix('NeoFont');allglyphs[name]=gs
  record=dict(name=name,path=str(p.relative_to(ROOT)),sha256=hashlib.sha256(data).hexdigest(),applet_id=f'{struct.unpack_from(">H",data,20)[0]:04X}',
   internal_name=internal_name,advertised_lines=advertised,clipped_last_line_slots=clipped,solid_rectangles=solid,descriptor_offset=descriptor,height=h,max_width=w,
   ascii_widths=sorted(set(widths[32:127])),spacing='proportional'if len(set(widths[32:127]))>1 else'monospace',
   ink_y=[min(box[1]for box in ink),max(box[3]for box in ink)],blank_slots=[f'{c:02X}'for c in blank],
   nonblank_slots=256-len(blank),blank_where_rom_has_ink=[f'{c:02X}'for c in blank if rom[c].getbbox()],
   duplicate_cells=[[f'{c:02X}'for c in cs]for cs in groups.values()if len(cs)>1],
   style_getters=['regular'],nominal_uniform_rows=65//h,
   note='Byte-table occupancy is verified; semantic equivalence of every differently drawn glyph is not certified.')
  records.append(record)
  if name not in ['Klingon','Neuropol','Mirror']:card(name,gs,rom)
 # Exact Atto/Femto relation, including trailing blank row.
 differences=[f'{c:02X}'for c,(a,f)in enumerate(zip(allglyphs['Atto'],allglyphs['Femto']))if a.width!=f.width or a.tobytes()!=f.crop((0,0,f.width,6)).tobytes()]
 assert differences==['61','67','6A','70','71','74','79','BF']
 overview=Image.new('RGB',(1400,70+len(records)*145),'white');d=ImageDraw.Draw(overview)
 d.text((12,8),'Existing NeoFonts — extracted source glyphs, 3× scale',font=font(24),fill='black')
 for i,r in enumerate(records):
  y=70+i*145;d.text((12,y),f'{r["name"]} — {r["height"]}px cells, {r["spacing"]}, {r["nonblank_slots"]}/256 nonblank slots',font=font(17),fill='black')
  text='The quick brown fox: Il1 O0 ijmw 0123456789 ÀÉÑÖÜ ß Œœ Šš Žž'
  gs=allglyphs[r['name']];x=12
  # Large decorative faces use a shorter sample, at the same scale.
  for c in text.encode('cp1252'):
   g=gs[c].crop((0,r['ink_y'][0],gs[c].width,r['ink_y'][1]));
   if x+g.width*3>1380:break
   paste(overview,g,(x,y+30));x+=g.width*3
 overview.save(OUT/'overview.png')
 report=dict(method='Decode 256 widths and offsets from the original PC-relative font descriptor; exact source bitmaps, no screen capture or inference.',
  mapping_reference='Neo ROM system font at 0x44AF8E; no assumption that CP1252 defines all Neo slots.',
  records=records,exact_relations=['Atto/Femto have identical width tables and 248/256 identical first-six-row glyphs; differing slots: '+', '.join(differences)])
 (OUT/'inventory.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps([{k:r[k]for k in ['name','height','applet_id','ascii_widths','nonblank_slots','blank_where_rom_has_ink']}for r in records],indent=2))
if __name__=='__main__':main()
