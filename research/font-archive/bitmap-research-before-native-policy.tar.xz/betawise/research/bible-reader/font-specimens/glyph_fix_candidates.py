#!/usr/bin/env python3
"""Draft bitmap comparisons only; does not edit shipping BDFs."""
import json
import sys
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT/'fonts'))
import fontgen
OUT=Path(__file__).with_name('glyph-fixes-review')
STYLES=['Regular','Bold','Italic','BoldItalic']
FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
LABEL=ImageFont.truetype(FONT,16)
TITLE=ImageFont.truetype(FONT,22)


def replace_body(cell,rows,top):
    result=cell.copy()
    for y,row in enumerate(rows,top):
        for x,char in enumerate(row):result.putpixel((x,y),char=='#')
    return result


def run(glyphs,text):
    width=sum(glyphs[c].width for c in text.encode('cp1252'))
    result=Image.new('1',(width,glyphs[0].height));x=0
    for code in text.encode('cp1252'):
        g=glyphs[code];result.paste(g,(x,0));x+=g.width
    return result


def paste(image,g,xy,scale):
    mask=g.resize((g.width*scale,g.height*scale),Image.Resampling.NEAREST)
    image.paste('black',(*xy,xy[0]+mask.width,xy[1]+mask.height),mask)


def main():
    image=Image.new('RGB',(1420,1180),'white');draw=ImageDraw.Draw(image)
    draw.text((16,10),'Draft wider bowls — original / proposed, same advances and baselines',font=TITLE,fill='black')
    draw.text((16,48),'Proposal only; shipping BDFs unchanged. Mono: 6px cells, 5px capitals. Serif Regular c/ç: 4px advance, 3px ink.',font=LABEL,fill='#555555')
    records=[]
    for index,style in enumerate(STYLES):
        path=ROOT/f'fonts/BetaWiseMono/BetaWiseMono-Small-{style}.bdf'
        original=fontgen.load(path,'iso8859-1',63);draft=[g.copy()for g in original]
        bold=style.startswith('Bold')
        rows_c=['.###..','##..#.','##....','##..#.','.###..']if bold else['.##...','#..#..','#.....','#..#..','.##...']
        rows_g=['.###..','##....','##.##.','##..#.','.###..']if bold else['.##...','#.....','#.##..','#..#..','.##...']
        if 'Italic'in style:
            def slant(rows):return ['.'+row[:-1]if i<3 else row for i,row in enumerate(rows)]
            rows_c=slant(rows_c);rows_g=slant(rows_g)
        for code,rows in [(67,rows_c),(71,rows_g),(199,rows_c)]:
            draft[code]=replace_body(original[code],rows,3)
            assert draft[code].size==original[code].size
            if code in (67,71):
                oldbox=original[code].getbbox();newbox=draft[code].getbbox()
                assert newbox[2]-newbox[0] == oldbox[2]-oldbox[0]+1
            if code==199:assert draft[code].crop((0,8,6,11)).tobytes()==original[code].crop((0,8,6,11)).tobytes()
            records.append(dict(font=path.name,slot=f'{code:02X}',body_rows=rows,body_top=3))
        y=95+index*215
        draw.text((16,y),f'Mono {style}',font=LABEL,fill='black')
        for col,face in enumerate([original,draft]):
            x=170+col*610
            draw.text((x,y),'Original'if col==0 else'Proposed',font=LABEL,fill='black')
            paste(image,run(face,'C G Ç'),(x,y+25),7)
            paste(image,run(face,'Cocoa GCG café ÇÇ'),(x,y+112),3)
        draw.line((0,y+200,1420,y+200),fill='#cccccc')
    original=fontgen.load(ROOT/'fonts/BetaWiseSerif/BetaWiseSerif-Small-Regular.bdf','iso8859-1',63)
    for code in [99,231]:
        original[code]=replace_body(original[code],['.#..','#...','#...','.#..'],4)
    draft=[g.copy()for g in original]
    for code in [99,231]:
        draft[code]=replace_body(original[code],['.##.','#...','#...','.##.'],4)
        assert draft[code].size==original[code].size
    y=975;draw.text((16,y),'Serif Regular (approved)',font=LABEL,fill='black')
    for col,face in enumerate([original,draft]):
        x=170+col*610
        draw.text((x,y),'Original'if col==0 else'Proposed',font=LABEL,fill='black')
        paste(image,run(face,'c ç'),(x,y+25),7)
        paste(image,run(face,'cocoa concise café ça'),(x,y+112),3)
    image.save(OUT/'wider-bowl-proposals.png')
    (OUT/'wider-bowl-proposals.json').write_text(json.dumps(records,indent=2)+'\n')
    print(OUT/'wider-bowl-proposals.png')


if __name__=='__main__':main()
