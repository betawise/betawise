#!/usr/bin/env python3
"""Unmodified full-repertoire X11 comparison: no ASCII fallback or glyph repair."""
import json
from PIL import Image,ImageDraw
import build as b
SIZES=[(3,21,21),(4,16,16),(5,13,13),(6,11,10),(7,9,9)]

def choose(family,styles,limit,pitch):
    inventory=[]
    for pt,dpi,pixels in b.strike_options(family):
        faces=[b.source(family,style,pt,dpi)[1]for style in styles]
        top,bottom=b.envelope(faces,b.CODES)
        inventory.append(dict(points=pt,dpi=dpi,pixels=pixels,top=top,bottom=bottom,height=bottom-top,faces=faces))
    fits=[s for s in inventory if s['height']<=limit]
    if not fits:return None,dict(available=False,minimum_ink_height=min(s['height']for s in inventory))
    chosen=max(fits,key=lambda s:(s['pixels'],s['height'],s['dpi']))
    top=chosen['top'];bodies=[];checked=0
    for face in chosen['faces']:
        body={}
        for code in b.CODES:
            ink,t,_=b.raw(face[code]);cell=Image.new('1',(ink.width,pitch));cell.paste(ink,(0,t-top))
            expected={(x,y+t)for y in range(ink.height)for x in range(ink.width)if ink.getpixel((x,y))}
            actual={(x,y+top)for y in range(cell.height)for x in range(cell.width)if cell.getpixel((x,y))}
            assert expected==actual
            assert not cell.getbbox()or cell.getbbox()[3]<=limit
            body[code]=cell;checked+=1
        bodies.append(body)
    return bodies,dict(available=True,**{k:v for k,v in chosen.items()if k!='faces'},source_glyphs_verified=checked,baseline=-top)

def main():
    b.OUT.mkdir(exist_ok=True)
    im=Image.new('RGB',(2256,1435),'white');d=ImageDraw.Draw(im)
    d.text((12,8),'Largest native X11 strike fitting the full text repertoire — accents included',font=b.TITLE,fill='black')
    d.text((12,40),'All 218 Windows-1252 printable glyphs × four styles. No ASCII fallback, no rescaling and no extended-glyph edits. Screen samples 2×.',font=b.SMALL,fill='#444444')
    report=dict(scope='Full 218-glyph CP1252 Western text repertoire; Neo control/device glyphs are not a verified Unicode mapping',
                source_encoding='Unicode X11 sources, mapped via cp1252',codes=b.CODES,fonts=[],
                policy='Largest XLFD pixel size fitting complete glyph ink across four styles; no glyph edits or source leading requirement')
    for col,(title,family,styles)in enumerate(b.FAMILIES):
        for row,(lines,pitch,limit)in enumerate(SIZES):
            body,meta=choose(family,styles,limit,pitch)
            entry=dict(family=title,lines=lines,pitch=pitch,ink_budget=limit,**meta);report['fonts'].append(entry)
            x,y=12+564*col,76+265*row
            d.text((x,y),f'{title} — {lines} lines / {pitch}px pitch',font=b.LABEL,fill='black')
            if body is None:
                d.text((x,y+27),f"No native strike fits: minimum full ink is {meta['minimum_ink_height']}px",font=b.SMALL,fill='#a02020')
                continue
            d.text((x,y+26),f"{meta['pixels']}px / {meta['points']}pt / {meta['dpi']}dpi; full ink {meta['height']}px",font=b.SMALL,fill='#444444')
            page,text=b.page(body[0],lines,pitch)
            white=Image.new('RGB',page.size,'white');white.paste('black',(0,0),page)
            white.save(b.OUT/f'{family}-{lines}-lines-full-repertoire.png')
            im.paste(white.resize((528,130),Image.Resampling.NEAREST),(x,y+49))
            d.rectangle((x-1,y+48,x+528,y+179),outline='#999999')
            # An actual accented-text strip makes the reserved headroom visible.
            sample='ÀÉÖ Ññ Åå Œœ Ÿÿ'.encode('cp1252')
            run=b.render_run(body[0],sample)
            assert run.width*2<=528
            b.draw_ink(im,run,(x,y+193),2)
            entry['page_text']=text
    d.text((12,1411),'Neo control bytes and device/icon drawings are separate from this printable text repertoire; no claim of a complete 256-slot Neo mapping.',font=b.SMALL,fill='#555555')
    assert all(f['height']<=f['ink_budget']for f in report['fonts']if f['available'])
    report['validation']=dict(passed=True,source_glyphs_verified=sum(f.get('source_glyphs_verified',0)for f in report['fonts']),
        available=sum(f['available']for f in report['fonts']),glyph_edits=0,whole_font_rescalings=0,screen=[264,65])
    path=b.OUT/'regular-body-full-repertoire-overview.png';im.save(path)
    (b.OUT/'full-repertoire-report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report['validation']))
    for f in report['fonts']:print(f['family'],f['lines'],f.get('pixels','unavailable'),f.get('dpi',''),f.get('height',f.get('minimum_ink_height')))
    print(path)
if __name__=='__main__':main()
