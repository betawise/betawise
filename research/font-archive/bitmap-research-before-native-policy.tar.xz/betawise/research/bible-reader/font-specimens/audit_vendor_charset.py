#!/usr/bin/env python3
"""Inventory reviewed glyphs in original vendor resources, never community fonts."""
import gzip
import json
import sys
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
from inventory_neo_fonts import decode
from verify_charset_review import FONT_NAMES, UnicodePCF, signature

sys.path.insert(0, str(Path(__file__).resolve().parents[3] / "os3k"))
import charsets

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).with_name('charset-review')
SLOTS = [0x01, 0x03, 0x05, 0x06, 0x07, 0x09, 0x11, 0x17, 0x18,
         0x19, 0x1a, 0x1b, 0x1e, 0x04, 0x16, 0x81, 0x90]
CONTROLS = [0x0d, 0x60, 0x4e, 0x6e, 0xd1]


def main():
    source = ROOT.parent / 'Ghidra/Alphasmart Neo/SmartApplets'
    rom = (source / 'os3kneorom.os3kos').read_bytes()
    fonts = {}
    for label, address in [('System 6×16', 0x44af8e), ('Dialog', 0x44e336)]:
        fonts[label] = (source / 'os3kneorom.os3kos', address - 0x410000,
                        decode(rom, address - 0x410000, 0x410000)[1])
    for label, stem in [('Small', 'small'), ('Medium', 'medium'), ('Large', 'large'),
                        ('Very Large', 'vlarge'), ('Extra Large', 'xlarge')]:
        path = source / f'neofont{stem}.os3kapp'
        data = path.read_bytes()
        assert data[-4:] == bytes.fromhex('cafefeed')
        at = {'small': 0x1030, 'medium': 0x10f4, 'large': 0x1094,
              'vlarge': 0x249c, 'xlarge': 0x334a}[stem]
        fonts[label] = (path, at, decode(data, at)[1])
    mapping = charsets.load(ROOT / 'os3k/charsets/neo-us.txt')
    candidates = sorted({mapping[slot] for slot in SLOTS + CONTROLS} |
                        {0x2713, 0x25a1, 0x25af, 0x2395, 0x221a, 0x02cb, 0x0300})
    UnicodePCF.candidates = candidates
    references = []
    for name in FONT_NAMES:
        path = Path('/usr/share/fonts/X11/misc') / (name + '.pcf.gz')
        if not path.is_file():
            continue
        with gzip.open(path, 'rb') as stream:
            reference = UnicodePCF(stream)
        if reference.info[b'CHARSET_REGISTRY'] != b'ISO10646':
            continue
        for index, code in enumerate(candidates):
            glyph = reference.glyph[index]
            if glyph:
                references.append((code, name, signature(glyph[3].crop(glyph[2]))))
    records = []
    for name, (path, at, glyphs) in fonts.items():
        records.append(dict(font=name, path=str(path.relative_to(ROOT.parent)),
            descriptor_offset=at, height=glyphs[0].height,
            glyphs={f'{slot:02X}': dict(width=glyphs[slot].width,
                bbox=glyphs[slot].getbbox(),
                reference_matches=[dict(unicode=f'U+{code:04X}', font=refname)
                    for code, refname, pattern in references
                    if pattern and pattern == signature(glyphs[slot])], rows=[
                    ''.join('1' if glyphs[slot].getpixel((x,y)) else '0'
                            for x in range(glyphs[slot].width))
                    for y in range(glyphs[slot].height)],
                identical_slots=[f'{other:02X}' for other in range(256)
                    if other != slot and glyphs[other].size == glyphs[slot].size
                    and glyphs[other].tobytes() == glyphs[slot].tobytes()],
                same_ink_slots=[f'{other:02X}' for other in range(256)
                    if other != slot and signature(glyphs[other]) == signature(glyphs[slot])])
                for slot in SLOTS + CONTROLS}))
    (OUT / 'vendor-glyph-audit.json').write_text(json.dumps(records, indent=2) + '\n')
    face = '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
    title = ImageFont.truetype(face, 21)
    label = ImageFont.truetype(face, 16)
    for page, slots in enumerate([SLOTS[:13], SLOTS[13:] + CONTROLS], 1):
        image = Image.new('RGB', (1370, 100 + 145 * len(slots)), 'white')
        draw = ImageDraw.Draw(image)
        draw.text((12, 8), 'Vendor Neo source glyphs — ' + ('manual identifications' if page == 1 else 'additional slots and comparisons'), font=title, fill='black')
        draw.text((12, 38), 'Exact bitmap cells at 3×; no margin cropping. Outlined cells retain original advance and height.', font=label, fill='#444444')
        for col, name in enumerate(fonts):
            draw.text((110 + col * 180, 70), name, font=label, fill='black')
        for row, slot in enumerate(slots):
            y = 100 + row * 145
            draw.text((12, y+20), f'0x{slot:02X}', font=title, fill='black')
            for col, (_, _, glyphs) in enumerate(fonts.values()):
                glyph = glyphs[slot]
                x = 115 + col * 180
                enlarged = glyph.resize((glyph.width * 3, glyph.height * 3), Image.Resampling.NEAREST)
                draw.rectangle((x-1,y-1,x+enlarged.width,y+enlarged.height), outline='#cccccc')
                image.paste('black',(x,y,x+enlarged.width,y+enlarged.height),enlarged)
                draw.text((x,y+103),f'{glyph.width}×{glyph.height}',font=label,fill='#666666')
            draw.line((0,y+139,1370,y+139), fill='#dddddd')
        image.save(OUT / f'vendor-glyph-audit-{page}.png')
    for r in records:
        print(r['font'], 'height', r['height'])
        for slot in SLOTS:
            g = r['glyphs'][f'{slot:02X}']
            print(f'  {slot:02X}:', g['bbox'], 'duplicates', g['identical_slots'], 'references', g['reference_matches'])


if __name__ == '__main__':
    main()
