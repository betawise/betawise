#!/usr/bin/env python3
"""Write the selected reader BDFs with editable family/style metadata into fonts/."""
import json,re,shutil
from pathlib import Path
import sys
import evaluate_substitutes as e
HERE=Path(__file__).resolve().parent
DEST=HERE.parents[2]/'fonts'
sys.path.insert(0, str(HERE.parents[2] / 'os3k'))
from charsets import load as load_charset, glyph_name
NAMES={'tim':('BetaWise Serif','BetaWiseSerif'),'helv':('BetaWise Sans','BetaWiseSans'),'ncen':('BetaWise Book','BetaWiseBook'),'cour':('BetaWise Mono','BetaWiseMono')}
SIZES={3:('VeryLarge','Very Large'),4:('Large','Large'),5:('Medium','Medium'),6:('Small','Small')}
STYLES={'R':'Regular','B':'Bold','I':'Italic','BI':'BoldItalic'}

def main():
 report=json.loads((HERE/'reader-candidates/manifest.json').read_text());exports=[]
 mapping=load_charset(HERE.parents[2]/'os3k/charsets/neo-us.txt')
 for selection in report['fonts']:
  family,stem=NAMES[selection['stem']];meta=selection['metadata']
  if 'sources'in meta:
   source=meta['sources']['R']['path'];pt=int(re.search(r'courR(\d+)',source)[1]);dpi=int(Path(source).parent.name.removesuffix('dpi'));pixel_size=8
  else:pt=meta['points'];dpi=meta['dpi'];pixel_size=meta['pixel_size']
  for file in selection['files']:
   source=HERE/'reader-candidates'/file['path'];text=source.read_text();style=file['style'];bold=style in ['B','BI'];italic=style in ['I','BI']
   slant=('O'if selection['stem']in ['helv','cour']else'I')if italic else'R'
   _,glyphs,_=e.parse(source);spacing='M'if len({g['advance']for g in glyphs.values()})==1 else'P'
   properties=[f'FAMILY_NAME "{family}"',f'FULL_NAME "{family} {STYLES[style]} {SIZES[selection["lines"]][1]}"',f'WEIGHT_NAME "{"Bold"if bold else"Medium"}"',f'SLANT "{slant}"','SETWIDTH_NAME "Normal"',f'PIXEL_SIZE {pixel_size}',f'POINT_SIZE {pt*10}',f'RESOLUTION_X {dpi}',f'RESOLUTION_Y {dpi}',f'SPACING "{spacing}"','CHARSET_REGISTRY "NEO"','CHARSET_ENCODING "US"']
   lines=text.splitlines();lines[1]=f'FONT -betawise-{family.lower().removeprefix("betawise ")}-{"bold"if bold else"medium"}-{slant.lower()}-normal--{pixel_size}-{pt*10}-{dpi}-{dpi}-{spacing.lower()}-0-neo-us';lines[2]=f'SIZE {pt} {dpi} {dpi}'
   a=next(i for i,line in enumerate(lines)if line.startswith('STARTPROPERTIES '));z=lines.index('ENDPROPERTIES');old=lines[a+1:z];old=[line.replace('Adobe/DEC X11 derivative research; see FONT-LICENSE.txt', 'Copyright 1984-1989, 1994 Adobe Systems Incorporated. Copyright 1988, 1994 Digital Equipment Corporation. See ../LICENSE.md.')for line in old]
   lines[a:z+1]=[f'STARTPROPERTIES {len(old)+len(properties)}',*old,*properties,'ENDPROPERTIES']
   for i,line in enumerate(lines):
    if line.startswith('STARTCHAR '):lines[i]='STARTCHAR '+glyph_name(int(lines[i+1].split()[1]),mapping)
   lines.insert(1,'COMMENT Native Neo-US byte slots; see os3k/charsets/neo-us.txt for glyph identities.')
   folder=DEST/family.replace(' ', '');folder.mkdir(exist_ok=True)
   target=folder/f'{stem}-{SIZES[selection["lines"]][0]}-{STYLES[style]}.bdf';target.write_text('\n'.join(lines)+'\n')
   _,actual,_=e.parse(target);assert actual==glyphs,target
   exports.append(target.name)
 # The shipping LICENSE.md contains the applicable upstream notices.

 print(f'Exported {len(exports)} BDFs; verified 13,952 exact glyphs/advances. Destination: {DEST}')
if __name__=='__main__':main()
