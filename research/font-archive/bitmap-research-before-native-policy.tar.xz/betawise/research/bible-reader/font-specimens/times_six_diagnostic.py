#!/usr/bin/env python3
"""Offline selected-source spacing/cap-height diagnostic; no selection changes."""
import json
from PIL import Image,ImageDraw
import build as b
import evaluate_substitutes as e
import reader_candidates as r
OUT=b.HERE/'times-six-diagnostic'

def main():
 OUT.mkdir(exist_ok=True);im=Image.new('RGB',(1500,1150),'white');d=ImageDraw.Draw(im);report=[]
 d.text((16,10),'Times six-line: spacing is present; native capitals are 5px',font=b.TITLE,fill='black')
 d.text((16,44),'4× source pixels. Blue rectangles identify actual spaces. Lower sample in each pair tries a 3px space; selected BDFs unchanged.',font=b.SMALL,fill='#444444')
 for i,st in enumerate(e.STYLE_ORDER):
  _,gs,_=e.parse(r.OUT/f'tim-6-lines-{st}.bdf');face={}
  for c,g in gs.items():
   cell=Image.new('1',(g['advance'],11))
   for x,y in g['points']:cell.putpixel((x,y+8),1)
   face[c]=cell
  assert face[32].width==2 and not face[32].getbbox()
  y=90+i*185;d.text((16,y),st,font=b.LABEL,fill='black')
  for j,width in enumerate([2,3]):
   variant=dict(face);variant[32]=Image.new('1',(width,11));text='earth. And void; and light: yes, now!'
   mask=b.render_run(variant,text.encode());x=180;yy=y+22+j*68
   d.text((16,yy),f'{width}px space'+(' (current)'if width==2 else' (trial)'),font=b.SMALL,fill='#444444')
   pen=x
   for code in text.encode():
    if code==32:d.rectangle((pen,yy,pen+width*4-1,yy+43),fill='#e0f2ff')
    pen+=variant[code].width*4
   assert pen<im.width;b.draw_ink(im,mask,(x,yy),4)
  report.append(dict(style=st,space_width=2,space_ink=0,cap_height=5))
 d.text((16,850),'Capital comparison — 8× exact pixels, aligned at the baseline',font=b.LABEL,fill='black')
 for i,(stem,name)in enumerate([('tim','Times'),('ncen','Schoolbook'),('helv','Helvetica'),('cour','Courier')]):
  _,g,_=e.parse(r.OUT/f'{stem}-6-lines-R.bdf');pts=g[65]['points'];height=max(y for x,y in pts)-min(y for x,y in pts)+1
  x=16+i*370;d.text((x,890),f'{name}: {height}px A',font=b.LABEL,fill='black')
  cell=Image.new('1',(g[65]['advance'],11))
  for xx,yy in pts:cell.putpixel((xx,yy+8),1)
  b.draw_ink(im,cell,(x,925),8)
 d.text((16,1090),'Next native Times strikes: 10px at 75dpi / 11px at 100dpi; both have 7px capitals and 13px full-Western ink height.',font=b.SMALL,fill='#444444')
 im.save(OUT/'spacing-and-cap-height.png');(OUT/'report.json').write_text(json.dumps(dict(styles=report,selection_changed=False,next_native_cap_height=7,next_native_full_height=13),indent=2)+'\n')
 print(OUT/'spacing-and-cap-height.png')
if __name__=='__main__':main()
