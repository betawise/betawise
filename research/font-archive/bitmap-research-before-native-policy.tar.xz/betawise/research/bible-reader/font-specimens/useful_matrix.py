#!/usr/bin/env python3
"""Curated source-bitmap choice matrix. Not an LCD capture or acceptance oracle."""
import json,sys
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import build as b
import evaluate_substitutes as e
import inventory_neo_fonts as n
import family_roles as roles
OUT=b.HERE/'useful-matrix'
SAMPLE='AaBbCcDdEeFfGg'
COLUMNS=['Serif','Sans','Book','Mono','Terminal']
SCALE=2
CW=690;LEFT=110;WIDTH=LEFT+CW*5+20
font=lambda s:ImageFont.truetype(b.FONT,s)
F=font(22);SMALL=font(19);HEAD=font(34)
PITCH={2:32,3:21,4:16,5:13,6:11,7:9,8:8,9:7,10:6,11:5}
choices={(row,col):[]for row in range(2,12)for col in COLUMNS}
manifest=[]
def put(row,col,title,faces,note='',source='',flag=''):
 assert all(all(ord(c)in face for c in SAMPLE)for face in faces.values())
 choices[row,col].append(dict(title=title,faces=faces,note=note,source=source,flag=flag))
 manifest.append(dict(lines=row,role=col,title=title,note=note,styles=list(faces),source=source,flag=flag))
def western_profile(p,pitch):
 assert p['full_western']
 return {st:e.normalize(face,p['top'],pitch)[0]for st,face in p['faces'].items()}
def adobe(stem,lines):
 title,_,styles=next(f for f in b.FAMILIES if f[1]==stem)
 bodies,meta=b.body_fonts(stem,styles,32 if lines==2 else PITCH[lines],PITCH[lines])
 assert bodies is not None
 return {st:{u:body[c]for u,c in e.CP.items()}for st,body in zip(e.STYLE_ORDER,bodies)},meta

def bdf_family(names,pitch):
 faces={}
 for st,path in names.items():
  props,gs,_=e.parse(path)
  # Generated project BDFs use native byte encoding.
  face={u:gs[c]for u,c in e.CP.items()}
  faces[st]=face
 top,bottom=e.span(faces)
 assert bottom-top<=pitch
 return {st:e.normalize(face,top,pitch)[0]for st,face in faces.items()}

def main():
 OUT.mkdir(exist_ok=True)
 # Existing selections: native ASCII strikes with previously reviewed extended
 # repairs, no whole-font scaling. Show all four actual faces.
 for stem,col,rows in [('tim','Serif',[2,3,4,5,6,7]),('helv','Sans',[2,3,4,5]),('ncen','Book',[2,3,4,5]),('cour','Mono',[2,3,4,5])]:
  for lines in rows:
   if lines in [6,7]:
    styles=next(f[2]for f in b.FAMILIES if f[1]==stem)
    faces=bdf_family({st:b.OUT/f'{stem}-{lines}-lines-{src}.bdf'for st,src in zip(e.STYLE_ORDER,styles)},PITCH[lines])
    meta=next(x for x in json.loads((b.OUT/'report.json').read_text())['fonts']if x['family']=='Times'and x['lines']==lines)
   else:faces,meta=adobe(stem,lines)
   title=f'{dict(tim="Times",helv="Helvetica",ncen="Schoolbook",cour="Courier")[stem]} {meta["pixel_size"]}px'
   put(lines,col,title,faces,f'{meta["dpi"]}dpi native strike; extended repairs †','Adobe X11',flag='†')
 # The aligned 8px alternatives retain four styles without baseline staggering.
 for stem,col,title in [('helv','Sans','Helvetica 8px aligned'),('cour','Mono','Courier 8px aligned')]:
  styles=next(f[2]for f in b.FAMILIES if f[1]==stem)
  faces=bdf_family({st:b.OUT/f'aligned6-{stem}-{src}.bdf'for st,src in zip(e.STYLE_ORDER,styles)},11)
  put(6,col,title,faces,'Accent-only repairs; shared baseline †','Adobe 75dpi aligned alternative',flag='†')
 # Lucida: secondary visual choices, retain all four native styles. Labels use
 # pixel size from XLFD/property, never confuse point and pixel sizes.
 for prefix,col,pts,lines in [('Sans','Sans',[18,12,10,8],[2,3,4,5]),('Bright','Book',[18,12,10],[2,3,4])]:
  for pt,row in zip(pts,lines):
   prefixes=['luRS','luBS','luIS','luBIS']if prefix=='Sans'else['lubR','lubB','lubI','lubBI']
   p=e.family(f'Lucida {prefix}',dict(zip(e.STYLE_ORDER,[f'{x}{pt:02}.bdf'for x in prefixes])),'Lucida notice/trademark conditions')
   if p['height']>PITCH[row]:
    # 18pt may exceed 32px Western extent; pick next actual native strike.
    if row!=2:continue
    pt=14;p=e.family(f'Lucida {prefix}',dict(zip(e.STYLE_ORDER,[f'{x}{pt:02}.bdf'for x in prefixes])),'Lucida notice/trademark conditions')
   if p['height']>PITCH[row]:continue
   px=e.parse(next(iter(p['paths'].values())))[0].get('PIXEL_SIZE')
   put(row,col,f'Lucida {prefix} {px}px',western_profile(p,PITCH[row]),'Secondary: check stroke contrast; licence review','u8g2 BDF',flag='thin')
 # Existing native fonts as meaningful regular-only references.
 for row,name in [(6,'Bold'),(7,'Micro'),(8,'Nano')]:
  data=(n.FONTDIR/f'NeoFont{name}.OS3KApp').read_bytes();info,gs=n.decode(data,len(data)-20)
  assert [c for c,g in enumerate(gs)if not g.getbbox()]==[32,160]
  put(row,'Sans','Neo '+name,{'R':dict(enumerate(gs))},'Existing proportional; regular-only provider','Original NeoFonts applet')
 for row,name in [(4,'large'),(5,'medium'),(6,'small')]:
  gs=roles.vendor(name)
  put(row,'Sans','Vendor '+name.title(),{'R':gs},'Existing proportional; regular-only reference','Original vendor resource')
 # Fixed and ttyp0 are Terminal choices, independent of style-family gate.
 for row,size in [(2,22),(3,18),(4,16),(5,12)]:
  if size in [16,18]:
   p=e.family(f'ttyp0 {size}',{'R':f'ttyp:{size}'},'ttyp0')
  else:
   p=e.family(f'ttyp0 {size}',{'R':f't0-{size}-uni.bdf'},'ttyp0')
  assert p['height']<=PITCH[row]
  faces=western_profile(p,PITCH[row]);advance=next(iter(p['faces']['R'].values()))['advance']
  put(row,'Terminal',f'ttyp0 {advance}×{size}',faces,f'{264//advance} columns; regular only here','ttyp0/u8g2; full Western checked')
 for row,name in [(4,'7x14.bdf'),(5,'6x13.bdf'),(6,'6x10.bdf'),(7,'6x9.bdf'),(8,'5x8.bdf')]:
  p=e.family('Fixed',{'R':name},'Public domain')
  assert p['height']<=PITCH[row]
  faces=western_profile(p,PITCH[row]);w=int(name.split('x')[0])
  put(row,'Terminal','Fixed '+name.removesuffix('.bdf').replace('x','×'),faces,f'{264//w} columns; full Western; regular only','X11 Misc Fixed via u8g2')
 for row,file,title,w in [(8,'glyphs.bdf','BetaWise Terminal 6×8',6),(9,'glyphs-5x7.bdf','BetaWise Terminal Small 5×7',5),(10,'glyphs-4x6.bdf','BetaWise Terminal Tiny 4×6',4)]:
  path=b.HERE.parents[2]/'fonts'/file
  props,gs,_=e.parse(path)
  # Native byte glyphs, not Unicode remapped; ASCII specimen only.
  put(row,'Terminal',title,{'R':{c:ncell(g,PITCH[row])for c,g in gs.items()}},f'{264//w} columns; actual project source','BetaWise Terminal BDF')
 # Draw matrix using fixed display enlargement and shared style baselines.
 heights={row:max([blockheight(x)for col in COLUMNS for x in choices[row,col]]+[0])for row in range(2,12)}
 # Stack multiple alternatives within each cell, not just the largest block.
 heights={row:max(110,max(sum(blockheight(x)for x in choices[row,col])+25 for col in COLUMNS))for row in range(2,12)}
 top=190;footer=640
 im=Image.new('RGB',(WIDTH,top+sum(heights.values())+footer),'white');d=ImageDraw.Draw(im)
 d.text((18,12),'Neo 264×65 — useful font choices by role and lines per screen',font=HEAD,fill='black')
 d.text((18,60),'Native bitmap samples at 2× nearest-neighbour throughout: AaBbCcDdEeFfGg. R / B / I / BI shown where supplied.',font=F,fill='#333333')
 d.text((18,94),'Shortlist for visual judgment, not a shipping commitment. Blank = no qualifying useful candidate selected. Terminal has no style requirement.',font=SMALL,fill='#333333')
 d.text((18,124),'† Existing extended-glyph repairs; ASCII unscaled. Small Lucida regulars may be too thin at 45dpi; compare their native bold faces.',font=SMALL,fill='#704400')
 for j,col in enumerate(COLUMNS):d.text((LEFT+j*CW+15,155),col,font=HEAD,fill='black')
 y=top
 for row in range(2,12):
  end=y+heights[row]
  d.rectangle((0,y,WIDTH,end),fill='#f4f6f7'if row%2==0 else'white')
  d.text((14,y+20),str(row),font=HEAD,fill='black');d.text((10,y+65),'lines',font=SMALL,fill='#555555')
  for j,col in enumerate(COLUMNS):
   x=LEFT+j*CW;d.line((x,y,x,end),fill='#bbbbbb',width=1);yy=y+12
   for item in choices[row,col]:
    drawitem(im,item,x+15,yy);yy+=blockheight(item)
  d.line((0,end,WIDTH,end),fill='#999999',width=2)
  # Independent row cards for readable browsing.
  y=end
 y+=25
 d.text((18,y),'Excluded existing dense-font references — not eligible selections',font=HEAD,fill='black');y+=50
 d.text((18,y),'Femto and Atto have a solid block for Ã (C3). Atto also clips @ / ƒ / ¡ on the 11th line. No qualifying 11-line candidate selected.',font=F,fill='#8b2424');y+=40
 for name,lines in [('Femto',9),('Atto',11)]:
  data=(n.FONTDIR/f'NeoFont{name}.OS3KApp').read_bytes();_,gs=n.decode(data,len(data)-20)
  item=dict(title=f'Neo {name}: {lines} lines — reference only',faces={'R':dict(enumerate(gs))},note='Known coverage defect; not a full-Western recommendation',flag='')
  drawitem(im,item,20,y);y+=blockheight(item)+10
 d.text((18,y+10),'Coverage: imported candidates check 218 Western printable characters. Neo-specific controls/device glyphs remain a separate mapping audit.',font=SMALL,fill='#444444')
 d.text((18,y+42),'Vendor/community references use original Neo byte tables. This Latin sample does not prove international readability.',font=SMALL,fill='#444444')
 d.text((18,y+74),'Mono means monospaced source design; Neo overhang padding can vary widths. Terminal choices preserve fixed ASCII columns.',font=SMALL,fill='#444444')
 im.save(OUT/'font-choice-matrix.png')
 y=top
 sections=[]
 for row in range(2,12):
  crop=Image.new('RGB',(WIDTH,heights[row]+50),'white');cd=ImageDraw.Draw(crop)
  for j,col in enumerate(COLUMNS):cd.text((LEFT+j*CW+15,5),col,font=HEAD,fill='black')
  crop.paste(im.crop((0,y,WIDTH,y+heights[row])),(0,50));crop.save(OUT/f'{row}-lines.png');y+=heights[row]
  sections.append(f'<h2>{row} lines</h2><a href="{row}-lines.png"><img src="{row}-lines.png"></a>')
 (OUT/'index.html').write_text('<!doctype html><meta charset="utf-8"><title>Neo font choice matrix</title><style>body{font:18px sans-serif;margin:20px}img{width:100%;image-rendering:pixelated}h2{margin-top:35px}</style><h1>Neo font choice matrix</h1><p>All specimens use the same 2× display enlargement. Click a row for its full image. R/B/I/BI are actual styles; existing regular-only references are labelled. Lucida is secondary due to thin strokes. Daggers identify existing extended-character repairs.</p><p><a href="font-choice-matrix.png">Complete card</a> | <a href="choices.json">Selection manifest</a></p>'+''.join(sections))
 (OUT/'choices.json').write_text(json.dumps(dict(sample=SAMPLE,display_scale=2,choices=manifest,excluded={'Femto':'C3 solid block','Atto':'C3 solid block; 11th-line clipping','ProFont':'No italic and extended encoding unverified','Spleen':'Incomplete Western in inspected sizes'},validation='All source geometry/normalization assertions passed; visual usefulness remains a design judgment, not automated legibility certification.'),indent=2)+'\n')
 print('Saved',im.size,len(manifest),'choices to',OUT)

def ncell(g,pitch):
 points=g['points'];top=min([y for x,y in points]+[0])
 # Actual Terminal source BDF has a baseline shared by all characters: use
 # declared ascent via source file instead of separately aligning each glyph.
 # All three source fonts use bottom=0 at their full cell height.
 im=Image.new('1',(g['advance'],pitch))
 for x,y in points:
  assert 0<=x<im.width and 0<=y+pitch<pitch,(x,y,pitch)
  im.putpixel((x,y+pitch),1)
 return im

def blockheight(item):
 return 68+sum(9+2*next(iter(face.values())).height for face in item['faces'].values())+22

def drawitem(im,item,x,y):
 d=ImageDraw.Draw(im);d.text((x,y),item['title'],font=F,fill='#7d4900'if item.get('flag')=='thin'else'black')
 d.text((x,y+29),item['note'],font=SMALL,fill='#666666');yy=y+61
 for st,face in item['faces'].items():
  mask=b.render_run(face,map(ord,SAMPLE));assert mask.width*SCALE<CW-80,(item['title'],mask.width)
  d.text((x,yy),st,font=SMALL,fill='#777777');b.draw_ink(im,mask,(x+43,yy),SCALE);yy+=mask.height*SCALE+9

if __name__=='__main__':main()
