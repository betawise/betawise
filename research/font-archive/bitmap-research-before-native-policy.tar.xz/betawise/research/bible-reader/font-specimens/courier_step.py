#!/usr/bin/env python3
"""Exact baseline-anchored three-row step oblique, for source-font design review."""
from pathlib import Path
import json,shutil
from PIL import Image,ImageDraw
import build as b
import courier_gentle as old
import reader_candidates as reader
OUT=b.HERE/'courier-step'
SAMPLES=['AaBbCcDdEeFfGg','HIlmnp MW mw ij','Reading the book.']

def step(points,width,oblique):
 # Baseline is y=0: normal body bottom rows -3/-2/-1, plus descenders, stay put.
 # Everything at -4 and above is displaced right by exactly one pixel.
 moved={(x+int(oblique and y<-3),y)for x,y in points}
 if not moved:return set(),dict(offset=0,removed=[],exact=True)
 left=min(x for x,y in moved);right=max(x for x,y in moved)+1
 if right-left<=width:
  offset=max(-left,min(0,width-right));removed=[]
 else:
  # Explicit experimental correction: choose one constant glyph placement with
  # the fewest edge pixels outside the cell. Every removed pixel is recorded.
  offsets=range(-right,width-left+1)
  offset=min(offsets,key=lambda s:(sum(not(0<=x+s<width)for x,y in moved),abs(s),s))
  removed=sorted((x,y)for x,y in moved if not 0<=x+offset<width)
 result={(x+offset,y)for x,y in moved if 0<=x+offset<width}
 assert len(result)==len(points)-len(removed)
 assert all(0<=x<width for x,y in result)
 return result,dict(offset=offset,removed=removed,exact=not removed)

def main():
 OUT.mkdir(exist_ok=True);shutil.copyfile(b.OUT/'FONT-LICENSE.txt',OUT/'FONT-LICENSE.txt');report=[];panels=[];audit_items=[]
 for lines,pitch in reader.ROWS:
  previous,meta,_,source=reader.smooth_courier(lines,pitch);w=meta['width'];baseline=meta['baseline']
  bases={st:{c:set(p)for c,p in source[st].items()}for st in ['R','B']}
  for st,c,op,np in reader.PATCHES[lines]:
   bases[st][c].remove(op)
   if np is not None:bases[st][c].add(np)
  result={};edits=[]
  for st,base in [('R','R'),('B','B'),('I','R'),('BI','B')]:
   result[st]={}
   for c,pts in bases[base].items():
    new,record=step(pts,w,st in ['I','BI']);g=Image.new('1',(w,pitch))
    for x,y in new:
     assert 0<=y+baseline<pitch
     g.putpixel((x,y+baseline),1)
    result[st][c]=g
    if record['removed']:
     edits.append(dict(style=st,code=f'{c:02X}',character=bytes([c]).decode('cp1252'),**record))
     audit_items.append((lines,pitch,w,baseline,st,c,pts,g,record))
  for st,face in result.items():reader.export(OUT/f'cour-{lines}-lines-{st}.bdf',face,baseline)
  # Keep the preceding inverse-shear draft, unmodified, as a historical comparator.
  if lines!=3:inverse,_=old.cells(old.patched(source,lines),w,pitch,baseline,'adaptive')
  else:inverse,_=old.cells(source,w,pitch,baseline,'adaptive')
  panel=Image.new('RGB',(2700,145+2*(120+pitch*12)),'white');d=ImageDraw.Draw(panel)
  d.text((12,8),f'Courier {lines} lines — same {w}px cells / {264//w} columns; no widening',font=b.TITLE,fill='black')
  d.text((12,40),'All samples 4× nearest-neighbour. Requested step: baseline rows -3/-2/-1 and descenders aligned; rows -4 and above +1px.',font=b.SMALL,fill='#444444')
  for j,title in enumerate(['Earlier inverse shear','Previous 6-degree oblique','Bottom-three-straight step']):d.text((12+j*900,74),title,font=b.LABEL,fill='black')
  d.text((1812,100),f'{len(edits)} glyph-style edge trims / {sum(len(e["removed"])for e in edits)} pixels, explicitly recorded',font=b.SMALL,fill='#a02020')
  for i,(st,oldst)in enumerate([('I','O'),('BI','BO')]):
   y=140+i*(120+pitch*12)
   for j,face in enumerate([inverse[oldst],previous[st],result[st]]):
    x=12+j*900;d.text((x,y),st,font=b.LABEL,fill='black')
    for k,text in enumerate(SAMPLES):
     mask=b.render_run(face,text.encode());assert mask.width*4<875
     b.draw_ink(panel,mask,(x,y+27+k*(pitch*4+7)),4)
  panel.save(OUT/f'{lines}-lines.png');panels.append(panel)
  if lines==5:panel.crop((1800,0,2700,panel.height)).save(OUT/'5-lines-requested.png')
  # Native bitmap previews: exact 264x65 pixels, no resampling, no screenshots.
  for st in ['I','BI']:
   page,text=b.page(result[st],lines,pitch);native=Image.new('RGB',page.size,'white');native.paste('black',(0,0),page)
   native.save(OUT/f'{lines}-lines-{st}-native.png')
   native.resize((1056,260),Image.Resampling.NEAREST).save(OUT/f'{lines}-lines-{st}-4x.png')
  entry=dict(lines=lines,width=w,columns=264//w,remainder=264%w,baseline=baseline,rule='R/B unchanged. I/BI: y<-3 shift +1; y>=-3 shift 0. Constant per-glyph placement permitted.',base_patches=meta['patches'],edge_trims=edits)
  report.append(entry)
 # Exact exception review: patched upright input, ideal step (expanded), final.
 audit=Image.new('RGB',(1400,95+len(audit_items)*155),'white');ad=ImageDraw.Draw(audit)
 ad.text((12,8),'Requested step: every additional edge correction',font=b.TITLE,fill='black')
 ad.text((12,40),'LEFT upright input / MIDDLE exact step, expanded / RIGHT fixed-width trimmed draft. These trims are not lossless.',font=b.SMALL,fill='#a02020')
 for i,(lines,pitch,w,baseline,st,c,pts,g,record)in enumerate(audit_items):
  y=90+i*155;ad.text((12,y),f'{lines} lines {st} {c:02X} '+bytes([c]).decode('cp1252'),font=b.LABEL,fill='black')
  ad.text((12,y+28),f'{len(record["removed"])} edge pixel(s)',font=b.SMALL,fill='#a02020')
  for j,pp in enumerate([pts,{(x+int(yy<-3),yy)for x,yy in pts}]):
   left=min(x for x,yy in pp);right=max(x for x,yy in pp)+1;mask=Image.new('1',(right-left,pitch))
   for x,yy in pp:mask.putpixel((x-left,yy+baseline),1)
   b.draw_ink(audit,mask,(350+j*320,y),6)
  b.draw_ink(audit,g,(990,y),6)
 audit.save(OUT/'edge-trim-audit.png')
 (OUT/'report.json').write_text(json.dumps(dict(scope='New alternative design, previous reader-candidates set preserved.',coverage='218 Western printable native-byte slots; Neo device/control map incomplete.',fonts=report,validation=dict(bdf_faces=16,roundtrip_glyphs=16*len(b.CODES),checks='Every ideal glyph uses exactly two baseline-anchored shift bands; only recorded edge pixels may be removed. Exact BDF pixel/advance round trip. Constant widths retained.'),interpretation='Native-size PNGs are 1:1 bitmap assets, not a claim about their physical on-screen size or LCD contrast. Source-font diagrams are for human review, not a Neo screenshot validation oracle.'),indent=2)+'\n')
 overview=Image.new('RGB',(2700,70+sum(p.height+20 for p in panels)),'white');od=ImageDraw.Draw(overview);od.text((12,10),'Courier: inverse shear / earlier gentle shear / requested bottom-three-row step',font=b.TITLE,fill='black');y=70
 for p in panels:overview.paste(p,(0,y));y+=p.height+20
 overview.save(OUT/'overview.png')
 sections=[]
 for lines,pitch in reader.ROWS:
  sections.append(f'<h2>{lines} lines</h2><a href="{lines}-lines.png"><img class="large" src="{lines}-lines.png"></a><p>Native 264×65 I / BI bitmaps (browser zoom can change apparent size):</p><img class="native" src="{lines}-lines-I-native.png"> <img class="native" src="{lines}-lines-BI-native.png"><p>Same bitmaps at exact 4× nearest-neighbour:</p><img class="large" src="{lines}-lines-I-4x.png"><img class="large" src="{lines}-lines-BI-4x.png">')
 (OUT/'index.html').write_text('<!doctype html><meta charset="utf-8"><title>Courier bottom-three step</title><style>body{font:17px sans-serif;margin:24px}img{image-rendering:pixelated}.large{max-width:100%}.native{width:264px;height:65px;border:1px solid #aaa}</style><h1>Courier bottom-three-row step</h1><p>Bottom three body rows are defined relative to the baseline, shared by all glyphs; descenders remain with that lower band. Rows above are shifted right exactly one pixel. No widening. A few glyphs need explicitly disclosed edge trims; inspect the correction audit before choosing this draft.</p><p>The earlier reader-candidates set remains unchanged. All font previews are binary source bitmaps, with no gray antialiasing or simulated dithering. Downscaled display can still make jagged shapes appear smoother than physical large LCD pixels.</p>'+''.join(sections)+'<h2>All additional edge corrections</h2><a href="edge-trim-audit.png"><img class="large" src="edge-trim-audit.png"></a><p><a href="report.json">Exact changes and checks</a></p>')
 for entry in report:print(entry['lines'],len(entry['edge_trims']),sum(len(x['removed'])for x in entry['edge_trims']),[(x['style'],x['code'])for x in entry['edge_trims']])
 print(OUT/'index.html')
if __name__=='__main__':main()
