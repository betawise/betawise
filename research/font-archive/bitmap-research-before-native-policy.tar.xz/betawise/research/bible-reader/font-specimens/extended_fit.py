"""Local extended-glyph candidate repairs; never used on ASCII."""
import unicodedata
from PIL import Image

def pixels(glyph):
    advance,box,src,bitmap=glyph
    left,top,right,bottom=box
    shift=max(0,-left)
    width=max(advance[0]+shift,right+shift,1)
    bitmap=bitmap.crop(src)
    points={(left+shift+x,top+y) for y in range(bitmap.height) for x in range(bitmap.width) if bitmap.getpixel((x,y))}
    return width,points

def image(width,height,points,top):
    result=Image.new('1',(width,height))
    for x,y in points:
        assert 0<=x<width and 0<=y-top<height
        result.putpixel((x,y-top),1)
    return result

def fit(glyph,face,code,top,limit,pitch):
    width,original=pixels(glyph)
    if not original:return Image.new('1',(width,pitch)),None
    low=min(y for x,y in original);high=max(y for x,y in original)+1
    if top<=low and high<=top+limit:return image(width,pitch,original,top),None
    assert code>=128,'ASCII must never enter the repair path'
    char=bytes([code]).decode('cp1252')
    reference=unicodedata.normalize('NFD',char)[0]
    if reference not in 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz':
        reference='H' if char.isupper() else 'x'
    _,ref=pixels(face[ord(reference)])
    split=min(y for x,y in ref)
    upper={(x,y)for x,y in original if y<split}
    base=original-upper
    overflow=max(0,top-low)
    moved={(x,y+overflow)for x,y in upper}|base
    def fits(points):return points and min(y for x,y in points)>=top and max(y for x,y in points)<top+limit
    if upper and overflow and fits(moved) and len(moved)==len(original) and all(y+overflow<split for x,y in upper):
        result=moved;method=f'accent/upper-band translated down {overflow}px';base_preserved=True
    elif upper and split>top and high<=top+limit:
        start=min(y for x,y in upper)
        src=image(width,split-start,upper,start)
        resized=src.convert('L').resize((width,split-top),Image.Resampling.BOX).point(lambda p:255 if p>=64 else 0,'1')
        replacement={(x,top+y)for y in range(resized.height)for x in range(width)if resized.getpixel((x,y))}
        assert replacement
        result=base|replacement;method='accent/upper-band compressed vertically; base pixels unchanged';base_preserved=True
    else:
        # Last resort affects this extended glyph only, retaining width/advance and
        # its ink bottom (thus its baseline relationship) whenever it already fits.
        end=min(high,top+limit)
        src=image(width,high-low,original,low)
        resized=src.convert('L').resize((width,end-top),Image.Resampling.BOX).point(lambda p:255 if p>=64 else 0,'1')
        result={(x,top+y)for y in range(resized.height)for x in range(width)if resized.getpixel((x,y))}
        method='extended glyph compressed vertically in isolation; review body shape';base_preserved=False
    assert fits(result)
    if base_preserved:
        assert {(x,y)for x,y in result if y>=split}==base
    record=dict(code=f'{code:02X}',character=char,method=method,source_top=low,source_bottom=high,
                overflow_above=max(0,top-low),overflow_below=max(0,high-top-limit),
                base_pixels_preserved=base_preserved,width_preserved=True,
                original_ink_pixels=len(original),adjusted_ink_pixels=len(result),review_required=True)
    return image(width,pitch,result,top),record
