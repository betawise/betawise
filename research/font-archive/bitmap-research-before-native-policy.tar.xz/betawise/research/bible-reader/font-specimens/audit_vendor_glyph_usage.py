#!/usr/bin/env python3
"""Static candidate census plus exact keyboard/help evidence; no screen inference.

Disassembly of arbitrary data is only a lead. Candidate hits are not certified
instructions or glyph consumers; see vendor-glyph-usage.md for reviewed findings.
"""
import json
import re
import struct
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).with_name('charset-review')
TARGETS = {0x08, 0x16, 0x90}


def main():
    inventory = json.loads((ROOT / 'research/abi-audit/vendor-image-inventory.json').read_text())
    entries = [r for r in inventory if r['path'].startswith('Ghidra/Alphasmart Neo/SmartApplets/')]
    rom_path = ROOT.parent / 'Ghidra/Alphasmart Neo/SmartApplets/os3kneorom.os3kos'
    rom = rom_path.read_bytes()
    key_outputs = []
    for key in range(80):
        pointer = struct.unpack_from('>I', rom, 0x44b526 - 0x410000 + key * 4)[0]
        if not 0x410000 <= pointer < 0x410000 + len(rom):
            continue
        at = pointer - 0x410000
        if rom[at] == 0:  # TranslateKeyToChar exits before modifiers for holes.
            continue
        for field in range(2):
            if rom[at + field] in TARGETS:
                key_outputs.append(dict(key=key, descriptor=f'{pointer:06X}',
                    modifiers='unshifted' if field == 0 else 'shifted', output=rom[at + field]))
        field = 2
        while rom[at + field]:
            mask, value = rom[at + field:at + field + 2]
            if value in TARGETS:
                key_outputs.append(dict(key=key, descriptor=f'{pointer:06X}',
                    modifiers=f'{mask:02X}', output=value))
            field += 2
            assert field < 100
    assert key_outputs == [dict(key=0x11, descriptor='447C01', modifiers='30', output=8)]
    alpha_path = ROOT.parent / 'Ghidra/Alphasmart Neo/SmartApplets/alphawordplus.os3kapp'
    alpha = alpha_path.read_bytes()
    help_text = b'\x08 (superscript dot): option-H'
    assert alpha.index(help_text) == 0x17c76
    resource_pointer = struct.unpack_from('>I', alpha, 0x14374 + 4 * 0x90)[0]
    resource = alpha[resource_pointer:alpha.index(b'\0', resource_pointer)]
    assert resource == b'Beamer sending is disabled.'
    candidates = []
    source_entries = [dict(path=str(rom_path.relative_to(ROOT.parent)), name='Neo 3.21 ROM')] + entries
    for entry in source_entries:
        path = ROOT.parent / entry['path']
        data = path.read_bytes()
        command = ['m68k-linux-gnu-objdump', '-D', '-b', 'binary', '-m', 'm68k:68000']
        if path == rom_path:
            command += ['--adjust-vma=0x410000', '--start-address=0x410094', '--stop-address=0x44a38e']
        lines = subprocess.run(command + [str(path)], check=True, capture_output=True,
                               text=True).stdout.splitlines()
        constants = []
        for index, line in enumerate(lines):
            if re.search(r'\b(?:move[bwl]|moveq|cmpi[bwl]|pea)\s+#?(?:22|144|-112|0x16|0x90)(?:,|$)', line):
                constants.append('\n'.join(lines[max(0, index-2):index+5]))
        strings = []
        for match in re.finditer(rb'[\x08\x16\x90\x20-\x7e]{8,}', data):
            text = match[0]
            if TARGETS.intersection(text) and len(re.findall(rb'[A-Za-z]{3,}', text)) >= 2:
                strings.append(dict(offset=f'{match.start():X}', bytes=text.hex(), display=repr(text[:180])))
        candidates.append(dict(path=entry['path'], name=entry['name'],
                               constant_candidates=constants, text_candidates=strings))
    report = dict(scope='Neo 3.21 ROM plus 27 inventoried vendor SmartApplets; excludes community NeoFonts',
        limitation='Candidate search is not whole-program dataflow; compressed/dynamic text and indirect/table-based consumers may remain.',
        key_outputs=key_outputs, alphaword_help=dict(offset='17C76', text=repr(help_text)),
        alphaword_resource_90=dict(pointer=f'{resource_pointer:X}', text=resource.decode()),
        candidates=candidates)
    assert len(entries) == 27
    (OUT / 'vendor-glyph-usage.json').write_text(json.dumps(report, indent=2) + '\n')
    print('PASS exact keyboard/help/resource evidence; retained candidate census for', len(source_entries), 'vendor images')


if __name__ == '__main__':
    main()
