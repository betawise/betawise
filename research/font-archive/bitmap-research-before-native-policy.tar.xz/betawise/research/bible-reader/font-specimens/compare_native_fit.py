#!/usr/bin/env python3
"""Current selected cells against largest fully fitting native Western strikes.
Exact offline source checks; no Neo screen capture and no inferred charset mapping.
"""
import json,hashlib,re
from pathlib import Path
from PIL import Image,ImageDraw
import build as b
import reader_candidates as r
import full_repertoire_comparison as full
import evaluate_substitutes as e
OUT=b.HERE/'native-fit-comparison'
TEXT=['AaBbCcDdEeFfGg HIlm ijmw','ÀÁÂÃÄÅ ÉÊË ÑÖÜ ŠŽŸ','àáâãäå éêë ñöü CÇ cç','g j p q y 0123456789 Œœ ß']

def load_selected(entry,pitch):
 faces={}
 for f in entry['files']:
  _,gs,_=e.parse(r.OUT/f['path']);face={}
  for c,g in gs.items():
   cell=Image.new('1',(g['advance'],pitch))
   for x,y in g['points']:
    yy=y+entry['metadata']['baseline'];assert 0<=x<cell.width and 0<=yy<pitch
    cell.putpixel((x,yy),1)
   face[c]=cell
  faces[f['style']]=face
 return faces

def drawface(im,face,x,y,pitch,base):
 d=ImageDraw.Draw(im)
 for i,text in enumerate(TEXT):
  yy=y+i*(pitch*3+5);mask=b.render_run(face,text.encode('cp1252'))
  assert mask.width*3<1060,(text,mask.width)
  d.line((x,yy+base*3,x+max(mask.width*3,330),yy+base*3),fill='#d0e4ef')
  b.draw_ink(im,mask,(x,yy),3)

def main():
 OUT.mkdir(exist_ok=True);manifest=json.loads((r.OUT/'manifest.json').read_text());records=[];links=[]
 for title,stem,styles,idbase in r.FAMILIES:
  familylinks=[]
  for lines,pitch in r.ROWS:
   entry=next(f for f in manifest['fonts']if f['stem']==stem and f['lines']==lines)
   current=load_selected(entry,pitch);bodies,meta=full.choose(stem,styles,10 if lines==6 else pitch,pitch)
   native=dict(zip(e.STYLE_ORDER,bodies))if bodies else None
   block=70+4*(pitch*3+5);im=Image.new('RGB',(2260,140+block*4+70),'white');d=ImageDraw.Draw(im)
   d.text((16,10),f'{title} — {lines} lines / {pitch}px pitch — all four styles',font=b.TITLE,fill='black')
   d.text((16,42),'3× integer pixels. Blue: baseline. RIGHT: every printable Western character fits unchanged across all four styles.',font=b.SMALL,fill='#444444')
   d.text((16,63),'Coverage: 218 CP1252 printable characters; complete Neo-US byte/control/icon mapping is not certified.',font=b.SMALL,fill='#8b3020')
   cm=entry['metadata'];pixel=cm.get('pixel_size',cm.get('pixels'))
   if pixel is None:
    source=cm['sources']['R']['path'];pt=int(re.search(r'courR(\d+)',source)[1]);dpi=int(Path(source).parent.name.removesuffix('dpi'))
    pixel=next(px for p,d,px in b.strike_options(stem)if (p,d)==(pt,dpi))
   d.text((16,91),f'CURRENT: {pixel}px strike; baseline restored; approved local glyph repairs retained',font=b.LABEL,fill='black')
   label=f"NATIVE: {meta['pixels']}px · {meta['points']}pt / {meta['dpi']}dpi · full ink {meta['height']}px"if native else f"NATIVE: none fits (smallest full ink {meta['minimum_ink_height']}px)"
   d.text((1140,91),label,font=b.LABEL,fill='black')
   files=[]
   for i,st in enumerate(e.STYLE_ORDER):
    y=140+i*block;d.text((16,y),st+' — '+dict(R='regular',B='bold',I='italic / oblique',BI='bold italic / oblique')[st],font=b.LABEL,fill='black')
    drawface(im,current[st],16,y+28,pitch,cm['baseline'])
    if native:
     drawface(im,native[st],1140,y+28,pitch,meta['baseline'])
     path=OUT/f'{stem}-{lines}-native-{st}.bdf';r.export(path,native[st],meta['baseline'])
     files.append(dict(style=st,path=path.name,sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
    else:d.text((1140,y+35),'No unmodified four-style strike fits this line count.',font=b.LABEL,fill='#9c3020')
    d.line((0,y+block-8,2260,y+block-8),fill='#cccccc')
   name=f'{stem}-{lines}-comparison.png';im.save(OUT/name)
   record=dict(family=title,stem=stem,lines=lines,pitch=pitch,current=dict(pixel_size=pixel,baseline=cm['baseline'],metadata=cm),native=meta,files=files)
   records.append(record);familylinks.append(f'<h3>{lines} lines</h3><a href="{name}"><img src="{name}"></a>')
   print(title,lines,'current',pixel,'native',meta.get('pixels','NONE'),'full ink',meta.get('height',meta.get('minimum_ink_height')))
  # Compact all-size summary: all four styles, current left and native right.
  summary=Image.new('RGB',(1900,120+sum(100+4*(pitch*2+10)for _,pitch in r.ROWS)),'white');sd=ImageDraw.Draw(summary)
  sd.text((16,10),title+' — current / unmodified native fits',font=b.TITLE,fill='black')
  sd.text((16,42),'All four styles at 2×. 218 Western printable glyphs checked; Neo-specific device mapping remains separate.',font=b.SMALL,fill='#555555')
  yy=80
  for lines,pitch in r.ROWS:
   record=next(f for f in records if f['stem']==stem and f['lines']==lines)
   entry=next(f for f in manifest['fonts']if f['stem']==stem and f['lines']==lines)
   current=load_selected(entry,pitch);bodies,meta=full.choose(stem,styles,10 if lines==6 else pitch,pitch)
   native=dict(zip(e.STYLE_ORDER,bodies))if bodies else None
   sd.text((16,yy),f'{lines} lines — current {record["current"]["pixel_size"]}px',font=b.LABEL,fill='black')
   sd.text((970,yy),(f'Native {meta["pixels"]}px / full ink {meta["height"]}px'if native else'No unchanged native strike fits'),font=b.LABEL,fill='black')
   for i,st in enumerate(e.STYLE_ORDER):
    sy=yy+32+i*(pitch*2+10)
    for x,faces in [(16,current),(970,native)]:
     sd.text((x,sy),st,font=b.SMALL,fill='#666666')
     if faces:
      mask=b.render_run(faces[st],'AaBbCcDd g j p q y ÀÉÑÖ Çç'.encode('cp1252'));assert mask.width*2<875
      b.draw_ink(summary,mask,(x+35,sy),2)
   yy+=100+4*(pitch*2+10);sd.line((0,yy-15,1900,yy-15),fill='#cccccc')
  summary.save(OUT/f'{stem}-summary.png')
  # One scrollable source card per family, preserving exact 3× scale.
  cards=[Image.open(OUT/f'{stem}-{lines}-comparison.png')for lines,_ in r.ROWS]
  stack=Image.new('RGB',(2260,sum(im.height for im in cards)),'white');y=0
  for card in cards:stack.paste(card,(0,y));y+=card.height
  stack.save(OUT/f'{stem}-all-sizes.png')
  links.append(f'<h2>{title}</h2>'+''.join(familylinks))
 report=dict(scope='218 CP1252 printable text glyphs, not certified full Neo-US device/control mapping',selection='Largest XLFD pixel size across all installed Adobe 75/100dpi strikes with common ink envelope fitting across all four styles. No native-side edits.',fonts=records,validation=dict(native_glyphs_verified=sum(x['native'].get('source_glyphs_verified',0)for x in records),native_rescalings=0,native_glyph_edits=0))
 (OUT/'manifest.json').write_text(json.dumps(report,indent=2)+'\n')
 (OUT/'index.html').write_text('<!doctype html><meta charset="utf-8"><title>Current versus native full-repertoire fonts</title><style>body{font:17px sans-serif;margin:24px}img{max-width:100%;image-rendering:pixelated}h2{margin-top:60px}</style><h1>Current versus largest native full-repertoire fits</h1><p>Left: current sizes with baseline/descender experiment withdrawn. Right: largest unmodified native strike fitting all four styles and all 218 printable Western characters. Every installed Adobe 75/100dpi strike is considered. This is not a certified Neo-US control/icon mapping.</p>'+''.join(links))
 (OUT/'README.md').write_text('''# Current sizes versus native full-repertoire fits

[Gallery](index.html), [manifest](manifest.json).

Run `python3 betawise/research/bible-reader/font-specimens/compare_native_fit.py`.
Regenerate the selected set first with `reader_candidates.py`.

All four families at 3/4/5/6 lines, all four styles. Left is the current set,
with the baseline/descender changes withdrawn. The independent Schoolbook
one-row umlaut and Helvetica six-line cedilla placement fixes remain.
Right is the largest native Adobe XLFD pixel size fitting the common ink
height of all 218 printable CP1252 characters and all four styles, considering
all installed 75/100dpi strikes. Exported native-side BDFs round-trip every
pixel and advance exactly. No scaling, accent edits or fallback glyphs.
Unavailable cells mean there is no native strike meeting these constraints.
The six-line choice allows 10 ink rows at 11px pitch, fitting the final row
inside 65 pixels. Other budgets are 21/16/13 rows.

The 218-glyph set is not a verified full Neo-US mapping: Neo control/device
symbols are absent from these X11 sources. No full 256-slot coverage claim is
made. Cards are offline bitmap design specimens, not Neo screen captures.
''')
 print(json.dumps(report['validation']));print(OUT/'index.html')
if __name__=='__main__':main()
