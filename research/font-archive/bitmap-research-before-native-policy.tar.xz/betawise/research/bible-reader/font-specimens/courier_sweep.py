#!/usr/bin/env python3
"""Every one-pixel row-step location for every available Courier Western glyph.
No pixel removal/tuning; static cards plus an offline per-glyph choice recorder.
"""
from pathlib import Path
from collections import defaultdict
import json,html,shutil,hashlib
from PIL import Image,ImageDraw,ImageFont
import build as b
import reader_candidates as reader
OUT=b.HERE/'courier-sweep'
SCALE=4;CW=92
LABEL=ImageFont.truetype(b.FONT,13);TITLE=b.TITLE

def candidate(points,width,baseline,boundary):
 shifted={(x+int(boundary is not None and y+baseline<boundary),y)for x,y in points}
 if not shifted:return dict(points=[],offset=0,overhang=[])
 left=min(x for x,y in shifted);right=max(x for x,y in shifted)+1
 if right-left<=width:offset=max(-left,min(0,width-right))
 else:offset=min(range(-right,width-left+1),key=lambda s:(sum(not 0<=x+s<width for x,y in shifted),abs(s),s))
 pts=sorted((x+offset,y)for x,y in shifted);over=[p for p in pts if not 0<=p[0]<width]
 assert len(pts)==len(points)
 for y in {y for x,y in points}:
  assert sorted(x for x,yy in pts if yy==y)==sorted(x+offset+int(boundary is not None and y+baseline<boundary)for x,yy in points if yy==y)
 return dict(points=pts,offset=offset,overhang=over)

def draw_choice(im,x,y,points,width,pitch,baseline,boundary,tag=None):
 info=candidate(points,width,baseline,boundary);d=ImageDraw.Draw(im)
 d.text((x+2,y),tag if tag is not None else 'upright'if boundary is None else f'T{boundary:02} / b{baseline-boundary:+}',font=LABEL,fill='black')
 ox=x+12;oy=y+22
 d.rectangle((ox-1,oy-1,ox+width*SCALE,oy+pitch*SCALE),outline='#aaaaaa')
 for xx,yy in info['points']:
  px=ox+xx*SCALE;py=oy+(yy+baseline)*SCALE
  color='#c02b23'if not 0<=xx<width else'black'
  d.rectangle((px,py,px+SCALE-1,py+SCALE-1),fill=color)
 if boundary is not None:
  line=oy+boundary*SCALE
  d.line((ox-5,line,ox-2,line),fill='#316cac',width=2)
  d.line((ox+width*SCALE+2,line,ox+width*SCALE+5,line),fill='#316cac',width=2)
 if info['overhang']:d.text((x+2,oy+pitch*SCALE+3),f'{len(info["overhang"])} red px',font=LABEL,fill='#b02020')
 return info

def main():
 OUT.mkdir(exist_ok=True);shutil.copyfile(b.OUT/'FONT-LICENSE.txt',OUT/'FONT-LICENSE.txt')
 sizes={};pages=[];verified=0;counts={}
 for lines,pitch in reader.ROWS:
  source,advance,baseline,paths=reader.courier_source(lines,pitch);width=advance+1
  # Deliberately no reader.PATCHES: these are the original selected upright
  # inputs (prior vertical extended repairs only), before horizontal retouching.
  faces={st:{f'{c:02X}':sorted(source[st][c])for c in b.CODES}for st in ['R','B']}
  sizes[str(lines)]=dict(lines=lines,height=pitch,width=width,baseline=baseline,columns=264//width,remainder=264%width,faces=faces,native_faces={st:{f'{c:02X}':sorted(source[st][c])for c in b.CODES}for st in ['O','BO']},source_paths=paths)
  groups=defaultdict(list)
  for code in b.CODES:groups[code//16].append(code)
  rowheight=2*(pitch*SCALE+59)+34;imagewidth=165+(pitch+1)*CW
  comparisons=0;overhangs=0
  for block,codes in sorted(groups.items()):
   im=Image.new('RGB',(imagewidth,110+len(codes)*rowheight),'white');d=ImageDraw.Draw(im)
   d.text((12,8),f'Courier {lines} lines — {width}px cells / {264//width} cols — slots {block:X}0–{block:X}F',font=TITLE,fill='black')
   d.text((12,40),'Upright / native oblique / EVERY row boundary. R upper row, B lower row. All glyphs 4×; no pixel deletion, blur or custom tuning.',font=LABEL,fill='#444444')
   d.text((12,61),'T = boundary counted from top of font cell; b = body rows below cut, relative to baseline. Upper rows +1px; red ink exceeds cell.',font=LABEL,fill='#444444')
   for i,code in enumerate(codes):
    y=105+i*rowheight;ch=bytes([code]).decode('cp1252');name='SPACE'if code==32 else'NBSP'if code==160 else ch
    d.rectangle((0,y,imagewidth,y+rowheight),fill='#f5f6f7'if i%2 else'white')
    d.text((10,y+8),f'{code:02X}  {name}',font=b.LABEL,fill='black')
    for k,st in enumerate(['R','B']):
     yy=y+27+k*(pitch*SCALE+59);d.text((12,yy),st,font=b.LABEL,fill='black')
     points=set(source[st][code])
     for j,boundary in enumerate([None,'native']+list(range(1,pitch))):
      native=boundary=='native';native_st='O'if st=='R'else'BO'
      info=draw_choice(im,165+j*CW,yy,set(source[native_st][code])if native else points,width,pitch,baseline,None if native else boundary,'native '+native_st if native else None)
      verified+=1
      if boundary is not None and boundary!='native':comparisons+=1
      if info['overhang']:overhangs+=1
    d.line((0,y+rowheight,imagewidth,y+rowheight),fill='#bbbbbb')
   file=f'{lines}-lines-{block:X}0-{block:X}F.png';im.save(OUT/file)
   pages.append(dict(lines=lines,block=f'{block:X}0–{block:X}F',file=file,codes=[f'{c:02X}'for c in codes]))
  counts[str(lines)]=dict(upright_glyphs=2*len(b.CODES),step_candidates=comparisons,with_overhang=overhangs,pages=len(groups))
  # Compact a/W example, both weights, all boundaries.
  codes=[ord('a'),ord('W')];im=Image.new('RGB',(imagewidth,100+len(codes)*rowheight),'white');d=ImageDraw.Draw(im)
  d.text((12,8),f'Courier {lines} lines — a / W, every one-pixel step position',font=TITLE,fill='black')
  d.text((12,40),'Upright / native oblique / T01…: shift every row ABOVE that boundary +1px. Red pixels overhang the same fixed-width cell.',font=LABEL,fill='#444444')
  for i,code in enumerate(codes):
   y=90+i*rowheight;d.text((10,y+8),f'{code:02X} {chr(code)}',font=b.LABEL,fill='black')
   for k,st in enumerate(['R','B']):
    yy=y+27+k*(pitch*SCALE+59);d.text((12,yy),st,font=b.LABEL,fill='black')
    for j,boundary in enumerate([None,'native']+list(range(1,pitch))):
     native=boundary=='native';native_st='O'if st=='R'else'BO'
     draw_choice(im,165+j*CW,yy,set(source[native_st][code])if native else set(source[st][code]),width,pitch,baseline,None if native else boundary,'native '+native_st if native else None)
  im.save(OUT/f'{lines}-lines-a-W.png')
 data=dict(sizes=sizes,codes=[dict(hex=f'{c:02X}',char=bytes([c]).decode('cp1252'))for c in b.CODES],pages=pages)
 data['datasetId']=hashlib.sha256(json.dumps(data,separators=(',',':')).encode()).hexdigest()
 (OUT/'data.json').write_text(json.dumps(data,separators=(',',':'))+'\n')
 report=dict(scope='All 218 available Western printable source slots × R/B upright bases × four line counts. Neo low-byte device/control symbols are not invented.',method='Each font-cell row boundary tested independently: exactly +1px above, 0 below, followed by one constant glyph placement minimizing overhang. No pixel edits, no automatic cut choice, no widened cells.',definitions=dict(T='Boundary row counted from font-cell top (between rows T-1 and T)',b='baseline minus T: body rows below boundary; b<0 places boundary in descenders'),counts=counts,validation=dict(candidate_bitmaps_verified=verified,static_pages=len(pages),source_pixel_count_and_row_shape='Exact for every candidate, including visible out-of-cell pixels',no_clipping=True),model_fonts='Installed Courier foundry inventory includes Adobe only; upright and one oblique category, no separately labelled gentler oblique. Search is not proof no other bitmap exists.')
 (OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
 template=(Path(__file__).with_name('courier_sweep_picker.html')).read_text()
 template=template.replace('<a href="courier-sweep/README.md">Archived output and reproduction notes</a>', '<a href="cards.html">All static image cards</a><a href="report.json">Scope and exact checks</a><a href="data.json">Source glyph data</a>')
 (OUT/'index.html').write_text(template.replace('/*DATA*/',json.dumps(data,separators=(',',':')).replace('</','<\\/')))
 (OUT/'cards.html').write_text('<!doctype html><meta charset="utf-8"><title>Courier exhaustive step cards</title><style>body{font:17px sans-serif;margin:24px}img{max-width:100%;image-rendering:pixelated}</style><h1>Every Courier glyph / every one-pixel step position</h1><p>Original upright R/B and native O/BO references; no horizontal patches or pixel deletion. Red ink is real source overhang outside the fixed cell. T is a font-cell row boundary; b is baseline minus T. Click an image for the full 4× pixel version.</p><p><a href="index.html">Interactive picker</a> | <a href="report.json">Scope and checks</a></p>'+''.join(f'<section><h2>{p["lines"]} lines, slots {p["block"]}</h2><a href="{p["file"]}"><img loading="lazy" src="{p["file"]}"></a></section>'for p in pages))
 print(json.dumps(report['validation']))
 print('Step candidates:',sum(v['step_candidates']for v in counts.values()))
 print(OUT/'index.html')
if __name__=='__main__':main()
