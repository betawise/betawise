#!/usr/bin/env python3
"""Show original bearings/advances separately from normalized Neo glyph cells."""
import json
from PIL import Image,ImageDraw
import build as b
STYLES=('R','B','O','BO')

def source_run(face,codes):
    points=set();pen=0
    for c in codes:
        advance,box,src,bitmap=face[c];left,top,right,bottom=box;ink=bitmap.crop(src)
        for y in range(ink.height):
            for x in range(ink.width):
                if ink.getpixel((x,y)):points.add((pen+left+x,top+y))
        pen+=advance[0]
    first=min(0,min(x for x,y in points));last=max(pen,max(x for x,y in points)+1)
    im=Image.new('1',(last-first,14))
    for x,y in points:im.putpixel((x-first,y+10),1)
    return im,pen

def main():
    im=Image.new('RGB',(1120,1000),'white');d=ImageDraw.Draw(im)
    d.text((12,8),'Native 8px hinting and spacing — source versus current Neo cells',font=b.TITLE,fill='black')
    d.text((12,40),'Upper samples isolate source artwork. Lower samples show how overhang padding changes the advances in déjà.',font=b.SMALL,fill='#444444')
    report={'styles':[]}
    for n,style in enumerate(STYLES):
        x=12+n*275
        d.text((x,83),style,font=b.LABEL,fill='black')
        _,cour=b.source('cour',style,8,75);_,helv=b.source('helv',style,8,75)
        mask,advance=source_run(cour,[ord('m')]);d.text((x,112),'Courier m (8×)',font=b.SMALL,fill='#555555');b.draw_ink(im,mask,(x,140),8)
        mask,advance=source_run(helv,'i j'.encode());d.text((x,264),'Helvetica i j (8×)',font=b.SMALL,fill='#555555');b.draw_ink(im,mask,(x,292),8)
        codes='déjà'.encode('cp1252');native,advance=source_run(helv,codes)
        cells=b.read_font(b.OUT/f'aligned6-helv-{style}.bdf','iso8859-1');cellwidth=sum(cells[c].width for c in codes)
        source_canvas=Image.new('1',(native.width,14));source_canvas.paste(native,(0,0))
        cell_canvas=Image.new('1',(cellwidth,14));xx=0
        for c in codes:cell_canvas.paste(cells[c],(xx,2));xx+=cells[c].width
        d.text((x,465),f'Source déjà: {advance}px advance (8×)',font=b.SMALL,fill='#555555');b.draw_ink(im,source_canvas,(x,495),8)
        d.text((x,635),f'Neo cells: {cellwidth}px advance (8×)',font=b.SMALL,fill='#555555');b.draw_ink(im,cell_canvas,(x,665),8)
        entries=[]
        for c in codes:
            entries.append(dict(character=bytes([c]).decode('cp1252'),source_advance=helv[c][0][0],source_box=helv[c][1],neo_cell_width=cells[c].width))
        report['styles'].append(dict(style=style,source_word_advance=advance,neo_word_advance=cellwidth,glyphs=entries))
    d.text((12,850),'Source: original Adobe X11 75dpi 8pt bitmaps. No synthetic emboldening. Display enlargement is integer nearest-neighbour.',font=b.SMALL,fill='#555555')
    d.text((12,878),'The source word uses pen advances and overhangs. The current converter makes each glyph a self-contained ink-width cell.',font=b.SMALL,fill='#555555')
    im.save(b.OUT/'native8-hinting-spacing-diagnostic.png')
    (b.OUT/'native8-hinting-spacing-diagnostic.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
if __name__=='__main__':main()
