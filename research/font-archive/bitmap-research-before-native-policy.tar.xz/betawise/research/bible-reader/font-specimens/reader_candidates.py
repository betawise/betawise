#!/usr/bin/env python3
"""Selected four-family reader set; native Courier slant and fixed cedilla bodies.
Offline source-bitmap design study. Not LCD acceptance or installed providers.
"""
from pathlib import Path
import math,json,hashlib,shutil
from PIL import Image,ImageDraw
import build as b
import evaluate_substitutes as e
import courier_gentle as old
import cedilla_fit
import reader_accent_fit
import full_repertoire_comparison as native_fit
OUT=b.HERE/'reader-candidates'
ROWS=[(3,21),(4,16),(5,13),(6,11)]
FAMILIES=[('Times','tim',('R','B','I','BI'),0xaff0),('Helvetica','helv',('R','B','O','BO'),0xaff4),('Schoolbook','ncen',('R','B','I','BI'),0xaff8),('Courier','cour',('R','B','O','BO'),0xaffc)]
PHASES=sorted([i/16 for i in range(16)],key=lambda p:abs(p-.75))
# Upright-source exceptions. These replace the previous native-oblique patches.
# Euro's 13-column bars cannot fit the 12-column 3-line cell by translation.
PATCHES={3:[('B',0x80,(-3,y),None)for y in [-9,-8,-5,-4]],
         4:[],5:[],6:[('B',0x99,(-1,-8),(3,-8))]}

def loaded_body(stem,styles,lines,pitch):
 if lines==3:
  bodies,meta=b.body_fonts(stem,styles,pitch,pitch)
  assert bodies
  return dict(zip(e.STYLE_ORDER,bodies)),meta
 if lines==6 and stem in ['helv','ncen','cour']:
  paths={st:b.OUT/f'aligned6-{stem}-{src}.bdf'for st,src in zip(e.STYLE_ORDER,styles)}
  baseline=8
  meta=dict(pixel_size=8,points=8,dpi=75,baseline=baseline,method='Aligned native 8px candidate; previous extended repairs retained')
 else:
  entry=next(x for x in json.loads((b.OUT/'report.json').read_text())['fonts']if x['family']==dict(tim='Times',helv='Helvetica',ncen='Century Schoolbook',cour='Courier')[stem]and x['lines']==lines)
  paths={st:b.OUT/f'{stem}-{lines}-lines-{src}.bdf'for st,src in zip(e.STYLE_ORDER,styles)};baseline=entry['baseline'];meta=entry
 faces={}
 for st,path in paths.items():
  _,gs,_=e.parse(path);face={}
  for code in b.CODES:
   g=gs[code];im=Image.new('1',(g['advance'],pitch))
   for x,y in g['points']:
    assert 0<=y+baseline<pitch
    im.putpixel((x,y+baseline),1)
   face[code]=im
  faces[st]=face
 return faces,meta

def courier_source(lines,pitch):
 if lines!=3:return old.source(lines)
 faces,meta=loaded_body('cour',('R','B','O','BO'),lines,pitch);out={};paths=[]
 for st,face in zip(old.STYLES,faces.values()):
  path,raw=b.source('cour',st,meta['points'],meta['dpi']);paths.append(str(path))
  out[st]={c:{(x-max(0,-raw[c][1][0]),y-meta['baseline'])for y in range(g.height)for x in range(g.width)if g.getpixel((x,y))}for c,g in face.items()}
 return out,raw[65][0][0],meta['baseline'],paths

def rotate_rows(points,width,oblique):
 if not points:return set(),dict(angle=6 if oblique else 0,phase=.75,offset=0,shifts={})
 for angle in ([6,5,4,3,2,1,0]if oblique else[0]):
  for phase in (PHASES if oblique else[0]):
   shifts={y:math.floor(-y*math.tan(math.radians(angle))+phase)if oblique else 0 for x,y in points}
   shifted={(x+shifts[y],y)for x,y in points}
   a=min(x for x,y in shifted);z=max(x for x,y in shifted)+1
   if z-a>width:continue
   offset=max(-a,min(0,width-z));result={(x+offset,y)for x,y in shifted}
   shifts={y:s+offset for y,s in shifts.items()}
   ys=sorted(shifts)
   assert all(shifts[a]>=shifts[z]for a,z in zip(ys,ys[1:])),shifts
   assert len(result)==len(points)and all(0<=x<width for x,y in result)
   for y in ys:
    assert sorted(x for x,yy in result if yy==y)==sorted(x+shifts[y]for x,yy in points if yy==y)
   return result,dict(angle=angle,phase=phase,offset=offset,shifts=shifts)
 raise AssertionError(('no lossless fit',width,points))

def smooth_courier(lines,pitch):
 source,w,baseline,paths=courier_source(lines,pitch);width=w+1
 bases={s:{c:set(p)for c,p in source[s].items()}for s in ['R','B']}
 for st,c,oldpt,newpt in PATCHES[lines]:
  assert oldpt in bases[st][c]and(newpt is None or newpt not in bases[st][c])
  bases[st][c].remove(oldpt)
  if newpt is not None:bases[st][c].add(newpt)
 faces={};details={};pixels=0
 for st,base in [('R','R'),('B','B'),('I','R'),('BI','B')]:
  face={};details[st]={}
  for c,points in bases[base].items():
   transformed,record=rotate_rows(points,width,st in ['I','BI'])
   g=Image.new('1',(width,pitch))
   for x,y in transformed:
    assert 0<=y+baseline<pitch
    g.putpixel((x,y+baseline),1)
   assert sum(bool(g.getpixel((x,y)))for y in range(pitch)for x in range(width))==len(points)
   face[c]=g;details[st][f'{c:02X}']=record;pixels+=len(points)
  faces[st]=face
 meta=dict(lines=lines,pitch=pitch,baseline=baseline,width=width,columns=264//width,remainder=264%width,source_width=w,source_paths=paths,
           method='Synthetic gentle oblique from native upright R/B; monotonic integer row shear, normally 6 degrees; phase/angle chosen only for width fit.',
           patches=[dict(base_style=s,code=f'{c:02X}',old=op,new=np)for s,c,op,np in PATCHES[lines]],
           reduced_angle={s:[c for c,r in records.items()if r['angle']<6]for s,records in details.items()if s in ['I','BI']},
           source_pixels_verified=pixels)
 return faces,meta,details,source

def selected_courier(lines,pitch):
 selected=b.HERE/'courier-stock-fit'
 report=json.loads((selected/'report.json').read_text())
 metadata=next(r for r in report['fonts']if r['lines']==lines)
 faces={}
 for st,source_style in zip(e.STYLE_ORDER,old.STYLES):
  _,gs,_=e.parse(selected/f'cour-{lines}-lines-{source_style}.bdf')
  faces[st]={code:Image.new('1',(metadata['width'],pitch))for code in b.CODES}
  for code in b.CODES:
   for x,y in gs[code]['points']:faces[st][code].putpixel((x,y+metadata['baseline']),1)
 metadata={**metadata,'method':'Selected stock-slant Courier from courier-stock-fit; local edge/mark repairs, six-line regular m from bold, and oblique a/accents bottom pixel.'}
 return faces,metadata

def export(path,face,baseline):
 # Printable native-byte subset only; do not fabricate the Neo device/control slots.
 h=next(iter(face.values())).height;maxw=max(g.width for g in face.values())
 out=['STARTFONT 2.1',f'FONT -betawise-reader-medium-r-normal--{h}-0-75-75-p-0-fontspecific-0','SIZE 10 75 75',f'FONTBOUNDINGBOX {maxw} {h} 0 {baseline-h}','STARTPROPERTIES 3',f'FONT_ASCENT {baseline}',f'FONT_DESCENT {h-baseline}','COPYRIGHT "Adobe/DEC X11 derivative research; see FONT-LICENSE.txt"','ENDPROPERTIES',f'CHARS {len(face)}']
 for c,g in sorted(face.items()):
  w=g.width;n=(w+7)//8
  out +=[f'STARTCHAR slot{c:02X}',f'ENCODING {c}','SWIDTH 500 0',f'DWIDTH {w} 0',f'BBX {w} {h} 0 {baseline-h}','BITMAP']
  for y in range(h):out.append(f'{sum(bool(g.getpixel((x,y)))<<(n*8-1-x)for x in range(w)):0{n*2}X}')
  out.append('ENDCHAR')
 out.append('ENDFONT');path.write_text('\n'.join(out)+'\n')
 _,gs,_=e.parse(path)
 for c,g in face.items():
  assert gs[c]['advance']==g.width
  assert gs[c]['points']=={(x,y-baseline)for y in range(h)for x in range(g.width)if g.getpixel((x,y))}

def sample(im,face,text,xy,scale=3):
 mask=b.render_run(face,text.encode('cp1252'));b.draw_ink(im,mask,xy,scale);return mask.width*scale

def comparison(lines,pitch,new,meta,source):
 w=meta['width'];base=meta['baseline']
 if lines!=3:
  previous=old.patched(source,lines);before,_=old.cells(previous,w,pitch,base,'adaptive')
 else:
  before,_=old.cells(source,w,pitch,base,'adaptive')
 im=Image.new('RGB',(1800,140+2*(140+pitch*12)),'white');d=ImageDraw.Draw(im)
 d.text((12,8),f'Courier {lines} lines: {w}px fixed cells, {meta["columns"]} columns, {meta["remainder"]}px unused',font=b.TITLE,fill='black')
 d.text((12,40),'LEFT: inverse-shear method. RIGHT: new monotonic oblique from upright. Both displayed 4×; no grayscale.',font=b.SMALL,fill='#444444')
 for i,(st,oldst,basekey)in enumerate([('I','O','R'),('BI','BO','B')]):
  y=85+i*(140+pitch*12)
  for j,face in enumerate([before[oldst],new[st]]):
   x=12+j*900;d.text((x,y),('Old 'if j==0 else'New ')+st,font=b.LABEL,fill='black')
   for k,text in enumerate(['AaBbCcDdEeFfGg','HIlmnp MW mw ij','Reading the book.']):
    assert sample(im,face,text,(x,y+28+k*(pitch*4+6)),4)<875
 im.save(OUT/f'courier-{lines}-before-after.png')

def cedilla_audits(fonts,before,records):
 for title,stem,styles,idbase in FAMILIES:
  blocks=[80+4*(36+pitch*6+14)for lines,pitch in ROWS]
  im=Image.new('RGB',(1400,70+sum(blocks)),'white');d=ImageDraw.Draw(im)
  d.text((12,8),title+' — cedilla baseline: previous / corrected',font=b.TITLE,fill='black')
  d.text((12,40),'C Ç c ç ¸ at 3×. Blue line is the shared baseline; corrected C/c body pixels match their plain counterpart exactly.',font=b.SMALL,fill='#444444')
  y=70
  for (lines,pitch),block in zip(ROWS,blocks):
   meta=next(r for r in records if r['stem']==stem and r['lines']==lines);baseline=meta['baseline']
   d.text((12,y),f'{lines} lines',font=b.LABEL,fill='black')
   for i,st in enumerate(e.STYLE_ORDER):
    yy=y+35+i*(36+pitch*6+14);d.text((12,yy),st,font=b.LABEL,fill='black')
    for j,face in enumerate([before[stem,lines][st],fonts[stem,lines][st]]):
     x=100+j*650;d.text((x,yy), 'Previous'if j==0 else'Corrected',font=b.SMALL,fill='#555555')
     mask=b.render_run(face,'CÇ cç ¸'.encode('cp1252'))
     d.line((x,yy+20+baseline*3,x+max(mask.width*3,200),yy+20+baseline*3),fill='#abcce9')
     b.draw_ink(im,mask,(x,yy+20),3)
   y+=block
  im.save(OUT/f'{stem}-cedillas.png')

def main():
 OUT.mkdir(exist_ok=True);manifest=[];fonts={};courier=[];cedilla_records=[];cedilla_before={};revision_before={};accent_records=[]
 shutil.copyfile(b.OUT/'FONT-LICENSE.txt',OUT/'FONT-LICENSE.txt')
 for title,stem,styles,idbase in FAMILIES:
  for lines,pitch in ROWS:
   if lines<6:
    bodies,source_meta=native_fit.choose(stem,styles,pitch,pitch)
    assert bodies is not None
    face=dict(zip(e.STYLE_ORDER,bodies))
    meta={**source_meta,'pixel_size':source_meta['pixels'],'selection':'Unmodified native full-Western fit; no accent, cedilla, descender or slant edits.'}
    corrections=[]
   else:
    if stem=='cour':
     face,meta=selected_courier(lines,pitch);courier.append(meta)
    else:face,meta=loaded_body(stem,styles,lines,pitch)
    face,corrections=cedilla_fit.repair(stem,styles,lines,pitch,face,meta)
    meta={**meta,'selection':'Previously reviewed six-line glyphs retained exactly.'}
   cedilla_records.append(dict(family=title,stem=stem,lines=lines,baseline=meta['baseline'],corrections=corrections))
   fonts[stem,lines]=face
   files=[]
   for st,gs in face.items():
    path=OUT/f'{stem}-{lines}-lines-{st}.bdf';export(path,gs,meta['baseline']);files.append(dict(style=st,path=path.name,sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
   manifest.append(dict(family=title,stem=stem,lines=lines,pitch=pitch,reserved_id=f'{idbase+lines-3:04X}',files=files,metadata=meta))
 # Unified card: a reader page and four actual style specimens in every cell.
 CW=650;RH=600;LEFT=100;WIDTH=LEFT+4*CW+20
 im=Image.new('RGB',(WIDTH,160+len(ROWS)*RH+120),'white');d=ImageDraw.Draw(im)
 d.text((12,8),'Reader candidates — four families × 3 / 4 / 5 / 6 lines',font=b.TITLE,fill='black')
 d.text((12,40),'Native glyphs displayed 2×. Three/four/five lines: untouched native strikes. Six lines: previously reviewed repairs retained exactly.',font=b.SMALL,fill='#444444')
 d.text((12,63),'All four styles share a line pitch. Full Western = 218 printable CP1252 slots, not a complete Neo control/device mapping.',font=b.SMALL,fill='#444444')
 for j,(title,stem,styles,idbase)in enumerate(FAMILIES):d.text((LEFT+j*CW+12,107),title,font=b.TITLE,fill='black')
 for i,(lines,pitch)in enumerate(ROWS):
  y=155+i*RH;d.rectangle((0,y,WIDTH,y+RH),fill='#f3f5f7'if lines%2==0 else'white');d.text((12,y+12),str(lines),font=b.TITLE,fill='black');d.text((8,y+44),'lines',font=b.SMALL,fill='black')
  for j,(title,stem,styles,idbase)in enumerate(FAMILIES):
   x=LEFT+j*CW+12;face=fonts[stem,lines];entry=next(m for m in manifest if m['stem']==stem and m['lines']==lines);m=entry['metadata']
   d.text((x,y+12),entry['reserved_id']+' · '+(f'{m["width"]}px / {m["columns"]} cols'if stem=='cour' and lines==6 else f'{m["pixel_size"]}px strike'),font=b.LABEL,fill='black')
   page,text=b.page(face['R'],lines,pitch);b.draw_ink(im,page,(x,y+43),2);d.rectangle((x-1,y+42,x+528,y+172),outline='#888888')
   yy=y+197
   for st,gs in face.items():
    d.text((x,yy),st,font=b.LABEL,fill='#666666')
    assert sample(im,gs,'AaBbCcDdEeFfGg',(x+35,yy),2)<570
    yy+=pitch*2+11
   assert sample(im,face['R'],'ÀÉÑÖÜ Çç Œœ ß',(x,yy+9),2)<620
   d.line((x-12,y,x-12,y+RH),fill='#cccccc')
  d.line((0,y+RH,WIDTH,y+RH),fill='#999999')
 d.text((12,im.height-95),'3/4/5-line native glyphs have no custom trims or added cell width. Six-line Courier retains its approved 6px cells / 44 columns.',font=b.SMALL,fill='#444444')
 d.text((12,im.height-67),'IDs are reservations only. BDFs are research candidates; no applet installation, production packaging or complete Neo-US coverage is claimed.',font=b.SMALL,fill='#444444')
 im.save(OUT/'reader-set.png')
 report=dict(scope='16 candidate providers, four styles each, 218 printable Western native-byte slots; not complete Neo-US control/device coverage.',fonts=manifest,courier=courier,
  validation=dict(bdf_faces=64,roundtrip_glyphs=64*len(b.CODES),courier_slant='Native stock O/BO; approved six-line repairs only',cedilla_bodies_verified=32,cedilla_body_vertical_shifts=0,production_changed=False))
 report['cedilla_corrections']=cedilla_records
 report['accent_revisions']=accent_records
 report['validation']['ascii_above_baseline_preserved']=True
 report['validation']['baseline_shift_experiment_withdrawn']=True
 report['validation']['untouched_native_faces']=48
 report['validation']['untouched_native_glyphs']=48*len(b.CODES)
 report['validation']['six_line_faces_preserved']=16
 (OUT/'manifest.json').write_text(json.dumps(report,indent=2)+'\n')
 # Earlier accent/cedilla comparison cards remain historical artifacts.
 (OUT/'index.html').write_text('<!doctype html><meta charset="utf-8"><title>Selected reader fonts</title><style>body{font:17px sans-serif;margin:24px}img{max-width:100%;image-rendering:pixelated}</style><h1>Selected reader fonts</h1><p>Times, Helvetica, Schoolbook and Courier, each at 3/4/5/6 lines. Three/four/five-line faces use the largest untouched native strike fitting all 218 Western printable glyphs across all four styles. Six-line faces retain their previously reviewed corrections exactly.</p><a href="reader-set.png"><img src="reader-set.png"></a><p><a href="manifest.json">Selections, source metadata, reserved IDs and BDF hashes</a></p><p>Complete Neo-US control/device mapping and production packaging remain separate work. Older accent and cedilla comparison cards are historical, not the current selection.</p>')

 print(json.dumps(report['validation']))
 for meta in courier:print(meta['lines'],meta['width'],meta['columns'])
 print(OUT/'index.html')
if __name__=='__main__':main()
