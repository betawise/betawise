# Native glyph repertoires

[neo-us.txt](neo-us.txt) records every byte slot using a hexadecimal byte and
Unicode scalar, or `UNMAPPED` when the native artwork's identity is unresolved.
Python readers can use `charsets.load(path)` from `os3k/`.

Neo US printable Western glyph positions match the supplied reader fonts and
Terminal. Additional mappings incorporate the submitted human review and exact
reference-font comparisons. Slot 04 is uppercase Ń (U+0143), correcting the
earlier mistaken Ñ identification and the submitted lowercase ń. Slot 1F is Σ.
Slot 17 uses U+25AF WHITE VERTICAL RECTANGLE, rather than assigning an
unsupported APL meaning to the outline box.
The descriptor maps all 256 slots. Cross-font comparisons support 16 as an
alternate rendering of 0D (U+21B5), and 90 as an alternate rendering of 60
(U+0060). Several supplied Neo fonts have identical bitmaps for these pairs.

Evidence and reproduction are recorded in
`research/bible-reader/font-specimens/charset-review/README.md`.
The byte 81 glyph matches U+2310 ⌐ in four reference fonts. These low-resolution
shape comparisons do not uniquely establish historical Unicode semantics;
several equivalent-looking reference glyphs can share the same pixel pattern.
The user's mappings are retained as glyph correspondences, not new claims about
the scanner/control protocol. In particular, 0D has exact matches for both U+21B2
and U+21B5 in different fonts; the user's U+21B5 choice is retained.

This describes glyph identity, independently of firmware text-editor records.
For example, a byte can have printable font artwork and also serve as an editor
control depending on context. See `research/syscalls/text/token-records.md`.
Unknown slots must not silently become Unicode C0/C1 controls or question marks.

BDF ENCODING remains the native byte. Each file declares NEO/US, and STARTCHAR
uses the mapped Unicode glyph name (with a suffix for duplicate aliases).
Unmapped artwork uses a native-byte glyph name. A missing BDF glyph is separate
from an unknown Unicode mapping; missing glyphs remain absent, and the applet
build's explicit fallback policy supplies `?` where required by its 256-slot table.
