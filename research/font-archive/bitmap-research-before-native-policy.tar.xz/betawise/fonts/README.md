# BetaWise Fonts

Editable sources live in `BetaWiseSerif/`, `BetaWiseSans/`, `BetaWiseBook/`,
`BetaWiseMono/` and `BetaWiseTerminal/`. All use [FontApplet.c](FontApplet.c).
Finished `.OS3KApp` files stay directly in `fonts/`; intermediate files go in
`build/<applet>/`, with headers named `glyphs.h`, `glyphs-bold.h`, etc.

Our original work in this folder is public domain. Third-party font notices
remain applicable; see [LICENSE.md](LICENSE.md).

## Provenance and changes

The four reader families come from X11 bitmap fonts at 75/100 dpi.
The applet INFO field carries the upstream copyright; the complete notices
remain in the BDFs and [license](LICENSE.md). Sizes below are source
pixel sizes, not the line pitch. Small faces retain the reviewed local fixes;
the other sizes are untouched native bitmaps.

| Family | Very Large / Large / Medium / Small | Small-face changes |
|---|---|---|
| BetaWise Serif | 17 / 12 / 11 / 8px | Cedilla body alignment; wider Regular c/ç; native 5px capitals and 2px space retained |
| BetaWise Sans | 17 / 12 / 11 / 8px | Reviewed accent fitting and cedilla alignment/placement |
| BetaWise Book | 17 / 12 / 11 / 8px | Reviewed accent fitting and cedilla alignment |
| BetaWise Mono | 20 / 14 / 11 / 8px | Extra cell column, local overflow fixes, three-stem m, bottom pixel in oblique a and accented a |

BetaWise Terminal Medium’s 6×8 glyphs were independently recreated from the
AlphaSmart 3000 LCD controller font, including AlphaSmart’s custom modifications. Its 5×7 and 4×6 sources come from
public-domain X11 Misc Fixed. [LICENSE.md](LICENSE.md) distinguishes Terminal’s
provenance and notices from the reader fonts. The artifact includes this consolidated license file. BDFs preserve the existing Neo byte
slots and pixels, checked against independent [PNG fixtures](../tests/fonts/fixtures/).

## Names and IDs

| Size | Lines | Serif | Sans | Book | Mono |
|---|---:|---|---|---|---|
| Small | 6 | AFF3 | AFF7 | AFFB | AFFF |
| Medium | 5 | AFF2 | AFF6 | AFFA | AFFE |
| Large | 4 | AFF1 | AFF5 | AFF9 | AFFD |
| Very Large | 3 | AFF0 | AFF4 | AFF8 | AFFC |

For example, `BetaWiseSerif-Small.OS3KApp` returns the font name
**BetaWise Serif Small**. Its applet name is automatically formed as
**BetaWise Serif Small (6 lines)**. Each reader provider includes all four styles.

Terminal's Medium / Small / Tiny variants use 6×8 / 5×7 / 4×6 cells,
fitting 44×8 / 52×9 / 66×10 characters. All three retain ID A1F0; install one
at a time. Their font names are BetaWise Terminal Medium, BetaWise Terminal Small,
and BetaWise Terminal Tiny; applet names add 8, 9 and 10 lines respectively.

## Build and conversion

Run `make -C fonts` from the repository root, or `make -C fonts readers` for
only the reader families. Select one with
`make -C fonts READER_FAMILY=Serif READER_LINES=6` or `make -C fonts FONT=Tiny`.
`make -C fonts clean` removes the entire `build/` tree and published font images.

The Makefile invokes [fontgen.py](fontgen.py) directly for each BDF. Its
`--symbol-prefix` option separates optional style symbols; `FontApplet.c` uses
`#ifdef` to include the available faces. Each header supplies one static const
descriptor in initialized RAM for CRT pointer relocation; glyph data stays in
flash. There is no per-query initialization or font-specific MSG_INIT handler.
Missing styles return NULL. Applet
names are derived from `FONT_NAME` and `FONT_LINES`, with a length check.
Generated headers belong only in `build/`; prototype readers use
`build/BetaWiseTerminal-Medium/glyphs.h` directly.

The converter also accepts PNG/PCF and gzip-compressed BDF/PCF. BDF encoding is
Neo-US byte slots 0–255; `os3k/charsets/neo-us.txt` supplies glyph identities.
PCF uses `--pcf-encoding` (default `iso8859-1`). Reader BDFs retain their original 218 printable Western slots and now include
available Neo-specific artwork from each original X11 strike. Glyphs that are
unavailable or exceed the existing cell remain absent; builds explicitly
substitute `?` for missing slots. Existing artwork and line metrics are preserved. The shared descriptor maps all 256 slots, including Ń and Σ. Slots 16/0D share
the return-arrow mapping; 90/60 share the grave-accent mapping.

Verification after building:

```
python3 -m unittest discover -s tests/fonts -p test_fontgen.py -v
python3 tests/fonts/check_reader_applets.py
python3 tests/fonts/check_font_relocations.py
```

The offline checks exercise IDs, names, style getters and glyph tables, and
rebase all initialized descriptor pointers at displaced flash/RAM addresses.
It uses no screenshots or model inference.

## Glyph review

Run `make -C fonts review`, then open `fonts/glyph-review.html` in a browser.
It embeds every current BDF, works offline, and does not edit the sources.
Click a glyph to flag it; ASCII letters also flag their accented forms in the
same face; Unicode aliases are also grouped. Shift-click toggles only one glyph. Missing artwork is shown separately.
Flags persist in browser storage and can be exported/imported as JSON.

The mapping-review view shows only Neo-specific additions and unresolved native
slots beyond printable CP1252, with source Neo system-font and Terminal bitmaps.
Confirm mappings or suggest a character/U+ value; exports contain proposals only.
The complete CP1252 portion does not need reviewing again.

The Neo-specific import is recorded in
[the import report](../research/bible-reader/font-specimens/charset-review/glyph-import.json).
It added 466 glyphs across the reader faces while preserving all 14,720 existing
source glyphs exactly. Ten source glyphs did not fit the existing vertical bounds;
these and unavailable source characters remain visibly missing in the review.

## Bitmap versus vector review

Generate the offline comparison picker with:

```
make -C fonts vector-review
```

Open `fonts/vector-review.html`. The current generated page includes
all 67 faces and the 32 glyphs from the latest manual review. To seed a new set
of flags, use `make -C fonts vector-review REVIEW_FLAGS=/absolute/path/to/fixes.json`,
or import that JSON in the browser. The original glyph picker also links to this
page. A family-only generation is available through
`python3 fonts/vector_review.py --family Mono`.

Select a family, size, style and character. Compare C/G/O/Q or another related
shape group, then click a candidate or **Keep current bitmap**. Hover/focus previews
it in a 264×65 text specimen. Choices and notes persist locally; **Export choices**
writes `betawise-vector-choices.json` for the subsequent font update. Importing
saved choices rejects changed original cells, changed candidates and mismatched
source metadata. Export includes keep-current decisions, exact original and
proposed bitmaps, unchanged dimensions/baseline, notes and source provenance.
The picker itself never writes BDFs or installs applets.

The generator uses FreeType monochrome rasterization with embedded bitmaps
disabled, comparing the source's native hinter against the auto-hinter. It
calibrates nearby sizes against each bitmap face's A and x ink heights, tries
whole- and half-pixel horizontal phases, and allows at most a one-pixel horizontal
translation. The baseline and existing per-glyph advance are fixed. Missing slots
use the existing question-mark fallback's cell width. Every source ink pixel must
fit; overflowing candidates are rejected, never cropped or rescaled. Up to six
different shapes are retained per outline source per cell, deduplicating equivalent
translated renderings within that source. Use the outline-source filter to compare
fonts independently; the candidate budget for one source cannot crowd out another. Nearest metric matches are ordering aids, not legibility scores.
Ink width, pixel count, eight-connected ink parts and four-connected enclosed
counters are shown as diagnostics. Related styles are reviewed independently.

[vector-sources.json](vector-sources.json) selects local outline references:
Liberation Serif/Sans/Mono and TeX Gyre Schola. Terminal uses Liberation Mono as a
reference, not an exact outline counterpart. Optional local Microsoft references add Times New Roman for Serif, Arial/Verdana
for Sans, Georgia for Book, and Courier New for Mono. The installed Wine directory
is read directly; no font installation or downloads are performed. Only Courier
New Italic was found locally. An additional Georgia 2.11 Regular reference lives
in the user font directory. Missing styles are listed explicitly and are never
filled with synthesized styles or another font. Native TrueType instructions were
verified in the added files; bytecode presence alone does not establish manual
hint authorship. No Helvetica or Century Schoolbook outline was found in the
checked installed directories.

Configure additional sources with
`--sources /path/to/config.json`; each family entry supplies Regular/Bold/Italic/
BoldItalic files, provenance and license information. A null file means that style
is unavailable; optional sources can be absent on other machines. `~` in source
directories expands to the current user’s home directory. The fonts are not bundled;
the generator reads installed outlines and embeds the candidate rasters. Exported
choices retain source/license metadata for any subsequent imported artwork.

On Debian the additional dependencies are `build-essential`, `pkg-config`,
`libfreetype-dev`, `fonts-liberation2` and `fonts-texgyre`; Python/Pillow are already
used by the ordinary converter. The tiny host FreeType bridge is built under
`fonts/build/vector-review/` and is removed by the ordinary clean target.

Checks:

```
python3 -m unittest discover -s tests/fonts -p 'test_*.py'
python3 tests/fonts/check_vector_review.py
```

The raster test additionally needs `python3-fonttools` and uses an independently
authored rectangular TrueType fixture to
verify actual FreeType ink/metrics and clipping rejection. The isolated browser
check exercises exact canvas pixels, C/G/O/Q context, 264×65 specimen geometry,
per-style choices, flag navigation, persistence, and atomic JSON import/export.
There is no screen capture or model-based legibility judgement in these checks.
